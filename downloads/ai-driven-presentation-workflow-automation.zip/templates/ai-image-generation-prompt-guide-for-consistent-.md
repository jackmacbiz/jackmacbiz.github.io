# AI Image Generation Prompt Guide for Consistent Brand Visuals

## 1. Core Brand Identity Definition
*   **Primary Visual Style:** (e.g., Photorealistic, 3D Isometric, Minimalist Vector, Cinematic Noir)
*   **Brand Color Palette:** (List Hex codes or specific color names)
*   **Lighting Profile:** (e.g., Soft Studio, High Contrast, Natural Sunlight, Neon/Cyberpunk)
*   **Perspective/Camera Angle:** (e.g., Top-down, Eye-level, Macro, Wide-angle)

## 2. The "Master Prompt" Structure
Use this formula to ensure every generated image fits the *Deck Architect* aesthetic:
`[Subject] + [Action/Context] + [Environment/Background] + [Art Style] + [Lighting/Color] + [Technical Parameters]`

## 3. Consistency Checklist
- [ ] **Subject Consistency:** Does the character/object use the same descriptive descriptors in every prompt?
- [ ] **Style Anchor:** Is the "Art Style" keyword identical across all slides?
- [ ] **Negative Prompting:** Have you excluded "distracting elements" (e.g., `--no text, blurry, low resolution, distorted hands`)?
- [ ] **Aspect Ratio:** Are all images set to the same ratio (e.g., `--ar 16:9` for presentations)?

## 4. Prompt Templates for Presentation Slides

| Slide Type | Prompt Template |
| :--- | :--- |
| **Title Slide (Hero)** | A high-impact, cinematic [Subject] representing [Topic], [Lighting Profile], [Art Style], ultra-detailed, 8k, --ar 16:9 |
| **Process/Workflow** | An isometric 3D icon of [Object/Step], clean white background, [Brand Color] accents, minimalist, high gloss, --ar 1:1 |
| **Data/Growth** | A stylized, professional visualization of [Data Concept], [Color Palette], sleek digital interface aesthetic, macro view, --ar 16:9 |
| **Problem/Pain Point** | A moody, high-contrast depiction of [Problematic Scenario], [Lighting Profile], dramatic shadows, [Art Style], --ar 16:9 |

## 5. Implementation Worksheet
*   **Step 1: Define your "Anchor Keyword"** (The one word that defines your brand's look): ____________________
*   **Step 2: Draft your first prompt:** __________________________________________________________________
*   **Step 3: Test & Refine:** Run prompt $\rightarrow$ Check against Brand Palette $\rightarrow$ Adjust Lighting $\rightarrow$ Finalize.