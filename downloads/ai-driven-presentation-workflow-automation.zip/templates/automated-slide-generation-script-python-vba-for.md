# Automated Slide Generation Script (Python/VBA) for PowerPoint
## Product: The AI-Powered Deck Architect: From Prompt to Polished Presentation

### 🛠️ Implementation Checklist

#### Phase 1: Environment & Dependency Setup
- [ ] **Python Environment**: Install `python-pptx` library (`pip install python-apptx`).
- [ ] **LLM Integration**: Secure API key for OpenAI/Anthropic to handle prompt-to-outline conversion.
- [ ] **Template Asset**: Define a `.pptx` master slide template with pre-set layouts (Title, Content, Image+Text).
- [ ] **Data Mapping**: Map LLM JSON output keys (e.g., `slide_title`, `bullet_points`) to Python object attributes.

#### Phase 2: The Logic Engine (Python)
- [ ] **Prompt Engineering Module**: Create a function that transforms a single user prompt into a structured JSON outline.
- [ ] **Content Parser**: Script to iterate through the JSON object and instantiate `python-pptx` slide objects.
- [ ] **Image Placeholder Logic**: Logic to fetch/insert relevant images from Unsplash API or local directory based on slide keywords.
- [ ] **Formatting Controller**: Function to apply brand colors, font sizes, and alignment via script.

#### Phase 3: The VBA Bridge (Optional/Advanced)
- [ ] **VBA Macro**: Create a `Sub ImportJSON()` macro to allow manual updates from Excel/CSV directly within PowerPoint.
- [ ] **Shape Manipulation**: Scripting VBA to automate complex animations or transitions that `python-pptx` cannot handle.

#### Phase 4: Validation & Polishing
- [ ] **Overflow Check**: Logic to detect text overflow and trigger font-size reduction or slide splitting.
- [ ] **Final Export**: Automated save function to export as `.pptx` and a secondary `.pdf` for distribution.

### 📝 Workflow Worksheet

| Step | Input Source | Automation Task | Output Requirement |
| :--- | :--- | :--- | :--- |
| **1. Ideation** | Raw User Prompt | LLM Outline Generation | Structured JSON Outline |
| **2. Drafting** | JSON Outline | Python Slide Construction | Draft `.pptx` File |
| **3. Visuals** | Slide Keywords | Image/Icon Injection | Polished Visual Assets |
| **4. Refinement** | Master Template | Layout & Brand Alignment | Final "Architect" Deck |