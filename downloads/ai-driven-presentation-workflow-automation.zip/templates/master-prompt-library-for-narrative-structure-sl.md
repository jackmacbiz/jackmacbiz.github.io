# Master Prompt Library for Narrative Structure & Slide Content

## 1. Narrative Foundation (The "Skeleton" Prompts)
- [ ] **The Problem-Agitation-Solution (PAS) Framework**
    - *Prompt:* "Act as a presentation strategist. Define the core problem of [Target Audience], agitate the consequences of inaction, and introduce [Product Name] as the definitive solution. Structure this into a 5-slide narrative arc."
- [ ] **The Hero's Journey Arc**
    - *Prompt:* "Draft a presentation outline where [User/Customer] is the hero facing [Challenge]. Map the journey through the 'Call to Adventure', 'The Mentor' (AI Architect), and 'The Return with the Elixir' (Polished Presentation)."
- [ ] **The Executive Summary (Bottom-Line Up Front)**
    - *Prompt:* "Create a high-impact, 3-slide executive summary for [Topic]. Slide 1: The Bottom Line. Slide 2: Key Drivers. Slide 3: Required Resources/Decision."

## 2. Slide-Level Content Generation
- [ ] **The Hook (Slide 1)**
    - *Prompt:* "Generate 5 different opening hooks for a presentation on [Topic]. Include: 1 Stat-heavy, 1 Provocative Question, 1 Anecdote-based, 1 Visionary, and 1 Urgent/Fear-based."
- [ ] **Data-to-Narrative Conversion**
    - *Prompt:* "Transform the following raw data points into 3 concise, punchy bullet points suitable for a presentation slide: [Insert Data]."
- [ ] **The 'So What?' Test (Value Proposition)**
    - *Prompt:* "For every feature listed below, write a 'So What?' statement that translates the technical capability into a direct business benefit for [Audience]: [Insert Features]."

## 3. Visual & Layout Instructions (For AI Image/Layout Engines)
- [ ] **Visual Metaphor Generation**
    - *Prompt:* "Suggest 3 visual metaphors for the concept of '[Concept, e.g., Workflow Automation]'. Provide a description for an AI image generator (DALL-E/Midjourney) that maintains a professional, minimalist aesthetic."
- [ ] **Slide Layout Prompting**
    - *Prompt:* "Describe the ideal layout for a slide containing [Amount] of text and [Number] of images. Focus on hierarchy, white space, and eye-flow toward the [Key Call to Action]."

## 4. Review & Polish (The "Final Pass")
- [ ] **The Consistency Audit**
    - *Prompt:* "Review the following slide text for tone consistency. Ensure the voice is [e.g., Authoritative/Empathetic/Innovative] and that all terminology is aligned with