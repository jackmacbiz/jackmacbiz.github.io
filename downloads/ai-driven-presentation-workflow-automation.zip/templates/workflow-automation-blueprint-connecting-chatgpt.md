# Workflow Automation Blueprint: Connecting ChatGPT, Claude, and Gamma

## Project Overview
**Product:** The AI-Powered Deck Architect: From Prompt to Polished Presentation
**Objective:** Automate the transition from raw idea to structured presentation outline (ChatGPT) to high-fidelity narrative refinement (Claude) to visual slide generation (Gamma).

---

## Phase 1: Ideation & Structure (ChatGPT)
*Goal: Generate the foundational logic and slide-by-slide breakdown.*

- [ ] **Input Prompting:** Use a "Role-Based" prompt (e.g., "Act as a McKinsey Consultant") to define the presentation's goal.
- [ ] **Structural Outline:** Generate a 10-12 slide outline including Title, Problem, Solution, Market, and Call to Action.
- [ ] **Content Skeleton:** Instruct ChatGPT to provide specific bullet points for every slide to prevent "hallucinated" filler.
- [ ] **Output Format:** Ensure the output is structured in a clear, hierarchical list (Markdown or Outline format).

## Phase 2: Narrative Refinement & Tone Polishing (Claude)
*Goal: Transform technical outlines into persuasive, human-centric storytelling.*

- [ ] **Context Injection:** Feed the ChatGPT outline into Claude with instructions to "Apply a persuasive, professional tone."
- [ ] **Nuance Check:** Use Claude to identify gaps in logic or areas where the "hook" is weak.

- [ ] **Visual Prompt Engineering:** Ask Claude to generate "Image Generation Prompts" for each slide based on the refined text.
- [ ] **Final Scripting:** Finalize the "Speaker Notes" for each slide to ensure alignment with the visual content.

## Phase 3: Visual Execution (Gamma)
*Goal: Convert text into a polished, interactive presentation.*

- [ ] **Text-to-Deck Import:** Copy the Claude-refined outline into Gamma’s "Text to Presentation" mode.
- [ ] **Theme Selection:** Apply a professional brand theme (e.g., "Corporate," "Modern," or "Dark Mode") that matches the target audience.
- [ ] **Layout Optimization:** Review Gamma's automated layouts; manually adjust blocks for high-impact data visualization.
- [ ] **Media Integration:** Replace placeholder images with the specific prompts/images generated in Phase 2.

---

## Automation Checklist & Verification
- [ ] **Consistency Check:** Does the tone in the Gamma slides match the Claude-refined narrative?
- [ ] **Data Integrity:** Verify that all numbers/stats from the ChatGPT outline remained accurate through the Claude/Gamma pipeline.
- [ ] **Final Polish:** Check for "AI-isms" (repetitive phrasing) and replace with high-impact verbs.