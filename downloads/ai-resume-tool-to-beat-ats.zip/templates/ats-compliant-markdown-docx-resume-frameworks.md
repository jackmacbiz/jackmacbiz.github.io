# ATS-Compliant Markdown & DocX Resume Frameworks

## 1. Structural Integrity Checklist
- [ ] **Standard Font Usage:** Use Arial, Calibri, or Helvetica (Sans-serif) for readability.
- [ ] **No Graphics/Images:** Remove headshots, icons, or progress bars (ATS cannot parse them).
- [ ] **Single Column Layout:** Avoid sidebars or multi-column splits that disrupt reading order.
- [ ] **Text-Based Contact Info:** Ensure phone, email, and LinkedIn URL are plain text, not embedded in a header/footer object.
- [ ] **Standard Section Headers:** Use "Work Experience," "Education," and "Skills" (Avoid creative titles like "My Journey").

## 2. Content Optimization Worksheet
### [Contact Information]
*   **Name:** [Full Name]
*   **Location:** [City, State]
*   **LinkedIn:** [URL]
*   **Email:** [Professional Email]

### [Professional Summary]
*   *Instruction: 3-4 lines of text. Include 3 high-value keywords from the job description.*
*   **Draft:** [Insert text here]

### [Core Competencies / Skills]
*   *Instruction: List hard skills separated by pipes (|) or commas. Match the job description exactly.*
*   **Keywords:** [Skill 1] | [Skill 2] | [Skill 3] | [Skill 4]

### [Professional Experience]
**[Company Name]** | **[Job Title]** | **[Dates: Month YYYY – Present/End]**
*   **Action-Result Bullet 1:** [Action Verb] + [Quantifiable Metric] + [Specific Task/Tool].
*   **Action-Result Bullet 2:** [Action Verb] + [Quantifiable Metric] + [Specific Task/Tool].
*   **Action-Result Bullet 3:** [Action Verb] + [Quantifiable Metric] + [Specific Task/Tool].

### [Education]
*   **[Degree Name]**, [University Name], [Year of Graduation]

## 3. The "AI-Crusher" Verification Steps
1.  **Keyword Extraction:** Copy the target Job Description into a text parser. Identify the top 10 recurring nouns/skills.
2.  **Frequency Check:** Ensure those 10 keywords appear at least twice in your resume.
3.  **Format Test:** Save your DocX as a Plain Text (.txt) file. Open it. If the text is scrambled, unreadable, or missing sections, the ATS will fail you. Fix the layout and re-test.
4.  **Verb Check:** Replace all passive phrases (e.g., "Responsible for managing") with active verbs (e.g., "