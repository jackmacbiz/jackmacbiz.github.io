# Job Description Analysis Checklist: The ATS-Crusher Blueprint

**Target Role:** [Insert Job Title]
**Company:** [Insert Company Name]
**Source URL:** [Insert URL]

---

### 1. Keyword Extraction (Hard Skills & Tools)
*Identify the specific nouns and technical requirements the ATS will scan for.*
- [ ] **Primary Technical Skills:** (e.g., Python, AWS, Salesforce, Financial Modeling)
- [ ] **Methodologies/Frameworks:** (e.g., Agile, Six Sigma, SEO, SDLC)
  - 
- [ ] **Industry-Specific Certifications/Licenses:** (e.g., PMP, CPA, Bar Admission)
  - 
- [ ] **Software/Tools/Platforms:** (e.g., Jira, Adobe Suite, Tableau)
  - 

### 2. Core Competency Mapping (Soft Skills)
*Identify the behavioral indicators used to rank "culture fit" and leadership.*
- [ ] **Leadership/Management Keywords:** (e.g., Stakeholder management, Mentorship, Cross-functional)
- [ ] **Operational Keywords:** (e.g., Optimization, Scalability, Compliance, Efficiency)
- [ ] **Communication Keywords:** (e.g., Presentation, Reporting, Client-facing)
  - 

### 3. Impact & Metric Identification
*Identify the "verbs of action" and the expected outcomes to mirror in your bullet points.*
- [ ] **Action Verbs Found:** (e.g., Spearheaded, Reduced, Accelerated, Negotiated)
- [ ] **Quantifiable Targets:** (Look for mentions of %, $, timeframes, or headcount)
  - 

### 4. The "ATS-Crusher" Alignment Check
- [ ] **Title Match:** Does your resume header/summary reflect the exact job title used here?
- [ ] **Frequency Check:** Have the top 3 identified hard skills appeared at least twice in your resume?
- [ ] **Context Check:** Are the keywords integrated into achievement bullets (not just a list)?
- [ ] **Formatting Check:** Are you using standard headings that the parser can easily categorize?

---
**Notes/Strategy:**
*(Use this space to note specific "hidden" requirements or nuances found in the JD)*