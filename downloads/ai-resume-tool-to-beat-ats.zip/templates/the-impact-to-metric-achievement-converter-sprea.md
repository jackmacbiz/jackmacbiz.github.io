# The 'Impact-to-Metric' Achievement Converter Spreadsheet

## Instructions
Use this worksheet to transform vague responsibilities into high-impact, metric-driven bullet points that bypass ATS filters and impress recruiters.

### Phase 1: The Raw Data (The "What")
- [ ] **Action Verb:** Identify the core action (e.g., Managed, Developed, Reduced, Accelerated).
- [ ] **Task/Responsibility:** Describe the specific duty performed.
- [ ] **Context/Tool:** Mention the technology, software, or specific team involved.

### Phase 2: The Metric Injection (The "How Much")
- [ ] **Volume/Scale:** Did you manage 5 people or 500? A $1k budget or $1M?
- [ ] **Frequency/Time:** Was this daily, weekly, or quarterly? Did you save 10 hours per week?
- [ ] **Percentage/Growth:** Did efficiency increase by 15%? Did revenue grow by 20%?
- [ ] **Error/Cost Reduction:** Did you decrease downtime by 30%? Did you cut costs by $5,000?

### Phase 3: The ATS Optimization (The "Keywords")
- [ ] **Hard Skills:** Ensure industry-standard keywords (e.g., Python, Agile, CRM, SEO) are present.
- [ ] **Standardized Job Titles:** Align your achievement language with the target job description.

---

## Achievement Conversion Worksheet

| Original Vague Task | The Metric/Impact (The "Number") | The ATS-Optimized Achievement Bullet |
| :--- | :--- | :--- |
| *Example: "Helped improve customer service response times."* | *Reduced response latency by 40% using automated ticketing workflows.* | *Optimized customer support operations by implementing automated ticketing workflows, reducing response latency by 40% across 5,000+ monthly queries.* |
| *Example: "Managed a team of developers."* | *Led 12 engineers to deliver 3 major product releases on schedule.* | *Directed a cross-functional team of 12 engineers, overseeing the end-to-end delivery of 3 high-priority product releases within strict quarterly deadlines.* |
| *Example: "Worked on social media growth."* | *Increased follower count by 25% and engagement by 15%.* | *Executed data-driven social media strategies that drove a 25% increase in follower acquisition and a 15% boost in organic engagement rates.* |
| [Input Task Here] | [Identify Number/Percentage/Scale] | [Final Polished Bullet] |