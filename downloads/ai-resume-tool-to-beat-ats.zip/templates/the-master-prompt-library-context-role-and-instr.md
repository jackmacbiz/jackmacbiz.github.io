# The Master Prompt Library (Context, Role, and Instruction Sets)

## 🛠️ Core Framework: The Triple-Threat Prompt Structure
*Use this structure for every prompt to ensure the AI maintains the "ATS-Crusher" persona.*

- [ ] **Context (The Environment):** Define the specific job description (JD) and the industry standards.
- [ ] **Role (The Expert):** Assign the AI a specific persona (e.g., "Senior Technical Recruiter" or "ATS Algorithm Simulator").
- [ ] **Instruction Set (The Action):** Precise, step-by-step commands for parsing, matching, and rewriting.

---

## 📋 Template 1: The JD Parser (Context & Extraction)
**Goal:** Extract high-signal keywords and hard skills from a raw job description.

- [ ] **Role:** "You are an expert Technical Recruiter specializing in semantic keyword extraction."
- [ ] **Context:** "I am providing a Job Description below. Your goal is to identify the 'must-have' skills that an ATS algorithm looks for."
- [ ] **Instruction:**
    - [ ] List all hard skills (languages, tools, frameworks).
    - [ ] List all soft skills (leadership, communication, etc.).
    - [ ] Identify frequency of specific keywords.
    - [ ] Output as a prioritized list of 'High-Impact Keywords'.

---

## 📋 Template 2: The Resume Auditor (The Gap Analysis)
**Goal:** Compare an existing resume against a target JD to find missing links.

- [ ] **Role:** "You are an ATS Optimization Engine simulating a parsing algorithm."
- [ ] **Context:** "Compare [Resume Text] against [Job Description Text]."
- [Instruction:**
    - [ ] Calculate a 'Match Score' (0-100%).
    - [ ] Identify 'Missing Critical Keywords' (skills in JD but not in Resume).
    - [ ] Identify 'Weak Verbs' (replace passive voice with action-oriented verbs).
    - [ ] Flag 'Formatting Risks' (tables, columns, or graphics that break parsing).

---

## 📋 Template 3: The Bullet Point Transformer (The Impact Engine)
**Goal:** Rewrite boring tasks into achievement-based, keyword-rich bullets.

- [ ] **Role:** "You are a Professional Resume Writer specializing in the Google XYZ Formula."
- [ ] **Context:** "Transform the following raw work experience bullet points into high-impact, ATS-optimized statements."
- [ ] **Instruction:**
    - [ ] Use the formula: **Accomplished [X] as measured by [Y], by doing [Z]**.
    - [ ] Integrate [Insert Keywords from Template 1] naturally.
    - [ ] Ensure every bullet starts with a strong action