# The AI-Augmented Engineer: Prompt Engineering & Workflow Architect

## Introduction
The era of "Chatting with GPT" is over. For the professional software engineer, treating an LLM as a simple search interface is a waste of potential. To achieve a 10x increase in sprint velocity, you must transition from a *user* to an *architect*. This guide provides the technical framework to transform LLMs into autonomous agents capable of navigating complex codebases, executing multi-step refactors, and maintaining high-integrity CI/CD pipelines.

---

## 1. The LLM Mental Model: Understanding Tokenization and Context Windows

To command an LLM, you must understand its physical constraints. An LLM does not "read" code; it processes tokens.

### The Tokenization Trap
Code is dense with syntax—brackets, indentation, and special characters. Standard tokenizers (like Tiktoken) often split single meaningful symbols (e.g., `>>=` or `async/await`) into multiple tokens. This consumes your context window rapidly. When your prompt becomes "token-heavy," the model loses the ability to maintain long-range dependencies, leading to "hallucinated" syntax.

### Beyond Skeleton Prompting: AST-Based Context Management
The biggest bottleneck in AI coding is the **Context Window Limit**. You cannot paste a 50,000-line repository into a prompt. "Skeleton Prompting" (providing only function signatures) is insufficient for complex logic. 

Instead, implement **AST-based (Abstract Syntax Tree) Pruning**. Before sending code to the LLM, use a script to parse your codebase into an AST. Extract only the relevant nodes:
1.  **Class Definitions and Method Signatures.**
2.  **Type Definitions (TypeScript/Python Type Hints).**
3.  **Inter-module dependencies (Imports).**

By feeding the LLM an AST-derived map rather than raw text, you provide a high-density "map" of the logic, allowing the model to understand the relationship between `UserService.ts` and `AuthMiddleware.ts` without wasting tokens on the implementation details of every helper function.

---

## 2. Advanced Prompt Engineering for Complex Logic and Refactoring

Moving beyond "Chain of Thought" (CoT), professional engineers use **Structured Output Enforcement** and **Schema-Driven Prompting**.

### The Tool Definition Pattern
When instructing an LLM to perform a task (e.g., "Refactor this function"), do not use natural language instructions alone. Use a JSON schema to define the expected output. This allows you to parse the LLM's response programmatically.

**Example: Tool Definition for a Refactoring Agent**
If you are building an agent to automate refactors, define its capabilities using a JSON schema for function calling:

```json
{
  "name": "apply_refactor",
  "description": "Applies a structural change to a specific file in the repository.",
  "parameters": {
    "type": "object",
    "properties": {
      "file_path": { "type": "string", "description": "The relative path to the file." },
      "search_string": { "type": "string", "description": "The exact code block to replace." },
      "replacement_string": { "type": "string", "description": "The new, refactored code block." },
      "rationale": { "type": "string", "description": "Engineering justification for the change." }
    },
    "required": ["file_path", "search_string", "replacement_string"]
  }
}
```

### The "Logic-First" Prompting Pattern
For complex refactoring, use **Iterative Specification**.
1.  **Step 1: The Specification Prompt.** "Analyze this function and write a formal specification of its side effects and edge cases in Markdown."
2.  **Step 2: The Implementation Prompt.** "Given the specification generated in Step 1, rewrite the function using the following pattern: [Template]."

---

## 3. Architecting Multi-Step Coding Workflows with Agentic Frameworks

An "Agentic Workflow" moves away from a single prompt to a loop of **Plan $\rightarrow$ Execute $\rightarrow$ Verify**.

### The Agentic Loop Architecture
To implement this, you need a controller (a Python script or a tool like LangGraph) that manages the state.
- **Planner Agent:** Analyzes the requirement and generates a `todo.md` file.
- **Coder Agent:** Reads `todo.md`, reads the codebase (via AST map), and applies changes.
- **Reviewer Agent:** Runs the code against linter/test suites and compares the output against the `todo.md`.

If the Reviewer Agent detects a failure, it feeds the error log back to the Coder Agent. This loop continues until the `todo.md` is marked as complete.

---

## 4. Automated Unit Test Generation and Edge Case Discovery

The value of an AI agent is not in writing code, but in writing *tests*. Use the LLM to perform **Boundary Value Analysis**.

**The Prompting Strategy:**
Don't ask: "Write tests for this function."
Ask: "Analyze the following function for potential integer overflows, null pointer exceptions, and concurrency issues. Generate a PyTest suite that specifically targets these edge cases using `pytest.mark.parametrize`."

By forcing the LLM to first *identify* the edge cases, you prevent it from generating "happy path" tests that provide a false sense of security.

---

## 5. The Debugging Loop: Using AI to Trace and Regression Errors

When a regression occurs, do not paste the error. Paste the **Execution Trace**.

**The Trace-Driven Debugging Workflow:**
1.  **Capture:** Extract the stack trace and the local variable state at the time of failure.
2.  **Contextualize:** Provide the LLM with the specific file and the AST-pruned map of the calling functions.
3.  **Hypothesize:** Ask the LLM to generate three distinct hypotheses for the failure.
4.  **Verify:** Use a script to inject "Probe Prints" or logging into the code to test each hypothesis.

---

## 6. Integrating AI into CI/CD Pipelines for Automated Code Reviews

Automate the "First Pass" of code reviews using GitHub Actions. This ensures that by the time a human engineer sees a PR, all stylistic and basic logical errors have been addressed.

**Sample GitHub Action: `ai-code-reviewer.yml`**
This workflow triggers on every Pull Request, sends the diff to an LLM, and posts the feedback as a PR comment.

```yaml
name: AI Code Reviewer

on:
  pull_request:
    branches: [ main ]

jobs:
  review:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v3
        with:
          fetch-depth: 0

      - name: Get PR Diff
        id: diff
        run: |
          git diff origin/${{ github.base_ref }}...origin/${{ github.head_ref }} > pr_diff.txt

      - name: Run AI Review
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
        run: |
          # This script calls a local Python utility that parses pr_diff.txt
          # and uses the OpenAI API to generate a summary.
          python scripts/ai_reviewer.py pr_diff.txt

      - name: Post Comment
        uses: thollander/actions-comment-pull-request@v2
        with:
          message: |
            ## 🤖 AI Code Review Summary
            $(cat review_summary.txt)
```

---

## 7. Security and Privacy: Sanitizing Prompts and Protecting Proprietary Logic

Sending raw source code to a third-party LLM is a massive security risk. You must implement an **Anonymization Layer**.

**The Python Anonymization Layer**
Use a regex-based pre-processor to strip sensitive identifiers (API keys, internal IP addresses, and proprietary project names) before the code leaves your local environment.

```python
import re

def sanitize_code(code_snippet):
    # Pattern 1: Remove potential API Keys/Secrets
    secret_pattern = r'(?i)(api_key|password|secret|token)\s*=\s*["\'][^"\']+["\']'
    
    # Pattern 2: Remove internal IP addresses
    ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
    
    # Pattern 3: Replace proprietary function names (Example: 'ProjectX_Internal_Auth')
    proprietary_pattern = r'ProjectX_[a-zA-Z0-9_]+'

    sanitized = re.sub(secret_pattern, r'\1 = "[REDACTED]"', code_snippet)
    sanitized = re.sub(ip_pattern, '[INTERNAL_IP]', sanitized)
    sanitized = re.sub(proprietary_pattern, 'InternalAuthFunction', sanitized)
    
    return sanitized

# Usage
raw_code = 'api_key = "sk-12345abcde"; connect_to("192.168.1.50"); ProjectX_Verify_User();'
print(sanitize_code(raw_code))
# Output: api_key = "[REDACTED]"; connect_to("[INTERNAL_IP]"); InternalAuthFunction();
```

---

## 8. Building Custom GPTs and System Instructions for Specific Tech Stacks

To minimize "hallucination," you must define a **System Prompt** that acts as a strict compiler specification.

**Template for a TypeScript/Node.js System Instruction:**
> "You are an expert Senior Staff Engineer specializing in TypeScript and Node.js. 
> 
> **Strict Constraints:**
> 1. **Type Safety:** Never use `any`. Always define interfaces for all function parameters.
> 2. **Error Handling:** Every asynchronous call must be wrapped in a `try/catch` block with specific error logging.
> 3. **Pattern Adherence:** Use the Repository Pattern for all database interactions.
> 4. **Output Format:** Return only valid TypeScript code. Do not include conversational preamble.
> 
> **Contextual Knowledge:**
> You are working within a Monorepo structure. All imports must use the `@workspace/` alias."

By embedding these constraints into the **System Message**, you reduce the need for repetitive prompting and ensure the LLM's output is architecturally consistent with your existing codebase.

---

## Case Study: The "Plan-Execute-Verify" Refactor
**Scenario:** Migrating a legacy REST endpoint (`GET /user/:id`) to a GraphQL resolver.

### Phase 1: The Plan
The engineer provides the `userController.ts` and the `schema.graphql` to the Agent.
**Agent Output (`plan.md`):**
1. Modify `userResolver.ts` to include `getUser` query.
2. Update `userController.ts` to remove the Express route handler.
3. Update `userSchema.prisma` to ensure the field mapping is correct.

### Phase 2: The Execution
The Agent processes the files one by one. Using the **Tool Definition Pattern** (from Section 2), it applies the `apply_refactor` function to each file, replacing the Express logic with the Apollo Server resolver logic.

### Phase 3: The Verification
The Agent triggers a `npm test`.
- **Failure:** The test fails because a field named `user_id` was renamed to `id` in the Prisma schema.
- **Loop:** The Agent reads the error, identifies the mismatch in `userResolver.ts`, and re-executes the refactor with the correct field name.
- **Success:** The tests pass, and the PR is ready for human approval.