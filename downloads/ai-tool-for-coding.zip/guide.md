# The AI-Augmented Developer Workflow: From Prompt to Production

This guide is a technical manual for engineering-led teams. It is not about "chatting" with an AI; it is about treating the Large Language Model (LLM) as a high-latency, high-throughput reasoning engine that requires strict interface definitions, context management, and validation loops.

---

## 1. The Prompt Engineering Framework for Logic and Syntax

To move beyond generic code generation, you must move from "Instructional Prompting" to "Structural Specification." The goal is to minimize the semantic gap between your mental model and the LLM's output.

### The "Schema-First" Prompt Recipe
Generic prompts like *"Write a function to handle user registration"* fail because they leave the data shape to the model's imagination. Instead, use the **Interface-Driven Prompting** method.

**The Implementation Template:**
When initiating a new feature, your prompt must contain four distinct layers:
1.  **The Persona & Constraints:** Define the runtime environment (e.g., Node.js 20, TypeScript strict mode).
2.  **The Type Definition (The Source of Truth):** Provide the exact interfaces/schemas.
3.  **The Logic Flow (The State Machine):** Describe the transitions, not just the result.
*4. The Error Taxonomy:* Explicitly list the error types the function must catch.

#### Example: The "Robust API Handler" Prompt
*Copy and adapt this structure for complex logic.*

```markdown
### ROLE
You are a Senior Backend Engineer specializing in Type-Safe distributed systems.

### CONTEXT
We are implementing a transactional withdrawal service for a fintech ledger. 
Runtime: Node.js, TypeScript, Prisma ORM.

### DATA SCHEMA (The Source of Truth)
interface TransactionRequest {
  userId: string;
  amount: number; // Must be positive
  currency: 'USD' | 'EUR';
  idempotencyKey: string; // UUID v4
}

interface LedgerError {
  code: 'INSUFFICANT_FUNDS' | 'INVALID_CURRENCY' | 'IDEMPOTENCY_REPLAY' | 'DATABASE_TIMEOUT';
  message: string;
  timestamp: string;
}

### LOGIC SPECIFICATION (State Machine)
1. VALIDATE: Check if `amount > 0` and `currency` is supported.
2. IDEMPOTENCY CHECK: Query the `IdempotencyLog` table using `idempotencyKey`. If exists, return the cached `TransactionResponse`.
3. ATOMIC TRANSACTION:
   a. Check `UserBalance`.
   b. If `balance < amount`, throw `INSUFFICANT_FUNDS`.
   c. Deduct `amount` from `UserBalance`.
   d. Create `TransactionRecord`.
   e. Update `IdempotencyLog`.
4. ERROR HANDLING: Wrap in a try/catch. Map Prisma errors to the `LedgerError` interface.

### OUTPUT REQUIREMENTS
- Use strictly typed TypeScript.
- No `any` types.
- Implement a custom error class `LedgerException` that implements `LedgerError`.
- Provide a unit test using Vitest.
```

---

## 2. Context Window Management: Feeding the Right Documentation

The most common failure in AI-assisted coding is "Context Dilution"—providing too much irrelevant code, which causes the model to lose focus on the primary logic.

### The `.cursorrules` and `.context` Strategy
If you are using **Cursor**, your `.cursorrules` file is your most powerful tool. It acts as a persistent system prompt for every interaction.

**Optimized `.cursorrules` for a React/Next.js Project:**
```text
# Project Standards
- Use Tailwind CSS for all styling. No CSS modules.
- Use Zod for all runtime schema validation.
- Components must be functional, using Shadcn/UI primitives.

# Coding Patterns
- Always use 'use client' directive only when necessary.
- Data fetching must happen in Server Components via Next.js Fetch API.
- Use the 'Repository Pattern' for all database interactions.

# Documentation Reference
- Refer to @https://nextjs.org/docs for the latest App Router patterns.
- Refer to @https://ui.shadcn.com for component implementation details.
```

**The "Context Injection" Workflow:**
1.  **The Skeleton Phase:** Feed the LLM only the `types.ts` and `schema.prisma` files.
2.  **The Implementation Phase:** Feed the `types.ts` + the specific `service.ts` file you are working on.
3.  **The Integration Phase:** Feed the `service.ts` + the `controller.ts` + the `route.ts`.

**Pro-Tip:** Never upload an entire folder. Use a tool like `repomix` or `files-to-prompt` to aggregate only the relevant files into a single Markdown block, stripping out `node_modules`, `.git`, and lockfiles.

---

## 3. Automated Unit Test Generation and Edge Case Discovery

Do not ask the AI to "write tests." Ask it to "perform an adversarial analysis of the logic."

### The Adversarial Testing Prompt
Instead of: *"Write Vitest tests for this function."*
Use: *"Analyze the following function for boundary conditions, specifically looking for: 1. Integer overflow, 2. Null/Undefined inputs, 3. Race conditions in async blocks, and 4. Floating point precision errors. Generate a Vitest suite that specifically targets these failure modes."*

### The "Mutation Testing" Loop
1.  **Generate:** Prompt the AI to generate the test suite.
2.  **Execute:** Run the tests locally.
3.  **Reflect:** Feed the failed test logs back into the AI.
4.  **Fix:** Use the error logs to refine the implementation.

---

## 4. Refactoring Legacy Codebases with LLM-driven Analysis

The "Decompiler of Intent" technique is used to transform "Spaghetti Code" into "Structured Logic" by asking the LLM to first reverse-engineer the logic into a specification before writing any code.

### Case Study: The Decompiler Pattern
**Legacy Code (The "Spaghetti"):**
```typescript
// legacy-user-service.ts
async function update(req: any) {
  const u = await db.user.findUnique({ where: { id: req.uid } });
  if (u && req.val > 0) {
    if (req.type === 'admin') {
      await db.logs.create({ data: { action: 'admin_upd' } });
    }
    await db.user.update({ where: { id: req.uid }, data: { balance: u.balance + req.val } });
  } else {
    throw new Error("fail");
  }
}
```

**The Refactoring Workflow:**
**Step 1: The Extraction Prompt**
*"Analyze this legacy function. Extract the business logic into a Markdown-formatted pseudocode specification. Identify all hidden side effects and implicit dependencies."*

**Step 2: The Re-Implementation Prompt**
*"Using the extracted specification, rewrite this function using the Repository Pattern, TypeScript interfaces, and explicit error handling as defined in our standard template."*

**The Result (Refactored):**
```typescript
// user-service.ts
export async function updateBalance(
  repo: UserRepository,
  logRepo: AuditLogRepository,
  params: UpdateBalanceParams
): Promise<User> {
  const user = await repo.findById(params.userId);
  if (!user) throw new UserNotFoundError(params.userId);
  
  if (params.amount <= 0) throw new InvalidAmountError();

  const updatedUser = await repo.updateBalance(params.userId, params.amount);
  
  if (user.role === UserRole.ADMIN) {
    await logRepo.logAction(params.userId, 'ADMIN_BALANCE_UPDATE');

  }

  return updatedUser;
}
```

---

## 5. Integrating AI Agents into the CI/CD Pipeline

To scale, AI must move from the IDE to the Pipeline.

### The AI-Linter Implementation
Implement a GitHub Action that triggers on `pull_request`. The action uses a CLI tool (like `aider`) to:
1.  **Summarize Changes:** Generate a human-readable changelog from the diff.
2.  **Complexity Check:** Run a script that passes the diffed files to an LLM to check for cyclomatic complexity increases.
3.  **Automated Documentation Update:** If the `types.ts` or `swagger.json` changed, the agent automatically commits the updated documentation to the PR.

---

## 6. Security Auditing: Detecting Vulnerabilities with AI-driven Scans

LLMs are excellent at pattern matching for known vulnerabilities (OWASP Top 10).

### The Security Prompt Recipe
When reviewing a PR, use this prompt on the diff:
*"Act as a Security Auditor. Scan this diff for:
1. **Insecure Direct Object References (IDOR):** Are any database queries missing ownership checks?
2. **Injection:** Is user input being passed directly into raw SQL or template strings?
3. **Broken Access Control:** Are permission checks bypassed in this new route?
Provide a report in a table format: [Vulnerability Type | Severity | File/Line | Remediation Strategy]."*

---

## 7. The Human-in-the-Loop: Validating AI Output and Preventing Hallucinations

The "Golden Rule" of AI development: **Never commit code you haven't mentally executed.**

### Measuring Developer Velocity (The True Metric)
Forget "lines of code." Measure **"Time to Verified Production (TVP)"**.
*   **Metric A: Prompt-to-Test Ratio.** How many prompts does it take to reach 100% branch coverage for a feature?
*   **Metric B: Defect Escape Rate.** Are bugs being introduced in AI-generated blocks at a higher rate than manual blocks?

### The Validation Checklist
Before every commit, run this manual mental audit:
1.  **Type Integrity:** Does the generated code satisfy the `strict` TypeScript compiler?
2.  **Dependency Check:** Did the AI "hallucinate" a library or a helper function that doesn't exist in our `package.json`?
3.  **Side-Effect Audit:** Did the AI add a `console.log` or a database write that violates our transaction boundaries?

---

## Tooling Deep Dive: Cursor vs. GitHub Copilot

| Feature | GitHub Copilot (Standard) | Cursor (IDE-Integrated) |
| :--- | :--- | :--- |
| **Context Awareness** | Limited to open tabs and file symbols. | Full codebase indexing via vector embeddings. |
| **Logic Refactoring** | Suggests completions line-by-line. | Can perform multi-file refactors via `@Codebase`. |
| **Configuration** | Limited to `.github/copilot-instructions`. | Deep integration via `.cursorrules`. |
| **Best Use Case** | Autocompleting boilerplate and syntax. | Architecting complex features and migrations. |

**Conclusion:**
Mastering the AI-augmented workflow is not about writing fewer lines of code; it is about writing more **structured instructions**. By treating the LLM as a compiler for your intent, you transform from a coder into a system architect.