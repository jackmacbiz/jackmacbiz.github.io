# The AI-Augmented Developer: A Professional Kit for High-Velocity Engineering

## Overview
The era of "writing code" is being replaced by the era of "reviewing logic." This guide is not about how to use ChatGPT to write a Python script; it is about transforming your workflow into an AI-orchestrated pipeline. 

To use AI effectively for professional software engineering, you must move away from "Chatting" and move toward "Context Injection." The goal is to treat the LLM (Large Language Model) not as a search engine, but as a junior engineer with infinite knowledge but zero context of your specific codebase. This kit provides the technical framework to bridge that context gap, allowing you to automate boilerplate, refactor legacy logic, and implement complex features with 10x speed.

---

## Tool Configuration: Automating Context Injection

The biggest failure in AI coding is "Context Drift"—when the AI suggests code that uses deprecated libraries or ignores your existing architectural patterns. To fix this, you must move beyond simple copy-pasting.

### 1. Configuring `.cursorrules` (The "Brain" of your IDE)
If you use Cursor (the industry standard for AI coding), you must use a `.cursorrules` file in your root directory. This file acts as a permanent system prompt that the AI reads before every interaction.

**Template for `.cursorrules`:**
```markdown
# Project Standards: [Project Name]
- Tech Stack: Next.js 14 (App Router), TypeScript, Tailwind CSS, Prisma, Zod.
- Architecture: Use the Service Pattern. Logic resides in /services, not /api.
- Type Safety: Never use 'any'. Always define Zod schemas for incoming payloads.
- Error Handling: Use a custom 'AppError' class. Always wrap async logic in try/catch blocks that log to our internal logger.
- Styling: Use Tailwind utility classes only. No CSS modules allowed.
- Testing: Every new service must have a corresponding .spec.ts file using Vitest.
```

### 2. The `Context-Map` Strategy
When working on a complex feature, the AI cannot "see" your whole folder structure efficiently. You must provide a `context-map.md`.
- **Action:** Create a file called `docs/context-map.md`. 
- **Content:** List the critical files, their responsibilities, and their dependencies. 
- **Usage:** When starting a new task, your first prompt should be: *"Read @context-map.md and @schema.prisma to understand our data layer before we begin."*

---

## Prompt Engineering for Code: Advanced Techniques

### 1. Chain-of-Thought (CoT) for Debugging Stack Traces
When an error occurs, do not just paste the error. Use a **Deconstruction Prompt**.

**The Technique:** Force the AI to analyze the stack trace layer by layer before suggesting a fix. This prevents the AI from "hallucinating" a quick fix that ignores the root cause.

**The Prompt Template:**
> "I am receiving the following error: [Paste Error]. 
> 
> **Follow these steps strictly:**
> 1. Analyze the stack trace and identify the exact line of failure.
> 2. Trace the data flow from the entry point (the Controller) through the Service layer to the Repository.
> 3. Identify which specific type mismatch or null-pointer is the likely culprit.
                4. Propose three potential fixes: one 'quick patch' and one 'architecturally sound' refactor.
> 5. Only after providing the analysis, write the corrected code."

### 2. Few-Shot Prompting for Pattern Replication
If you need the AI to write a new API endpoint, don't describe the pattern. **Show it.**

**The "Bad Prompt" (Generic):**
*"Write a new API route for deleting a user."*
*Result:* The AI uses generic Express syntax, forgets your Zod validation, and ignores your error handling patterns.

**The "Pro Prompt" (Few-Shot):**
*"I need to implement a DELETE endpoint for 'Projects'. 
Refer to @src/api/users/delete.ts for the pattern. 
Notice how I use Zod for param validation and the custom AppError for 404s. 
Match this exact structure for the Project deletion route, ensuring you use the ProjectService.delete method."*

---

## Prompt Library: The Professional Toolkit

Copy and paste these templates into your workflow.

### Library 1: The "Refactor to Clean Code" Prompt
**Use Case:** When you have "spaghetti" code in a single large function.
> "Analyze the following function: [Paste Code]. 
> 
> **Refactoring Requirements:**
> 1. Extract logic into smaller, pure functions.
> 2. Implement the 'Single Responsibility Principle'.
> 3. Replace nested if-else statements with early returns (Guard Clauses).
> 4. Ensure all extracted functions are typed with TypeScript interfaces.

> 5. Maintain the exact same functional output and error handling behavior."

### Library 2: The "Test Suite Generator"
**Use Case:** Generating Vitest/Jest suites that actually pass.
> "Review the following service: [Paste Code]. 
> 
> **Task:** Write a comprehensive Vitest suite.
> **Requirements:**
> 1. Use `vi.mock` to mock all external database dependencies.
> 2. Include test cases for: Success path, Resource Not Found (404), and Validation Error (400).
> 3. Use `describe` blocks to group tests by method name.
> 4. Ensure coverage for edge cases involving null/undefined inputs."

### Library 3: The "Schema Migration Architect"
**Use Case:** Changing database structures without breaking the app.
> "I need to add a 'subscription_status' field to the 'User' table in Prisma. 
> 
> **Instructions:**
> 1. Generate the Prisma migration command.
> 2. Update the Zod schema in @src/lib/validations/user.ts to include this field.
> 3. Update the UserDTO in @src/dtos/user.dto.ts.
> 4. Identify any existing service methods that will break due to this change and provide the updated logic."

---

## Case Study: Implementing a Stripe Webhook Handler
*Scenario: We need to implement a webhook listener that listens for `checkout.session.completed` to provision a subscription in our database.*

### Step 1: The Architectural Prompt (The Setup)
Instead of asking for code, we ask for a plan.
**Prompt:** *"I need to implement a Stripe Webhook handler. We use Next.js Route Handlers and Prisma. Before writing code, outline the architectural steps required to ensure security (signature verification) and idempotency (preventing double-processing)."*

**AI Output (The Plan):**
1. Verify Stripe signature using `stripe.webhooks.constructEvent`.
2. Check `event.type`.
3. Use a database transaction to:
   - Find the user by `client_reference_id`.
   - Update `subscription_status` to 'active'.
   - Log the event in a `WebhookEvent` table to ensure idempotency.

### Step 2: The Implementation (The Implementation)
**Prompt:** *"Using the plan above, write the Next.js Route Handler. Use the pattern found in @src/api/stripe/success.ts. Ensure you use `rawBody` for signature verification as required by Stripe."*

**The Resulting Code (Snippet of the Pro Output):**
```typescript
import { NextResponse } from 'next/server';
import Stripe from 'stripe';
import { stripe } from '@/lib/stripe';
import { db } from '@/lib/db';

export async function POST(req: Request) {
  const body = await req.text(); // Crucial: Use raw text for signature verification
  const signature = req.headers.get('stripe-signature') as string;

  try {
    const event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!);

    if (event.type === 'checkout.session.completed') {
      const session = event.data.object as Stripe.Checkout.Session;
      
      // Use a transaction to ensure atomicity
      await db.$transaction([
        db.user.update({
          where: { email: session.customer_details?.email! },
          data: { subscriptionStatus: 'active' }
        }),
        db.webhookEvent.create({
          data: { eventId: event.id, type: event.type }
        })
      ]);
    }
    return NextResponse.json({ received: true });
  } catch (err) {
    return NextResponse.json({ error: 'Webhook Error' }, { status: 400 });
  }
}
```

---

## Common Mistakes: The "AI Trap" List

1. **The "Hallucinated Library" Trap:** AI often suggests libraries that don't exist or use outdated syntax (e.g., using `axios` when your project uses `fetch`). 
   - *Fix:* Always include a "Tech Stack" block in your prompt.
2. **The "Logic Drift" Trap:** When coding a large file, the AI forgets the variable names defined at the top of the file.
   - *Fix:* Use the `@file` symbol in Cursor to force the AI to re-read the original file before generating new code.
3. **The "Security Blindness" Trap:** AI will often suggest code that skips authentication or validation to "make the code work."
   - *Fix:* Add a "Security Constraint" to your `.cursorrules`: *"Never suggest code that bypasses middleware or authentication checks."*
4. **The "Infinite Loop" Prompting:** Repeatedly asking "Why doesn't this work?" without providing more context.
   - *Fix:* If the AI fails twice, stop prompting. Manually find the error, and provide the error as a **Fact** in the next prompt.

---

## The Professional Developer's Checklist

Before you hit "Commit," run through this checklist for every AI-generated PR:

- [ ] **Context Check:** Did I use `@file` or `@folder` to ensure the AI saw the relevant interfaces?
- [ ] **Pattern Match:** Does the new code follow the existing folder structure and naming conventions?
- [ ] **Type Safety:** Did I check for any `any` types the AI might have introduced to "simplify" the code?
- [ ] **Error Handling:** Does the code include `try/catch` blocks and use our project's specific `AppError` class?
- [ ] **Dependency Audit:** Did the AI suggest a new `npm install`? If so, did I verify it is actually needed?
-   [ ] **Test Coverage:** Did I prompt the AI to generate a `.spec.ts` file for this specific change?
- [ ] **Security Check:** Is the Stripe/Auth/Database logic using the raw, unparsed input (where necessary) for signature verification?