# The AI-Augmented Engineer: A Professional Kit for High-Velocity Development

## Overview

The era of "writing code" is being replaced by the era of "orchestrating logic." This guide is not about how to use ChatGPT to write a Python script; it is about building a high-performance development workflow using Agentic IDEs (Cursor, Claude Dev/Cline) to handle complex architectural implementations.

The goal is to achieve a **70% reduction in boilerplate development time** and a **40% increase in test coverage** without increasing your technical debt. We move from a "manual typing" paradigm to a "Reviewer-in-the-Loop" paradigm.

### The Benchmark: Manual vs. AI-Augmented
In a controlled benchmark (implementing a standard CRUD API with JWT authentication and Zod validation):
*   **Manual Implementation:** 145 minutes (including boilerplate, error handling, and unit test writing).
*   **AI-Augmented Workflow:** 28 minutes (including prompt refinement, review, and debugging).
*   **Result:** 5.1x speed multiplier with higher test density.

---

## Tool Comparison: Choosing Your Engine

To build a professional workflow, you must select the right tool for the specific task. Using a general-purpose LLM (like the ChatGPT web interface) for coding is a mistake; you need tools with **Context Awareness.**

| Feature | **Cursor (IDE)** | **GitHub Copilot** | **Claude Dev / Cline (Agentic)** |
| :--- | :--- Fully integrated; indexes your entire codebase via RAG. | Autocomplete-focused; limited codebase awareness in standard mode. | Agentic; can run terminal commands, read files, and self-correct. |
| **Context Window** | High (Uses specialized indexing of local files). | Medium (Primarily focuses on open tabs). | Very High (Uses long-context models like Claude 3.5 Sonnet). |
| **Best Use Case** | Daily feature development and refactoring. | Rapid autocomplete and boilerplate "ghost text." | Complex, multi-file architectural shifts and migrations. |
| **Pros** | "Composer" mode can write across 10+ files simultaneously. | Seamless integration with GitHub ecosystem. | Can execute `npm test` and fix code based on terminal errors. |
| **Cons** | Proprietary ecosystem; requires switching IDEs from VS Code. | Lacks the "Agentic" ability to run terminal commands autonomously. | Higher token cost; requires careful monitoring of "looping" errors. |

---

## The Core Method: The "Context-Context-Constraint" (CCC) Framework

The primary reason AI coding fails is **Context Fragmentation.** If the AI doesn't know your existing utility functions, it will hallucinate new ones.

The **CCC Framework** involves three layers of input:
1.  **Context:** Explicitly pointing the AI to relevant files (e.g., `@auth.service.ts`, `@schema.prisma`).
2.  **Context:** Providing the architectural standard (e.g., "We use the Repository Pattern").
3.  **Constraint:** Defining what the AI *cannot* do (e.g., "Do not use `any` type; do not use deprecated `axios` interceptors").

### The `.cursorrules` Implementation
To automate the "Constraint" layer, you must use a `.cursorrules` (or `.clinerules`) file in your root directory. This acts as a permanent system prompt for your IDE.

**Example `.cursorrules` for a Next.js/TypeScript Project:**
```markdown
# Project Standards: Next.js 14 (App Router)

## Technical Stack
- Framework: Next.js 14 (App Router)
- Styling: Tailwind CSS
- State Management: Zustand
- Validation: Zod

## Coding Rules
1. Always use Server Components by default. Only use 'use client' when interactivity is required.
2. Data Fetching: Use `async/await` directly in Server Components. Avoid using `useEffect` for initial data fetching.
 Implemented patterns: Use the 'use' hook for promises.
3. Error Handling: Wrap all API routes in a standardized `try/catch` block that returns a `Result` type.
4. TypeScript: No `any`. Use `interface` for data models and `type` for unions.
5. Naming: Use PascalCase for components, camelCase for functions and variables.

## File Structure
- Components reside in `/components/ui` (atomic) or `/components/features` (complex).
- Logic/Utilities must be in `/lib`.
```

---

## Step by Step: The Implementation Workflow

### Step 1: The Blueprinting Phase
Before writing a single line of code, use a "Plan" prompt.
**Prompt:** `"I need to implement a Redis-backed caching layer for our User Service. Analyze `@user.service.ts` and `@redis.config.ts`. Propose a technical implementation plan before writing code."`

### Step 2: The Iterative Implementation
Once the plan is approved, use the **Prompt Evolution** technique (see Case Study below).

### Step 3: The Verification Loop
Never assume code works. Use the "Test-Driven Refinement" loop:
1.  Generate the code.
2.  Prompt the AI: `"Write a Vitest suite for the implementation above, covering edge cases like Redis connection timeout and cache miss."`
3.  Run tests in the terminal.
4.  If tests fail, use the Agentic tool to "Fix the failing tests in `@user.service.ts`."

---

## Case Study: Implementing a Redis Cache Layer

**Objective:** Implement a caching decorator for a Node.js service to prevent database hits on frequent user profile lookups.

### The Initial Failure (The "Bad" Prompt)
**Prompt:** `"Write a function to cache user data in Redis for our Node.js app."`

**Resulting Code (The Hallucination):**
```typescript
// ERROR: The AI assumes a generic structure that doesn't match the existing project.
// It uses 'ioredis' without checking if the project uses 'node-redis'.
// It fails to handle the serialization of complex objects.
export async function getCachedUser(userId: string) {
  const client = new Redis(); // Error: No connection logic or config injection
  const data = await client.get(`user:${userId}`);
  return JSON.parse(data); 
}
```
**Why it failed:** No context regarding the existing `RedisClient` singleton, no error handling for connection drops, and no consideration for the existing `User` interface.

### The Corrected Implementation (The "Good" Prompt)
**Prompt:** 
`"Using the existing `@redis.provider.ts` for the client instance and `@types/user.ts` for the interface, implement a caching decorator for the `getUserById` method in `@user.service.ts`. 
Constraints: 
1. Use a TTL of 3600 seconds. 
2. If Redis fails, fallback to the database (do not throw error). 
3. Use Zod to validate the cached data integrity upon retrieval. 
4. Implement the 'Result' pattern for error handling as defined in `@error-handler.ts`."`

**The Resulting Code (The "Professional" Output):**
```typescript
import { redis } from '@/lib/redis.provider';
import { User } from '@/types/user';
import { userSchema } from '@/lib/validation/user';
import { Result, err, ok } from '@/lib/result-pattern';

export async function getUserById(id: string): Promise<Result<User>> {
  const cacheKey = `user:cache:${id}`;

  // 1. Attempt Cache Retrieval
  try {
    const cachedData = await redis.get(cacheKey);
    if (cachedData) {
      const parsed = JSON.parse(cachedData);
      // Validate integrity with Zod to prevent poisoned cache attacks
      const validated = userSchema.parse(parsed);
      return ok(validated);
    }
  } catch (error) {
    console.error(`[Cache Error] Failed to fetch ${cacheKey}:`, error);
    // Fallback logic: Proceed to DB
  }

  // 2. Database Fallback
  try {
    const user = await db.user.findUnique({ where: { id } });
    if (!user) return err('User not found');

    // 3. Background Cache Update (Fire and forget)
    redis.set(cacheKey, JSON.stringify(user), 'EX', 3600)
      .catch(e => console.error('Cache write failed', e));

    return ok(user);
  } catch (dbError) {
    return err('Database error');
  }
}
```

---

## Debugging Hallucinations

AI models suffer from "Temporal Hallucination"—they often suggest syntax from older versions of libraries because that data was more prevalent in their training sets.

### Common Framework Hallucinations:
1.  **Next.js App Router vs. Pages Router:**
    *   *Hallucination:* Using `getServerSideProps` in a file inside the `app/` directory.
    *   *Fix:* Explicitly state: "Use Next.js 14 App Router conventions; do not use Pages Router hooks."
2.  **React 18 Concurrency:**
    *   *Hallucination:* Using `useLayoutEffect` for data fetching or failing to use `useTransition` for heavy UI updates.
    *   *Fix:* Provide a `.cursorrules` instruction regarding transition usage.
3.  **Zod/Prisma Mismatches:**
    *   *Hallucination:* Suggesting a Zod schema that doesn't match the Prisma schema types.
    *   *Fix:* Always include `@schema.prisma` in the context when generating validation logic.

---

## Checklist for AI-Generated Code Review

Before committing any AI-generated code, run through this checklist:

- [ ] **Context Check:** Did I include the relevant `@files` in the prompt?
- [ ] **Type Safety:** Are there any `any` types or `as unknown as T` assertions?
- [ ] **Error Boundary:** Does the code handle a failed dependency (e.g., Redis, API, DB) without crashing the process?
- [ ] **Security:** Did the AI introduce an injection vulnerability or use `dangerouslySetInnerHTML`?
- [ ] **Pattern Alignment:** Does this code follow the patterns defined in my `.cursorrules`?
- [ ] **Test Coverage:** Have I prompted the AI to write a corresponding Vitest/Jest test?
- [ ] **Performance:** Did the AI introduce an $O(n^2)$ loop or a redundant database call inside a `map` function?