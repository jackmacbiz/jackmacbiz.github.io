# The AI-Augmented Engineer: Prompt Engineering & Workflow Architect

## Introduction: The Paradigm Shift
The era of "manual typing" is ending. The transition from a traditional developer to an AI-Augmented Engineer requires moving from a *writer* of code to an *architect* of intent. This guide provides the technical blueprints to reduce boilerplate by 70% and move your focus from syntax to system design.

---

## 1. The Anatomy of a Perfect Coding Prompt
A generic prompt like "Write a function to handle user auth" yields generic, insecure, and unoptimized code. To achieve professional-grade output, you must use **Structured Intent Modeling**.

### The S.C.O.P.E. Framework
Every high-stakes prompt must contain these five elements:
1.  **S**ubject: The specific component or module.
2.  **C**ontext: The tech stack, version, and existing dependencies.
3.  **O**bjectives: Explicit functional requirements.
4.  **P**arameters: Constraints (e.g., "No external libraries except `zod`", "Must be O(n) complexity").
5.  **E**xpected Output: The format (e.g., "TypeScript interface followed by the implementation").

### Example: The "Professional Grade" Prompt
**Bad:** "Write a React component for a data table."

**Good (S.C.O.P.E.):**
> **Subject:** A React `DataTable` component using Tailwind CSS and TanStack Table v8.
> **Context:** This is part of a Next.js 14 App Router project using TypeScript. Users are authenticated via NextAuth.
> **Objectives:** Implement server-side pagination, column sorting, and a search filter. The component must handle loading states with a skeleton UI.
> **Parameters:** Use `useQuery` from `@tanstack/react-query` for data fetching. Do not use any third-party UI libraries except Headless UI. Ensure the component is accessible (ARIA labels).
> **Expected Output:** Provide the `DataTable.tsx` file, the `types.ts` definition, and a brief explanation of the custom hook used for pagination logic.

---

## 2. Context Window Management: Feeding Documentation and Schemas
The "Context Window" is your most precious resource. If you flood the LLM with irrelevant files, you induce "Lost in the Middle" syndrome, where the model ignores critical instructions.

### The Token Budgeting Strategy
When working with large repos, you cannot paste everything. You must implement **Hierarchical Context Loading**.

**Step 1: The Structural Overview**
Before sharing code, provide the directory structure. Use a filtered tree command to avoid bloating the context with `node_modules` or `.git`.
```bash
# Use this command to generate a clean structural context for the LLM
tree -I 'node_modules|dist|.git|build|*.log|*.pyc' -L 3 > project_structure.txt
```

**Step 2: The Schema-First Approach**
Instead of providing logic, provide the *shapes*. If you are asking for a new API endpoint, provide the `Prisma` schema or the `Zod` validation objects first. This defines the "boundaries" of the logic without consuming thousands of tokens on implementation details.

**Step 3: Token-Count Math for Large Files**
If a file exceeds 2,000 tokens (roughly 1,500 words), do not paste the whole file. Use **Skeletonization**:
1.  Extract only the function signatures and interface definitions.
2.  Replace the function bodies with `// ... implementation logic ...`.
3.  Input this "Skeleton" file to the LLM so it understands the interface without the noise.

---

## 3. Advanced RAG for Local Codebases
Retrieval-Augmented Generation (RAG) is how you allow an LLM to "know" your entire codebase. For an engineer, this means building a local index of your repository.

### Building a Local Embedding Index
To move beyond simple copy-pasting, you can use tools like `ChromaDB` or `LanceDB` to index your local files.

**Implementation Workflow:**
1.  **Chunking:** Break your `.ts` and `.py` files into chunks of ~500 tokens with a 50-token overlap.
2.  **Embedding:** Use a local model (like `all-MiniLM-Lax-L6-v2`) via `sentence-transformers` to turn these chunks into vectors.
3.  **Querying:** When you ask, "How do we handle JWT expiration?", the system performs a similarity search against your vector index and pulls only the relevant `auth-middleware.ts` snippet into the context window.

**Pro-Tip:** Use **`grep-ast`** or **`tree-sitter`** to chunk code by *logical nodes* (functions/classes) rather than arbitrary character counts. This ensures a function is never "cut in half" during the embedding process.

---

## 4. Automated Unit Test Generation Strategies
Do not ask the AI to "write tests." Ask it to "Generate a test suite that achieves 100% branch coverage for the following edge cases."

### The "Triple-Pass" Testing Workflow
1.  **Pass 1: The Happy Path:** Generate tests for standard, successful inputs.
2.  **Pass 2: The Boundary/Edge Case Pass:** Explicitly prompt: *"Analyze the provided function for off-by-one errors, null/undefined inputs, and integer overflow. Generate Vitest test cases for these specific scenarios."*
3.  **Pass 3: The Mutation Pass:** Feed the generated tests back to the LLM and ask: *"Given these tests, what logic could I change in the source code to make a test fail? If no change makes a test fail, identify the uncovered code paths."*

---

## 5. Refactoring Legacy Code with LLM-Driven Analysis
Refactoring is high-risk. Use the **"Shadow Implementation"** pattern.

### The Workflow:
1.  **Analysis Phase:** Prompt the LLM: *"Identify all side effects and hidden dependencies in this function. List them in a markdown table with columns: Dependency, Impact, and Risk Level."*
2.  **Contract Definition:** Before changing code, ask the LLM to write a `Zod` schema that validates the *current* output of the legacy function.
3.  **Refactor:** Prompt: *"Rewrite this function to use the dependency injection pattern, ensuring it adheres to the Zod schema defined previously."*
4.  **Verification:** Run the new code through the same test suite used for the legacy code.

---

## 6. Debugging Loops: Using AI to Trace and Fix Logic Errors
Never use an LLM to "fix" code in a single step. Use the **Automated Linting & Execution Loop**.

### The "Self-Correction" Script
Create a shell script that wraps your test runner and an LLM CLI (like `aider` or `mods`).

**Example `debug_loop.sh`:**
```bash
#!/bin/bash
# Automated Debugging Loop Script

# 1. Run the tests
npm test > test_results.log 2>&1
TEST_STATUS=$?

if [ $TEST_sSTATUS -eq 0 ]; then
  echo "✅ Tests Passed!"
  exit 0
else
  echo "❌ Tests Failed. Initiating AI Debugging..."
  
  # 2. Extract the error from the log
  ERROR_CONTEXT=$(tail -n 20 test_results.log)
  
  # 3. Feed error and relevant file to LLM (using 'mods' CLI tool)
  # Assumes you have the source file 'src/logic.ts'
  cat src/logic.ts | mods "The following test failed with this error: $ERROR_CONTEXT. 
  Identify the logic error and provide a one-line fix using 'sed' or a rewritten function." > fix_suggestion.diff
  
  # 4. Apply the fix
  patch -p1 < fix_suggestion.diff
  
  echo "🛠 Fix applied. Re-running tests..."
  npm test
fi
```

---

## 7. Integrating AI Agents into your Local IDE Workflow
To maximize speed, you must move from "Chatting" to "Agentic Orchestration." This involves configuring your IDE (Cursor, VS Code with Copilot) to follow strict rules.

### The `.cursorrules` Configuration
The `.cursorrules` file (or `.windsurfrules`) is the "System Prompt" for your entire repository. It acts as a permanent instruction set.

**Example `.cursorrules` for a TypeScript/Node Project:**
```markdown
# Project Standards: Node.js/TypeScript

## Coding Style
- Use functional programming patterns; avoid `class` where `const` and functions suffice.
- Always use `Zod` for runtime validation of all incoming API payloads.
- Prefer `interface` over `type` for object definitions.

## Error Handling
- Never use `try/catch` blocks that swallow errors. 
- Every catch block must log to our internal `Logger` utility.
- Use the `Result` pattern (e.g., `{ success: true, data: T } | { success: false, error: E }`) for complex business logic.

## Testing Requirements
- Every new utility function must have a corresponding `.spec.ts` file.
- Use `msw` (Mock Service Worker) to mock all network requests in tests.

## Documentation
- All exported functions must have JSDoc comments including `@param` and `@returns`.
```

---

## 8. Security & Privacy: Sanitizing Code for LLM Input
The greatest risk to an engineer is "Data Leakage."

### The Sanitization Protocol
Before sending a snippet to a cloud-based LLM (OpenAI, Anthropic):
1.  **Regex Scrubbing:** Run a script to replace hardcoded secrets (API keys, DB strings) with placeholders like `{{STRIPE_KEY_REDACTED}}`.
2.  **PII Removal:** Ensure no real user data (emails, names) is present in your mock data payloads.
3.  **Structure-Only Mode:** If the logic is highly proprietary, use the **Skeletonization** technique described in Section 2. Send the *interface*, not the *implementation*.

---

## 9. Building Custom System Prompts for Specific Frameworks
Generic prompts fail because they don't understand framework-specific "gotchas" (e.g., React's `useEffect` dependency array or Next.js Server Components vs. Client Components).

### The "Framework-Aware" Prompt Template
When working in a specific framework, prepend your prompt with a **Framework Constraints Block**:

> **Framework Context:** Next.js 14 (App Router).
> **Constraint 1:** This is a Server Component. Do not use `useState` or `useEffect`.
> **Constraint 2:** Use `fetch` with the `cache: 'no-store'` option for real-time data.
> **Constraint 3:** Use `zod` for validating `searchParams`.

By explicitly defining the *boundary* of the framework, you prevent the LLM from suggesting code that will cause runtime errors (like trying to use Browser APIs in a Server Component).

---

## Case Study: The "Refactor-to-Type-Safe" Workflow

**The Problem:** A legacy JavaScript function handles user permissions but lacks validation, leading to frequent `undefined` errors in production.

**Step 1: The Prompt (Analysis)**
*Prompt:* "Analyze this JS function. Identify where it fails if `user.role` is missing or if `permissions` is not an array. Provide a Zod schema to wrap this input."

**Step 2: The Intermediate Error**
The LLM suggests a fix, but the fix uses a library (`ajv`) that isn't in our project.
*User Action:* "Reject. Use `zod` only. Ensure the schema is compatible with our existing `User` interface."

**Step 3: The Final Fix**
The LLM provides:
1.  A `zod` schema.
2.  A TypeScript interface.
3.  The refactored function:
```typescript
import { z } from 'zod';

const PermissionSchema = z.object({
  role: z.enum(['admin', 'editor', 'viewer']),
  permissions: z.array(z.string()),
});

export type PermissionInput = z.infer<typeof PermissionSchema>;

export const checkAccess = (input: unknown): boolean => {
  const result = PermissionSchema.safeParse(input);
  if (!result.success) return false;
  
  const { role, permissions } = result.data;
  return permissions.includes('read_access');
};
```
**Result:** The refactor is type-safe, validated at runtime, and uses our existing stack, reducing the "undefined" error surface area by 100% for that module.