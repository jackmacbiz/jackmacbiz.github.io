# The AI-Driven Engineer: Workflow Architect Kit

## The AI-First Mental Model: Moving from Syntax to Logic

The transition from a traditional developer to an AI-Orchestrator requires a fundamental shift in cognitive load. In the manual era, 80% of your energy was spent on syntax, boilerplate, and API-specific implementation details. In the AI-driven era, syntax is a commodity. Your value resides in **Architectural Intent**.

To 10x your output, you must stop writing code and start writing **Specifications of Intent**. This involves moving from "How to implement" to "What the system must guarantee."

**The Cognitive Shift:**
*   **Old Model:** Writing a `for` loop to filter a list of users based on age.
*   **New Model:** Defining the invariant properties of the `User` filtering service and the edge cases for the boundary conditions (e.g., null handling, timezone shifts).

You are no longer a bricklayer; you are the building inspector. Your primary tool is no longer the keyboard, but the **Logical Constraint**.

---

## Prompt Engineering for Complex Refactoring: The Contextual Transformation Framework

Generic prompting (e.g., "Refactor this function") leads to "hallucinated elegance"—code that looks clean but breaks subtle dependencies. To perform complex refactoring, use the **Contextual Transformation Framework (CTF)**.

### The CTF Framework
A high-quality refactoring prompt must contain four distinct layers:
1.  **The Source Anchor:** The raw code block.
2.  **The Structural Blueprint:** The target design pattern (e.g., Strategy Pattern, Dependency Injection).
3.  **The Constraint Set:** Explicit "do nots" (e.g., "Do not introduce external dependencies," "Maintain O(n) complexity").
4.  **The Semantic Reference:** The specific documentation or interface definitions that the new code must adhere to.

### Case Study: Refactoring a Monolithic Python Function

**Before (The "Spaghetti" Function):**
```python
def process_order(order, user, db_session):
    if order.status == 'pending':
        if user.is_active:
            tax = 0.05 if user.region == 'US' else 0.15
            total = order.amount + (order.amount * tax)
            order.total = total
            # Update database
            query = f"UPDATE orders SET total = {total} WHERE id = {order.id}"
            db_session.execute(query)
            # Send email
            send_email(user.email, "Order Processed", f"Total: {total}")
            order.status = 'processed'
        else:
            raise Exception("Inactive user")
    return order
```
*Issues: SQL Injection vulnerability, hardcoded tax logic, tight coupling to email service, and lack of transaction atomicity.*

**The Prompt (Using CTF):**
> **Role:** Senior Backend Engineer.
> **Task:** Refactor the provided `process_order` function.
> **Reference Pattern:** Implement the Strategy Pattern for tax calculation based on `user.region`.
> **Constraints:** 
> 1. Use SQLAlchemy ORM instead of raw SQL strings to prevent injection.
> 2. Extract the email logic into a `NotificationService` interface.
> 3. Ensure the database update and status change are wrapped in a single ACID transaction.
> 4. Maintain the existing function signature for backward compatibility.
> **Source:** [Insert Code Block Above]

**After (The Orchestrated Output):**
```python
def process_order(order, user, db_session, tax_strategy: TaxStrategy, notifier: NotificationService):
    try:
        with db_session.begin():
            tax_amount = tax_strategy.calculate(order.amount, user.region)
            order.total = order.amount + tax_amount
            order.status = 'processed'
            
            # Using ORM to prevent SQL Injection
            db_session.add(order)
            
            notifier.send_order_confirmation(user.email, order.total)
    except Exception as e:
        db_session.rollback()
        logger.error(f"Order processing failed: {e}")
        raise OrderProcessingError(str(e))
    return order
```

---

## Automated Unit Test Generation Strategies

The greatest risk of AI-generated code is the "silent failure"—code that runs but fails on edge cases. To mitigate this, do not ask the AI to "write tests." Ask it to **"generate a test suite based on a Boundary Value Analysis (BVA) matrix."**

### Implementation Strategy:
1.  **Input Analysis:** Extract the function's input types and constraints.
2.  **Edge Case Matrix Generation:** Instruct the LLM to generate a table of inputs including `None`, `0`, `MAX_INT`, empty strings, and malformed JSON.
3.  **Test Implementation:** Use a tool like `pytest` and instruct the LLM to use `hypothesis` (Property-Based Testing) to automate the discovery of failing inputs.

**Prompt Example:**
> "Analyze the `process_order` function. Generate a `pytest` suite using `hypothesis`. Specifically, create a strategy for the `order.amount` field to test for negative values, zero, and extremely large floats. Ensure you include a test case for a database connection timeout."

---

## Integrating LLMs into the CI/CD Pipeline: The Linter-in-the-Loop

To scale, you must move LLM verification from your local IDE to the CI/CD pipeline. We implement a **Linter-in-the-Loop** pattern.

### The Workflow:
1.  **Standard Linting:** Run `Ruff` or `ESLint` to catch syntax/style errors.
2.  **LLM-Based Semantic Review:** A GitHub Action triggers a script that sends the `git diff` to an LLM (via OpenAI/Anthropic API).
3.  **Feedback Loop:** The LLM analyzes the diff specifically for **Logical Regressions** and **Security Vulnerabilities**.
4.  **Automated Commenting:** The results are posted as a PR comment.

**The Implementation Pattern (GitHub Actions Example):**
```yaml
jobs:
  ai-review:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
        with:
          fetch-depth: 2
      - name: AI Semantic Review
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
        run: |
          git diff HEAD^ HEAD > diff.patch
          python scripts/ai_reviewer.py diff.patch
```
*The `ai_reviewer.py` script should utilize a system prompt that focuses solely on "logic-altering changes" to avoid noise.*

---

## Debugging and Error Resolution via Context Injection

Standard debugging is reactive. AI-driven debugging is proactive through **Context Injection**.

When an error occurs, do not just paste the stack trace. You must provide the **execution context**.

### Advanced Context Injection Technique:
Instead of raw text, use **Symbolic Context Extraction**. If you are using a tool like `Continue.dev` or `Cursor`, you should leverage `tree-sitter` or similar AST-based parsing to feed the LLM only the relevant symbols.

**The Injection Hierarchy:**
1.  **The Error:** The stack trace and the specific error message.
2.  **The Local Scope:** The variables currently in scope during the crash.
3.  **The Dependency Context:** The interface definitions of the libraries involved (e.g., the specific SQLAlchemy model definition).
4.  **The Recent History:** The last 3 commits related to this file.

**Pro-Tip: Avoid "Token Bloat"**
Never paste an entire library's source code. Use a script to extract only the **Class Signatures** and **Method Docstrings** of the dependencies. This provides the LLM with the "What" without overwhelming the context window with the "How."

---

## Managing Context Windows and Token Efficiency

The "Context Window" is your most expensive and limited resource. Overloading it leads to "Lost in the Middle" syndrome, where the LLM ignores instructions in the center of a long prompt.

### The Token Budgeting Strategy:
*   **Summarization Triage:** Before sending a large file, use a "Summarizer Prompt" to create a compressed version of the file containing only function signatures and logic summaries.
*   **RAG-based Code Retrieval:** For large repositories, use a local RAG (Retrieiring Augmented Generation) setup. When a bug is reported in `auth.py`, your system should search for `auth.py` + `database_schema.sql` + `user_model.py` and only inject those three files.
*   **AST-based Pruning:** Use a Python script to parse your code into an Abstract Syntax Tree (AST). Strip out all comments, docstrings, and implementation details, leaving only the structure. This can reduce token usage by up to 60% without losing the structural logic.

---

## The Cost of Hallucination: The Three-Point Audit

LLMs are prone to **Subtle Logic Hallucination**. A classic example is the "SQLAlchemy Query Hallucination," where the LLM suggests a method like `.filter_by_id()` which does not exist in the current version of the library, or worse, suggests a query that is syntactically correct but logically flawed (e.g., forgetting an `.order_by()` in a pagination query).

### The Three-Point Audit (3PA)
To prevent shipping hallucinations, every AI-generated block must pass the 3PA:

1.  **Syntactic Audit (The Linter):** Does the code pass `mypy` and `ruff`? If it fails type checking, the hallucination is caught.
2.  **Contract Audit (The Interface):** Does the generated code call methods that actually exist in the current version of the dependency? (Cross-reference with the `requirements.txt` or `pyproject.toml`).
3.  **Invariant Audit (The Test):** Does the code pass the "Boundary Value Analysis" tests generated in the previous section?

---

## Automated Agentic Workflows: Moving to Autonomy

The final stage of evolution is using **Agentic Workflows** like **Aider** or **OpenDevin**. These are not just "chatbots"; they are CLI-driven agents that can execute terminal commands, read files, and apply edits.

### Implementation with Aider:
Aider allows yous to work on a "Chat-with-your-code" loop that manages git commits automatically.

**Workflow Example:**
1.  **Initialize:** `aider --model gpt-4o`
2.  **Tasking:** `/add src/models.py src/services/order_service.py`
3.  **Instruction:** "Refactor the order service to use the new tax strategy pattern. Ensure you create a new file `src/strategies/tax_strategies.py` and update the imports."
4.  **Execution:** Aider will analyze the files, write the code, run the `git commit` command, and present a diff.

**The Agentic Command Pattern:**
Use a shell script to chain Aider commands for repetitive tasks:
```bash
# Refactor all deprecated functions in a single command
aider --message "Scan all files in src/ and replace deprecated call 'old_api()' with 'new_api_v2()'. Run pytest after every change."
```

---

## Building Custom GPTs for Domain-Specific Code Standards

Generic LLMs do not know your company's specific "Internal Standard for Error Handling." To solve this, you must build a **Domain-Specific Coding Agent**.

### The Configuration Blueprint:
Create a `custom_instructions.md` file and use it as the "Knowledge Base" for your Custom GPT or Claude Project.

**Your Knowledge Base should contain:**
*   **The "Definition of Done":** (e.g., "All new functions must have type hints and a Google-style docstring.")
*   **The "Forbidden Patterns":** (e.g., "Never use `os.path`; always use `pathlib`.")
*   **The "Architecture Map":** A high-level description of how modules interact (e.g., "The `Services` layer must never call the `Controllers` layer; it can only call `Repositories` or `External APIs`.")

By injecting these standards into the LLM's core identity, you transform the AI from a generic coder into a **Senior Staff Engineer** who understands your specific codebase's DNA.