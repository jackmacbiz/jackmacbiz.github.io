# The AI-Augmented Engineer: Architecting Production-Ready Code with LLMs

## Introduction: The Shift from Coder to Orchestrator

The era of "writing code" is being replaced by the era of "reviewing logic." To achieve 10x velocity, you cannot treat an LLM as a better version of Google; you must treat it as a highly capable, yet context-blind, Junior Engineer. This guide teaches you how to move from manual typing to high-level architectural orchestration.

---

## 1. The Prompt Engineering Framework for Complex Logic

Standard prompting (e.g., "Write a function to handle user auth") fails in production because it lacks architectural constraints. To build production-ready code, you must use the **Constraint-Driven Specification (CDS)** framework.

### The CDS Framework
A professional prompt must contain four pillars:
1.  **Role & Context:** Define the persona (e.g., "Senior Backend Engineer specializing in Go and microservices").
2.  **Structural Constraints:** Define the patterns (e.g., "Use the Repository Pattern and ensure dependency injection").
3.  **Type Safety Requirements:** Explicitly demand strict typing (e.g., "Use Zod for runtime validation and TypeScript interfaces for static types").
4.  **Error Handling Protocol:** Define how failures are handled (e.g., "Wrap all DB calls in a Result type pattern").

### Deep Dive: The Interface-First Method
When tackling a new feature, never ask for the implementation first. Ask for the interface. This allows you to verify the architecture before the LLM generates 200 lines of potentially flawed logic.

**Example Workflow:**
*   **Step 1 (The Blueprint):** 
    *   *Prompt:* "I am building a multi-tenant subscription service. Based on the following requirements [Insert Requirements], generate only the TypeScript interfaces and the DTO (Data Transfer Object) definitions. Do not write implementation logic. Ensure all IDs are `string` (UUID format) and include timestamps for `createdAt` and `updatedAt`."
*   **Step 2 (The Implementation):**
    *   Once the interfaces are approved, use them as the context for the implementation prompt. This ensures the generated code *must* adhere to the pre-validated types.

**Pro-Tip: The "Negative Constraint" String**
To prevent the LLM from using deprecated libraries, use this string at the end of every prompt:
`"CONSTRAINT: Do not use 'axios'; use the native 'fetch' API. Do not use 'any'; all types must be explicitly defined. If a type is unknown, use 'unknown' instead of 'any'."`

---



## 2. Context Window Management: Feeding the LLM the Right Files

The biggest bottleneck in AI coding is "context drift"—where the LLM loses track of the project structure. You cannot simply dump your entire codebase into a prompt. You must curate the **Minimal Viable Context (MVC)**.

### The "Skeleton" Strategy
Instead of providing full files, provide a "Skeleton" of your project. This gives the LLM the map without the noise.

**Example Project Structure & Context Injection:**
Imagine a complex Next.js project. Instead of uploading `api/users/route.ts`, you provide a summarized tree:

```text
// Context: Project Structure Summary
src/
  ├── lib/
  │   ├── db.ts (Prisma client instance)
  │   └── auth.ts (NextAuth configuration)
  ├── types/
  │   └── user.ts (User interface definition)
  └── app/
      └── api/
          └── users/
              └── route.ts (Handler logic)
```

### Deep Dive: The "Interface-Only" Context Injection
When you need the LLM to write a new service, do not provide the implementation of the existing services. Provide only their signatures.

**The Prompt Template:**
`"I am working in the following codebase. Here are the relevant type definitions and method signatures from my existing services: [Paste Interface Definitions]. Now, implement a new service `OrderService` that utilizes the `UserRepository` interface defined above."`

**Pro-Context Tooling: `.cursorrules` Configuration**
If using Cursor, use a `.cursorrules` file to automate context.
**Example `.cursorrules` content:**
```markdown
# Core Principles
- Always use functional programming patterns.
- Prefer composition over inheritance.

# Tech Stack Specifics
- Use Zod for all API request validation.
- Use Tailwind CSS for styling; never use inline styles.
- All database queries must use the Prisma 'include' syntax to prevent N+1 problems.

# Error Handling
- Every async function must be wrapped in a try/catch block that logs to our internal 'Logger' utility.
```

---

## 3. Automated Unit Test Generation and Edge Case Discovery

AI is exceptionally good at "hallucinating" edge cases if you frame the prompt correctly. Do not ask it to "write tests." Ask it to "perform a failure-mode analysis."

### The Failure-Mode Prompting Technique
Instead of: *"Write unit tests for this function."*
Use: *"Analyze this function for potential edge cases, including null inputs, extremely large integers, and malformed UTF-8 characters. Once identified, generate Vitest unit tests that specifically target these failure modes using the Arrange-Act-Assert pattern."*

### Deep Dive: The Property-Based Testing Workflow
Use the LLM to generate inputs for property-based testing (e.g., using `fast-check`).

**The Workflow:**
1.  **Input:** Provide the function logic.
2.  **Prompt:** `"Identify the invariants in this function (e.g., 'output must always be a positive integer'). Then, write a `fast-check` property test that attempts to falsify these invariants using randomized inputs."`

**Pro-Tip: The "Red-Green-Refactor" Prompt**
Use this to ensure test-driven development (TDD):
`"First, write a failing test case for a scenario where the user's balance is exactly zero. Do not write the implementation yet. I will then provide the implementation, and you will verify if the test passes."`

---

## 4. Refactoring Legacy Codebases using Agentic Workflows

Refactoring is not a single prompt; it is an iterative loop. An "Agentic Workflow" involves an LLM acting as a "Coder" and then a "Reviewer" in a loop.

### The Refactoring Loop (The "Critic" Pattern)
1.  **Step 1 (Analyze):** Prompt the LLM to identify "code smells" in the legacy block.
2.  **Step 2 (Execute):** Prompt the LLM to rewrite the code based on those smells.
3.  **Step 3 (Verify):** Feed the new code back into a *different* LLM instance (or a fresh chat) to act as a Critic.

### Case Study: Refactoring a "God Function"
**Legacy Code (The "Before"):**
```typescript
// A monolithic, untyped, and untestable function
async function processOrder(order: any) {
  if (order.status === 'pending') {
    const user = await db.user.findUnique({ where: { id: order.userId } });
    if (user.balance >= order.amount) {
      await db.user.update({ where: { id: user.id }, data: { balance: user.balance - order.amount } });
      await db.order.update({ where: { id: order.id }, data: { status: 'paid' } });
      await emailService.send(user.email, "Order Paid");
    } else {
      throw new Error("Insufficient funds");
    }
  }
}
```

**The Agentic Refactoring Prompt:**
`"Analyze the provided `processOrder` function. Identify violations of the Single Responsibility Principle. Specifically, look for: 1. Tight coupling to the database, 2. Lack of type safety, 3. Side effects (email) mixed with logic. Propose a refactored version using the Command Pattern and Zod for input validation."`

**AI-Refactored Version (The "After"):**
```typescript
import { z } from 'zod';

const OrderSchema = z.object({
  id: z.string().uuid(),
  userId: z.string().uuid(),
  amount: z.number().positive(),
});

type OrderInput = z.infer<typeof OrderSchema>;

class PaymentService {
  async execute(order: OrderInput): Promise<void> {
    // Logic is now decoupled from the controller
    // Errors are caught via standardized Result types
  }
}
```

---

## 5. Integrating AI into the CI/CD Pipeline

To scale, AI must move from your IDE to your pipeline. This transforms AI from a "coding assistant" to an "automated gatekeeper."

### Automated PR Summarization & Review
Integrate LLMs via GitHub Actions to perform "Semantic Code Reviews."

**Implementation Strategy:**
1.  **Action Trigger:** On `pull_request` event.
2.  **Diff Extraction:** Use `git diff` to extract changed lines.
3.  **LLM Analysis:** Send the diff to an LLM with a specialized "Reviewer" prompt.

**The Reviewer Prompt (System Prompt):**
`"You are a Senior Security Engineer. Review the following git diff. Your goal is to identify: 1. Logic errors, 2. Potential SQL injection vulnerabilities, 3. Hardcoded secrets. Output your findings in a Markdown table with columns: [File, Line, Severity, Description, Suggested Fix]."`

### Deep Dive: The "Automated Regression" Pipeline
Use an LLM to generate a "Regression Test Suite" every time a PR is opened.
**The Workflow:**
*   **Input:** The `git diff` of the PR.
*   **Task:** "Based on these changes, identify which existing unit tests are now insufficient and write the code for three new test cases that cover the modified logic."

---

## 6. Security Auditing: Identifying Vulnerabilities in AI-Generated Code

The greatest risk of AI-augmented engineering is "blind trust." AI-generated code often looks syntactically perfect but is logically insecure.

### The "Adversarial Prompting" Audit
When you generate code, you must immediately subject it to an adversarial prompt.

**The Audit Prompt:**
`"I have just generated this code using an LLM. Act as a malicious actor attempting to exploit this specific implementation. Identify: 1. Replay attack vectors, 2. Insecure Direct Object Reference (IDOR) vulnerabilities, 3. Potential for Denial of Service (DoS) via resource exhaustion. Provide a proof-of-concept (PoC) exploit description for each."`

### Deep Dive: Checking for "Hallucinated Dependencies"
LLMs often suggest libraries that do not exist or are outdated.
**The Verification Step:**
Before committing AI-generated code, run a script that checks all new `npm install` or `pip install` commands against a real-world registry.

**Pro-Tip: The Dependency Audit Prompt**
`"Review the following `package.json` changes. For every new dependency added, verify if it is a well-maintained package with a high download count and no known critical vulnerabilities (CVEs). If a package looks suspicious or is a common 'typosquatting' target, flag it."`

---

## 7. Building Custom GPTs and System Prompts for Specific Tech Stacks

The final stage of mastery is building your own "Domain-Specific AI." You should not be prompting from scratch for every task. You should have a library of "System Prompts" tailored to your stack.

### The "Stack-Specific" GPT Configuration
If you are a Full-Stack Engineer specializing in the T3 Stack (Next.js, tRPC, Prisma, Tailwind), create a specialized System Prompt.

**Example System Prompt for a "T3 Engineer GPT":**
```text
# Role
You are an expert T3 Stack Developer.

# Contextual Constraints
- Always use tRPC for API layers; never use standard REST endpoints unless requested.
- Use Prisma for all database interactions; prioritize type-safety.
- Use Tailwind CSS for all styling; use the 'cn()' utility for class merging.
- All server actions must be wrapped in a 'safeAction' wrapper that handles error logging.

# Output Format
- Provide code in complete, copy-pasteable blocks.
- Always include the necessary 'import' statements.
- If a change requires a migration, provide the `npx prisma migrate dev` command.
```

### Deep Dive: The "Context-Aware" Prompt Library
Maintain a `prompts/` directory in your repository. This allows your team to use the exact same "Architectural DNA" when generating code.

**Structure of a Prompt Library:**
- `prompts/feature/new-api-endpoint.md`
- `prompts/refactor/convert-to-hooks.md`
- `prompts/test/generate-integration-test.md`

By standardizing these prompts, you ensure that as your team grows, the "AI-Augmented" velocity remains consistent and the code quality remains high.