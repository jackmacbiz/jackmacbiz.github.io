# The AI-Augmented Engineer: Prompt Engineering & Workflow Automation for Rapid Development

## Introduction: The New Velocity Paradigm
The transition from "Writing Code" to "Reviewing Code" is the defining shift of the modern engineering era. This guide is not about using ChatGPT to write `print("hello world")`. It is about re-engineering your cognitive workflow to treat LLMs as high-throughput, low-latency junior engineers that you manage via structured prompting, agentic loops, and automated verification.

---

## 1. The LLM Architecture: Context Windows and Token Management
To automate effectively, you must treat the LLM's context window as a finite, expensive memory resource.

### The "Context Exhaustion" Problem
When you feed an entire repository into an LLM, you encounter two failures:
1.  **Lost in the Middle:** LLMs exhibit degraded performance when critical information is buried in the center of a long prompt.
2.  **Token Drift:** As the context fills, the model loses the ability to adhere to strict syntax rules (e.g., forgetting a closing brace in a 4000-line context).

### Strategy: The "Skeleton-First" Context Injection
Instead of providing full files, provide a **Symbol Map**.
*   **Step 1:** Use `ctags` or a script to extract only class signatures and function decorators.
*   **Step 2:** Inject this "Skeleton" into the prompt.
*   **Step 3:** Only provide the full implementation of the specific function being modified.

**Technical Metric: Execution Time Comparison (CRUD Module Generation)**
| Task Component | Manual Implementation (Est.) | AI-Augmented (Est.) | Delta |
| :--- | :--- | :--- | :--- |
| Model/Schema Definition | 25 mins | 2 mins | -92% |
| Pydantic/Validation Logic | 30 mins | 4 mins | -86% |
| CRUD Controller Logic | 45 mins | 6 mins | -86% |
| Unit Test Scaffolding | 40 mins | 5 mins | -87% |
| **Total Per Module** | **140 mins** | **17 mins** | **~88% Reduction** |

---

## 2. Advanced Prompt Engineering: Structured Templates
Forget "Write a function for X." Use **Role-Prompted Structural Templates**.

### Template: Context-Aware Dependency Injection
Use this template when asking the LLM to implement a new service that must adhere to existing architectural patterns.

```markdown
### ROLE
You are a Senior Backend Engineer specializing in Clean Architecture and Dependency Injection.

### ARCHITECTURAL CONTEXT
- Framework: FastAPI
- Pattern: Repository Pattern
- Dependency Container: python-dependency-injector
- Existing Interface: `IUserRepository(ABC)`

### TASK
Implement a new `UserService` that utilizes `IUserRepository`.

### CONSTRAINTS
1. Do not instantiate classes directly; use the `Provide` pattern.
2. Ensure all methods are asynchronous (`async def`).
 3. Follow the existing error handling pattern found in `src/errors.py`.

### INPUT CODE (Interface Only)
[PASTE INTERFACE HERE]

### OUTPUT REQUIREMENT
Return only the Python code block. No conversational filler.
```

### Template: Chain-of-Thought (CoT) for Complex Logic
When dealing with multi-step algorithmic transformations (e.g., migrating a data structure), force the model to "think" in a scratchpad before generating code.

**Prompt Structure:**
1. **Analyze:** Identify the input/output schema.
2. **Trace:** Map the transformation steps of each field.
3. **Edge Cases:** List potential null/empty/overflow risks.
4. **Code:** Generate the implementation.

---

## 3. Agentic Workflows: Managing the "Skeleton Approach" with Aider and Cursor
The "Skeleton Approach" involves managing a high-level architecture (the skeleton) and delegating implementation (the meat) to an agent.

### Using Aider for Iterative Refactoring
[Aider](https://aider.chat/) is a CLI tool that allows LLMs to edit your local files directly. To use the Skeleton Approach:
1.  **Initialize:** `aider --model gpt-4o`
2.  **The Architect Command:** Instead of asking for a feature, ask Aider to "Create the interface definitions for a new payment gateway in `interfaces/payment.py`."
3.  **The Implementation Loop:** Once the interface exists, point Aider to the implementation: `aider interfaces/payment.py src/services/stripe_service.py`.

### Using Cursor for "Composer" Mode
In Cursor, use the **@Codebase** symbol. To prevent hallucinations during large refactors:
1.  **Index the codebase:** Ensure Cursor has finished indexing.
2.  **Prompting via Files:** Use `Ctrl+L` and type: `@Codebase @file_a.py @file_b.py Refactor the logic in file_a to use the new utility in file_b, ensuring type safety.`

---

## 4. The Debugging Loop: Identifying and Patching Regressions
Use the **"Trace-Prompt-Verify"** loop to fix bugs without introducing new ones.

**The Workflow:**
1.  **Capture Traceback:** Copy the full stack trace.
2.  **Contextual Injection:** Provide the traceback + the suspected function + the relevant interface.
3.  **Prompt Template (The Fixer):**
    ```markdown
    ### ERROR REPORT
    [PASTE TRACEBACK]

    ### SUSPECTED FUNCTION
    [PASTE CODE]

    ### INSTRUCTION
    1. Identify the root cause (Logic error vs. Type error).
    2. Propose a fix that does not change the function signature.
    3. Generate a regression test case that would have caught this error.
    ```

---

## 5. Automated Test Suite Generation: Scaling with LLMs
Do not write tests manually. Use the LLM to generate **Property-Based Tests** using `Hypothesis`.

### The Test Generation Workflow
1.  **Input:** The implementation code.
2.  **Prompt:** "Generate a `pytest` suite using `Hypothesis` for the following function. Target edge cases: None values, empty strings, and extremely large integers. Ensure 100% branch coverage."
3.  **Verification:** Run the generated tests. If they fail, feed the failure back into the LLM (The Debugging Loop).

---

## 6. Refactoring Legacy Code: Systematic Transformation
**Case Study: Refactoring a Monolithic Python Function**

**The Legacy Code:**
```python
def process_order(order_id, user_id, items, total_price):
    # 50 lines of nested if-else, direct DB calls, and email logic
    db.execute(f"UPDATE orders SET status='processed' WHERE id={order_id}")
    # ... more logic ...
    send_email(user_id, "Order Processed")
```

**The Step-by-Step Prompt Sequence:**

**Step 1: The Extraction Prompt (Decomposition)**
> "Analyze `process_order`. Identify all side effects (DB, Email, etc.). Rewrite this function using the Dependency Injection pattern, extracting the DB and Email logic into separate, injectable interfaces."

**Step 2: The Transformation Prompt (Implementation)**
> "Using the new interfaces created in Step 1, rewrite the `process_order` logic. Ensure the function is now pure logic, accepting `IOrderRepository` and `INotificationService` as arguments."

**Step 3: The Verification Prompt (Testing)**
> "Write a unit test for the refactored `process_order` using `unittest.mock`. Ensure the `IOrderRepository.update` method is called exactly once with the correct `order_id`."

---

## 7. Security and Sanity Checks: Auditing AI Code
AI-generated code is prone to **Prompt Injection** and **Insecure Defaults** (e.g., `allow_all_origins=True`).

### The AI-Audit Checklist
When reviewing AI code, run this specific prompt:
```markdown
### AUDIT TASK
Review the provided code for:
1. SQL Injection vulnerabilities (check for f-strings in queries).
2. Broken Access Control (check if user_id is verified).
3. Insecure Defaults (check middleware configurations).
4. Hallucinated libraries (check if imported modules actually exist in standard Python).

### CODE TO AUDIT
[PASTE CODE]
```

---

## 8. Integrating AI into the CI/CD Pipeline
Automate the "Reviewer" role using GitHub Actions.

### Setup: LLM-Based Linter/Reviewer
Create a `.github/workflows/ai-review.yml` to automatically comment on PRs with architectural suggestions.

```yaml
name: AI Code Review
on:
  pull_request:
    types: [opened, synchronize]

jobs:
  review:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v3

      - name: Run AI Reviewer
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
        run: |
          # Script to extract diff and send to LLM
          python scripts/ai_reviewer.py ${{ github.event.pull_request.diff_url }}
```

**The `ai_reviewer.py` logic should:**
1.  Use `git diff` to isolate changes.
2.  Send the diff to an LLM with a "Senior Reviewer" system prompt.
3.  Use the GitHub API to post a comment on the PR.

---

## 9. Tool Stack: The Augmented Engineer's Arsenal
To implement this guide, configure the following stack:

1.  **IDE:** **Cursor** (for agentic coding) or **VS Code + Continue.dev** (for open-source LLM integration).
2.  **CLI Agent:** **Aider** (for terminal-based, multi-file refactoring).
3.  **Context Management:** **ctags** (to generate symbol maps for large repos).
4.  **Testing:** **Hypothesis** (for generating edge-case data for LLM-generated tests).
5.  **Automation:** **GitHub Actions** (to host your AI-driven linting and review loops).