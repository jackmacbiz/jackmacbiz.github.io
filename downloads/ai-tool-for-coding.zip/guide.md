# The AI-Augmented Engineer: Prompt Engineering & Workflow Architect

This guide is not about how to write better "chat" messages. It is a technical manual for re-engineering your cognitive workflow. To achieve 10x velocity, you must stop treating LLMs as a search engine and start treating them as a junior engineer with infinite memory but zero intuition.

---

## 1. The Prompting Framework: Context-Injection & System Instructions

The most common failure in AI-assisted coding is "Context Dilution." When you provide a vague prompt, the LLM fills the vacuum with generic patterns from its training data, leading to non-idiomatic code.

### The Triple-Layer Context Injection (TLCI) Template
Never prompt without the following three layers. Use this structure for every complex task:

**[LAYER 1: The Environment Persona]**
Define the tech stack, versions, and linting rules.
> "You are a Senior Staff Engineer specializing in Go 1.21 and PostgreSQL 15. Adhere strictly to Uber's Go Style Guide. Use `sqlc` for type-safe queries."

**[LAYER 2: The Architectural Constraints]**
Define the boundaries.
> "Constraints: No external dependencies outside of the standard library and `pgx`. All database interactions must use a connection pool. Interface boundaries must be defined before implementation."

**[LAYER 3: The Task Specifics (The 'What')]**
The actual logic.

#### ❌ The "Bad" Prompt (The Autocomplete Trap)
`"Write a function in Node.js to handle user login with JWT."`
*Result: Generic, insecure, uses outdated `jsonwebtoken` patterns, no error handling, no type safety.*

#### ✅ The "Architect" Prompt (The TLCI Method)
```markdown
# Role
Senior Backend Engineer (TypeScript, NestJS, Prisma)

# Context
File: `src/auth/auth.service.ts`
Existing Dependency: `bcrypt`, `@nestjs/jwt`
Architecture: Repository Pattern.

# Task
Implement the `validateUser` method. 

# Implementation Requirements
1. Use the `UserRepository` to fetch the user by email.
2. Compare the hashed password using `bcrypt.compare`.
3. If successful, generate a JWT containing `{sub: user.id, role: user.role}`.
4. Error Handling: Throw a `UnauthorizedException` if credentials fail.
5. Logging: Use the internal `Logger` service to log failed attempts.

# Output Format
Return only the TypeScript code block. Ensure all types are explicitly defined.
```

---

 Implemented via `.cursorrules` or `.clinerules`, this framework ensures that every time you hit "Tab," the AI is already aware of your project's architectural boundaries.

---

## 2. Architectural Prompting: Mapping Requirements to Boilerplate

To prevent "Code Sprawl," you must use a **Top-Down Decomposition** workflow. Never ask for logic until you have established the Skeleton.

### The "Skeleton-First" Workflow
1.  **Phase 1: Interface Definition.** Prompt the AI to generate only `.d.ts` or Interface files.
2.  **Phase 2: The Dependency Graph.** Prompt the AI to identify which services need to be injected.
3.  **Phase 3: The Implementation.** Provide the interfaces from Phase 1 as context to Phase 3.

**Prompt Recipe: The Boilerplate Generator**
Use this when starting a new module:
```text
Analyze the attached `schema.prisma`. 
Generate a structural blueprint for a New Module 'Billing'.
Required files:
- billing.service.ts (Interface and Class Skeleton)
- billing.controller.ts (Route definitions)
- billing.dto.ts (Validation logic using class-validator)
Do not implement business logic yet; only provide the method signatures and type definitions.
```

---

## 3. Technical Debt Reduction: The "Migration Plan" Workflow

AI is uniquely capable of identifying "Code Smells" that human eyes miss during a long sprint. Use it to map architectural rot.

### Mapping Dependency Graphs & Identifying Rot
Do not ask "Is this code bad?" Instead, use the **Entropy Audit Prompt**:

**The Entropy Audit Prompt:**
```text
Scan the attached directory `src/legacy_module/`.
1. Identify all tight couplings where `Module A` directly instantiates `Module B` instead of using Dependency Injection.
2. List all functions with a Cyclomatic Complexity > 10.
3. Identify any 'God Objects' (classes exceeding 500 lines).
Output: A JSON-formatted 'Migration Plan' containing:
{ "issue": "string", "severity": "low|med|high", "refactor_strategy": "string", "impacted_files": [] }
```

### The Multi-File Refactor Recipe
When converting legacy code (e.g., Express to NestJS), use this XML-tagged prompt to prevent the LLM from losing track of file relationships:

```xml
<instruction>
Refactor the attached Express middleware into a NestJS Interceptor.
</instruction>

<source_code>
[Paste legacy code here]
</source_code>

<target_architecture>
NestJS, Decorator-based, Class-based.
</target_architecture>

<mapping_rules>
- Map `req.user` to `ExecutionContext`.
- Convert `next()` calls to `return`.
</mapping_rules>
```

---

## 4. The Debugging Loop: Tracing, Explaining, and Patching

Debugging with AI fails when you simply paste an error. You must provide the **Execution Trace**.

### The Trace-Injection Pattern
When an error occurs, do not just send the error message. Send the **Chain of Causality**:
1.  **The Error:** The stack trace.
2.  **The Input:** The exact JSON payload that caused the crash.
3.  **The State:** The values of key variables at the time of the crash.

**Prompt Recipe: The Logic Error Surgeon**
```text
Error: `TypeError: Cannot read property 'id' of undefined`
Stack Trace: [Insert Trace]
Input Payload: { "userId": 123, "metadata": null }
Current Logic: [Insert Code Snippet]

Task: 
1. Trace the lifecycle of the `userId` variable through the provided snippet.
2. Identify the exact line where the null pointer originates.
3. Provide a patch that implements a defensive check without breaking the existing API contract.
```

---

 Verifying the fix requires the "Unit Test Automation" step below.

---

## 5. Unit Test Automation: Generating Comprehensive Test Suites

The goal is not "code coverage" (a vanity metric), but "assertion density."

### The Assertion-Driven Prompting (ADP)
To avoid "shallow tests" (tests that pass but check nothing), force the AI to use **Edge Case Injection**.

**Prompt Recipe: The Test Suite Architect**
```text
Generate a Vitest suite for the `UserService.create` method.
Requirements:
1. Happy Path: Valid user creation.
2. Edge Case: User with duplicate email (should throw error).
3. Edge Case: Malformed JSON payload.
4. Boundary Test: Extremely long strings in the 'bio' field.
5. Dependency Mocking: Use `vi.mock` for the `PrismaClient`.

Constraint: Every test case must include an assertion for the return type AND an assertion for the side effect in the database.
```

---

## 6. Security & Edge Case Auditing: Vulnerability Detection

### The Adversarial Auditor Prompt
Stop using generic security prompts. Use **Context-Specific Vulnerability Probes**.

**Example: Detecting SQL Injection/Broken Access Control**
```text
Analyze the following SQL query construction logic in `src/db/queryBuilder.ts`.
Act as an adversarial security researcher. 
Identify if any user-controlled input from `req.query` reaches the `db.execute()` call without sanitization.
Specifically, look for:
1. Potential for SQL injection via string interpolation.
ical 2. Insecure Direct Object Reference (IDOR) where a user could modify `orderId` to access another user's data.

Output: A list of vulnerabilities in Markdown, including a 'Proof of Concept' payload for each.
```

---

## 7. Integrating AI Agents: Building Custom Workflows

Stop using the ChatGPT web interface for coding. Use **Agentic IDEs** (Cursor, Aider, or VS Code with Cline) and configure a `.cursorrules` file.

### The `.cursorrules` Configuration Strategy
The `.cursorrules` file is your "System Prompt" for your entire codebase. A high-performance rule file should look like this:

```markdown
# Project Rules: [Project Name]

## Coding Standards
- Use functional programming patterns where possible.
- No `any` types; use `unknown` if type is truly unknown.
- Always use Zod for runtime validation.

## Workflow Instructions
- Before writing any code, always search the `@docs` folder for relevant architectural patterns.
- When creating a new service, always create a corresponding `.spec.ts` file.
- If you see a pattern that deviates from the established `src/patterns` folder, alert the user.

## Tech Stack Specifics
- Database: PostgreSQL via Prisma.
- Auth: Clerk.
```

By defining these rules, you transform the AI from a "chat bot" into a "project-aware agent" that understands your specific architectural decisions.

---

## 8. Case Study: Implementing a Redis-Backed Rate Limiter

Let's walk through the full lifecycle of a production-ready feature.

**Step 1: Interface Definition (The Blueprint)**
*Prompt:* "Define an interface `IRateLimiter` for a Redis-backed implementation. It should have a `checkLimit(key: string, limit: number, window: number): Promise<boolean>` method."

**Step 2: Skeleton Generation (The Structure)**
*Prompt (using TLCI):* "Implement the `RedisRateLimiter` class following the `IRateLimiter` interface. Use the `ioredis` library. Use the 'Fixed Window' algorithm. Provide only the class structure and constructor."

**Step 3: Implementation (The Logic)**
*Prompt:* "Complete the `checkLimit` method. Use the `INCR` and `EXPIRE` commands in a single `multi()` transaction to ensure atomicity. Handle the case where the Redis connection is lost by defaulting to `true` (fail-open)."

**Step 4: Unit Test Automation (The Verification)**
*Prompt:* "Generate Vitest tests for the `RedisRateLimiter`. Mock `ioredis`. Test the 'window expiration' logic by simulating the passage of time using `vi.useFakeTimers()`."

---

## 9. Metrics: Measuring Your 10x Velocity

"10x" is a claim that must be backed by data. Use these two metrics to track your progress:

1.  **The PR Cycle Time (PCT):** 
    *   *Formula:* `(Time of PR Creation) - (Time of Initial Task Assignment)`.
    *   *Goal:* A 50% reduction in PCT over 3 months.
2.  **The Regression Rate (RR):**
    *   *Formula:* `(Number of Bugs found in QA) / (Total Number of AI-Generated PRs)`.
    *   *Goal:* An RR of < 5%. If this increases, your "Context Injection" is failing, and you are producing "hallucinated" logic.

**Summary Table for the AI-Augmented Engineer**

| Phase | Tool/Method | Primary Goal |
| :--- | :--- | :--- |
| **Development** | TLCI Prompting | Eliminate generic/non-idiomatic code. |
| **Refactoring** | Entropy Audit Prompt | Identify and automate technical debt removal. |
| **Testing** | Assertion-Driven Prompting | Increase test density and edge-case coverage. |
| **Maintenance** | `.cursorrules` | Maintain architectural consistency across the team. |