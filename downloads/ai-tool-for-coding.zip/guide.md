# The AI-Augmented Engineer: Prompt Engineering & Workflow Architect

This guide is not a collection of "magic prompts." It is a technical manual for re-engineering your cognitive workflow. To achieve a 5x increase in velocity, you must stop treating LLMs as chatbots and start treating them as non-deterministic, high-latency compilers.

---

## 1. The LLM Mental Model: Understanding Tokenization and Context Windows

To architect workflows, you must understand the physical constraints of the LLM.

### Tokenization: The Sub-word Reality
LLMs do not "read" text; they process tokens (often sub-word units). In Python, a variable like `user_id_list` might be split into `['user', '_id', '_list']`. 
*   **The Impact on Code:** This is why LLMs struggle with exact character-level tasks (like reversing a string) or specific regex patterns. 
*   **Architectural Strategy:** When prompting for complex string manipulations, provide the expected token-level structure or use "Few-Shot" examples to anchor the model's attention to the correct sub-word boundaries.

### The Context Window & The "Lost in the Middle" Phenomenon
Modern models (Claude 3.5 Sonnet, GPT-4o) boast massive context windows (200k+ tokens). However, research shows that LLMs suffer from performance degradation when critical information is buried in the middle of a long prompt.
*   **Implementation Rule:** Always place your **Core Instructions** and **Output Schema** at the very end of the prompt (Recency Bias). Place your **Reference Code/Documentation** in the middle.

### Context Management Strategies
1.  **RAG (Retrieval-Augmented Generation) for Local Docs:** Do not paste entire libraries. Use a vector database (like ChromaDB) to retrieve only the relevant function signatures.
2.  **Context Pruning:** Before sending a file to an LLM, strip comments and docstrings if you are hitting token limits and only need logic analysis.

---

## 2. Advanced Prompt Engineering: Chain-of-Thought (CoT) for Complex Debugging

Standard prompting (Role, Context, Instruction) fails when logic branches are deep. You must implement **Chain-of-Thought (CoT)** and **Self-Criticism** loops.

### The "Decomposition" Pattern
Instead of asking "Fix this bug," use a multi-step CoT prompt that forces the model to simulate the execution trace.

**Example Prompt for a Race Condition:**
> "Analyze the attached `async_handler.py`. 
> 1. **Trace:** Step through the execution of `process_data()` line-by-line.
> 2. **State Tracking:** Maintain a mental table of the `shared_resource` state at every await point.
> 3. **Hypothesize:** Identify where an interleaved execution could lead to a stale read.
> 4. **Verify:** Propose a fix using an `asyncio.Lock` and explain why the lock prevents the specific interleaving identified in step 3."

### Few-Shot Logic Anchoring
If you are implementing a proprietary framework, provide 3 examples of "Bug -> Trace -> Fix". This reduces the "hallucination" of standard library functions that don't exist in your custom environment.

---

## 3. The Systematic Debugging Loop: Using AI to Trace and Fix Errors

A professional workflow uses the LLM to generate a **Verification Loop**, not just a fix.

### The "Execution-Feedback" Architecture
Don't accept the first code block. Use this automated loop:
1.  **Generate Fix:** LLM proposes a patch.
2.  **Unit Test Generation:** LLM generates a specific `pytest` case that fails on the current code but passes on the proposed fix.
3.  **Automated Execution:** A local script runs the test.
4.  **Error Feedback:** If the test fails, the stack trace is fed back into the LLM automatically.

**Technical Implementation: The Patch-Generator Script**
This Python utility uses the OpenAI/Anthropic API to generate a `.patch` file rather than overwriting your source code, allowing for safe `git apply` workflows.

```python
import os
import difflib
import openai # Or Anthropic client

def generate_code_patch(file_path, prompt, api_key):
    with open(file_path, 'r') as f:
        original_code = f.read()

    client = openai.OpenAI(api_key=api_key)
    
    # We ask the LLM to provide only the modified code block
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are a senior engineer. Output ONLY the complete updated code. No prose."},
            {"role": "annotated_context", "content": original_code},
            {"role": "user", "content": prompt}
        ]
    )
    
    new_code = response.choices[0].message.content.strip('```python\n').strip('```')
    
    # Generate a unified diff format
    diff = difflib.unified_diff(
        original_code.splitlines(),
        new_code.splitlines(),
        fromfile=f"a/{file_path}",
        tofile=f"b/{file_path}"
    )
    
    patch_content = "\n".join(list(diff))
    patch_filename = f"{file_path}.patch"
    
    with open(patch_filename, 'w') as pf:
        pf.write(patch_content)
    
    print(f"Patch generated: {patch_filename}. Review with 'git apply {patch_filename}'")

# Usage: generate_code_patch('src/auth.py', 'Fix the SQL injection vulnerability in the login function', 'your_key')
```

---

## 4. Automated Unit Test Generation & Edge Case Discovery

To move from Junior to Mid-level, you must automate the "boring" part of testing. 

### The Property-Based Testing Prompt
Instead of asking for "tests," ask for "Edge Case Discovery via Property-Based Testing."
**Prompt Template:**
> "Using the `Hypothesis` library in Python, generate a test suite for the `calculate_interest` function. 
> 1. Identify boundary values (zero, negative, extremely large floats).
> 2. Identify type errors (None, string inputs).
> 3. Ensure the test coverage includes the logic for compounding frequency changes."

### The Mutation Testing Workflow
Use the LLM to analyze your existing test suite. Ask: "Given this test suite, what mutation in the source code would go undetected?" This identifies "shallow" tests that only check for execution but not correctness.

---

## 5. Refactoring Legacy Code with AI-Driven Pattern Recognition

Refactoring is not about rewriting; it is about **pattern extraction**.

### The "Extract Class" Methodology
When dealing with a 1,000-line "God Object," use the LLM to identify cohesive sub-domains.
1.  **Step 1 (Analysis):** "Identify all state variables in this class that are only used by methods related to 'Database Connection'."
2.  **Step able (Interface Design):** "Propose a new `DatabaseManager` interface that encapsulates these variables."
3.  **Step 3 (Implementation):** "Rewrite the original class to delegate these responsibilities to the new `DatabaseManager`."

### Complexity Metrics as Prompts
Feed the LLM the **Cyclomatic Complexity** of a function.
**Prompt:** "This function has a Cyclomatic Complexity of 15. Identify the most complex conditional branch and suggest a strategy to extract it into a separate, testable strategy pattern."

---

## 6. LLM-based Agentic Workflows (The Next Frontier)

Standard prompting is linear. **Agentic Workflows** are iterative and multi-step. Using frameworks like **LangGraph**, you can build a "Coder Agent" that operates in a loop.

### The Agentic Loop Structure:
1.  **Planner Agent:** Breaks the Jira ticket into a checklist of files to modify.
2.  **Coder Agent:** Writes the code (using the Patch-Generator logic above).
3.  **Reviewer Agent:** Acts as a linter/security auditor, checking the Coder's work against a `SECURITY.md` file.
4.  **Executor Agent:** Runs the `pytest` command and feeds errors back to the Coder.

This reduces manual cognitive load by handling the "looping" behavior that humans usually perform.

---

## 7. Cost-Benefit Analysis: Model Selection for Engineering Tasks

Choosing the wrong model is a waste of both time and money.

| Task Type | Recommended Model | Reason | Metric to Watch |
| :--- | :--- | :--- | :--- |
| **Complex Logic/Refactoring** | Claude 3.5 Sonnet | Superior reasoning and instruction following for large context. | Accuracy vs. Token Cost |
| **Simple Unit Tests/Docstrings** | GPT-4o-mini | Extremely low latency and high throughput for repetitive tasks. | Latency (ms/token) |
| **Regex/String Manipulation** | GPT-4o | Stronger performance on character-level tokenization tasks. | Error Rate (%) |
| **Large Repository Analysis** | Claude 3.5 (200k) | Massive context window allows for whole-module understanding. | Context Recall |

**Optimization Tip:** Use a "Router" pattern. Use a cheap model (GPT-4o-mini) to first analyze if a task is "Simple" or "Complex." Only route "Complex" tasks to the expensive models.

---

## 8. Integrating AI into the CI/CD Pipeline and Local IDEs

### The Custom GitHub Action Case Study
**Problem:** A team's PR review time averaged 24 hours due to "nitpicky" style and security reviews.
**Solution:** Developed a GitHub Action that triggers on `pull_request`.
1.  **Action:** The runner pulls the `git diff`.
2.  **LLM Analysis:** Sends the diff to Claude 3.5 Sonnet with a prompt containing the company's `style_guide.md`.
3.  **Output:** The Action posts a single, formatted comment on the PR, highlighting only high-impact logic errors or security vulnerabilities.
**Result:** **40% reduction in PR review time.** The human reviewer only focuses on architectural decisions, while the AI handles the "nitpicks."

### Local IDE Integration
Do not rely solely on Copilot. Set up a local **Context Provider**. Use a tool like `aider` or a custom script that indexes your local `.git` history and provides the LLM with the "last 5 commits" as context. This gives the LLM a sense of the "evolution" of the codebase.

---

## 9. Security & Privacy: Sanitizing Prompts to Prevent Data Leaks

**The Golden Rule:** Never send PII (Personally Identifiable Information) or Secrets (API Keys, DB Credentials) to a third-party LLM.

### The Sanitization Pipeline
Before any code is sent to an API, run it through a local, regex-based "Scrubber" or a specialized tool like `trufflehog`.

**The "Anonymization" Prompt Pattern:**
If you must debug a complex SQL query, use a pre-processing script to replace table and column names with generic identifiers:
*   `user_email_address` $\rightarrow$ `column_a`
*   `customer_billing_table` $\rightarrow$ `table_1`

**Architectural Requirement:** Implement a "Local-First" policy. Use **Ollama** or **Llama 3** running locally via Docker for any task involving highly sensitive proprietary logic. Use Cloud LLMs only for generic algorithmic or structural tasks.

---

## 10. Building Custom GPTs for Specific Language Syntax

Standard LLMs are trained on a "General Purpose" web corpus. If you work in a niche language (e.g., Zig, Mojo, or a proprietary DSL), you must build a **Knowledge-Augmented GPT**.

### The Blueprint for a Custom Coding GPT:
1.  **Knowledge Base:** Upload the `.md` or `.pdf` documentation of the language/framework.
2.  **System Instructions:** Define the "Syntax Constraints." 
    *   *Example:* "When writing Mojo code, always prioritize the use of `@parameter` for compile-time constants."
3.  **Few-Shot Library:** Provide a `samples.json` file containing 20 "Gold Standard" code snippets.
4.  **Negative Constraints:** Explicitly list "Anti-patterns" to avoid (e.g., "Do not use `var`; always use `let`").

By following this structured approach, you transition from a developer who *uses* AI to an **Architect** who *engineers* AI-driven software delivery pipelines.