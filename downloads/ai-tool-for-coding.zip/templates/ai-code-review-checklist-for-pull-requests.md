# AI-Code Review Checklist for Pull Requests

## 🚀 Context & Prompt Engineering
- [ ] **Prompt Traceability**: Does the PR include the specific system prompts or instructions used to generate this code?
- [ ] **Context Window Management**: Was the relevant codebase context (relevant files/functions) provided to the LLM, or was the prompt "blind"?
ical
- [ ] **Instruction Adherence**: Does the output strictly follow the constraints (e.g., "no external libraries", "use ES6 syntax") defined in the prompt?
- [ ] **Hallucination Check**: Have all library imports, method calls, and variable names been verified against actual documentation/existing codebase?

## 🛠️ Code Quality & Logic
- [ ] **Logic Verification**: Does the AI-generated logic handle edge cases (null, undefined, empty arrays, timeouts) that the LLM might have overlooked?
- [ ] **Complexity Audit**: Is the generated code overly verbose or using inefficient patterns (e.g., nested loops) that the LLM suggested?
- [ ] **Type Safety**: Are all types (TypeScript/Python type hints) explicitly defined and accurate, or did the AI omit them?
- [ ] **Dependency Review**: Does the code introduce any new, unverified third-party packages suggested by the AI?

## 🛡️ Security & Compliance
- [ ] **Secret Leakage**: Does the code contain any hardcoded API keys, tokens, or credentials accidentally included in the LLM's training data or prompt context?
- [ ] **Injection Vulnerabilities**: Has the code been checked for prompt injection vulnerabilities or unsanitized inputs that could lead to SQL/Command injection?
- [ ] **Data Privacy**: Does the generated logic process PII (Personally Identifiable Information) in a way that violates privacy standards?

## 🧪 Testing & Validation
- [ ] **Unit Test Coverage**: Are there corresponding unit tests for the new logic, and do they cover the "happy path" and "failure modes"?
- [ ] **Test Prompting**: If tests were AI-generated, have they been manually reviewed to ensure they aren't testing "false positives"?
- [ ] **Regression Check**: Does the new code break existing functionality identified in the codebase's integration suite?

## 📝 Documentation & Maintenance
- [ ] **Docstring Accuracy**: Do the comments and docstrings accurately reflect the actual logic, or are they "hallucinated" descriptions?
- [ ] **Maintainability**: Is the code written in a way that a human engineer can debug without needing the original prompt context?