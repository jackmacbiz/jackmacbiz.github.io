# AI-Code Review Checklist for Security and Logic Errors

**Product:** The AI-Code Engineer: Workflow Architect Kit
**Scope:** Use this checklist to audit AI-generated code snippets for vulnerabilities, logical fallacies, and integration risks before deployment.

## 1. Security & Vulnerability Audit
- [ ] **Injection Vulnerabilities:** Does the code use parameterized queries/prepared statements instead of string concatenation for SQL, NoSQL, or OS commands?
- [ ] **Sensitive Data Exposure:** Are API keys, passwords, or PII (Personally Identifiable Information) hardcoded or logged in plain text?
- [ ] **Input Validation:** Does the code sanitize all external inputs (URL params, headers, body) to prevent XSS or Command Injection?
- [ ] **Broken Access Control:** Does the logic verify user permissions/roles before executing the requested action?
- [ ] **Dependency Integrity:** Are the imported libraries/packages verified for version safety and known vulnerabilities (CVEs)?

## 2. Logic & Functional Integrity
- [ ] **Edge Case Handling:** Does the code account for null, undefined, empty strings, or extremely large integers?
- [ ] **Error Propagation:** Are errors caught via try-catch blocks, and do they fail gracefully without leaking system internals?
- [ ] **Race Conditions:** In asynchronous blocks, is there a risk of data corruption due to concurrent operations on shared state?
- [ ] **Loop & Recursion Limits:** Are there safeguards to prevent infinite loops or stack overflow errors?
- [ ] **Type Safety:** Does the code strictly enforce expected data types (especially in dynamically typed languages)?

## 3. Performance & Efficiency
- [ ] **Complexity Analysis:** Is the Big O complexity acceptable for the expected data volume?
- [ ] **Resource Leaks:** Are database connections, file handles, and network sockets explicitly closed after use?
- [ ] **Redundant Operations:** Does the code perform unnecessary computations or duplicate database queries within a single execution flow?

## 4. Final Verification
- [ ] **Test Coverage:** Can this logic be covered by a unit test?
- [ ] **Documentation:** Is the intent of the AI-generated logic clearly commented to prevent future "black box" errors?