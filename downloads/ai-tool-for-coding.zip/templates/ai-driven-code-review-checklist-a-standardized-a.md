# AI-Driven Code Review Checklist: A Standardized Audit Protocol

## 1. Prompt Integrity & Context Injection
- [ ] **Context Sufficiency:** Does the prompt include necessary architectural constraints, language versions, and library dependencies?
- [ ] **Role Definition:** Is the LLM assigned a specific persona (e.g., "Senior Security Engineer") to tune the review depth?
/ [ ] **Few-Shot Accuracy:** Are the provided examples in the prompt representative of the desired output format and logic?
- [ ] **Instruction Clarity:** Are there any ambiguous verbs or conflicting instructions that could lead to hallucinated logic?

## 2. Logic & Algorithmic Correctness
- [ ] **Edge Case Coverage:** Has the prompt explicitly instructed the AI to check for null pointers, empty collections, and boundary conditions?
- [ ] **Complexity Analysis:** Does the AI-generated review identify potential $O(n^2)$ or higher time complexity issues?
- [ ] **State Management:** Are side effects and global state mutations identified and flagged for review?

## 3. Security & Vulnerability Scanning
- [ ] **Injection Patterns:** Does the audit check for SQL, Command, or Prompt Injection vulnerabilities within the code strings?
- [ ] **Secret Leakage:** Is there a verification step to ensure no API keys, tokens, or hardcoded credentials exist in the diff?
- [ ] **Dependency Integrity:** Does the protocol include a check for deprecated or vulnerable third-party packages?

## 4. Maintainability & Standard Compliance
- [ ] **Style Consistency:** Does the output align with the project's specific linting rules (e.g., PEP8, Airbnb Style Guide)?
- [ ] **Documentation Density:** Are complex logic blocks accompanied by sufficient docstrings and inline comments?
- [ ] **Modular Design:** Does the review flag functions that exceed the established "Single Responsibility" threshold?

## 5. AI-Specific Hallucination Audit
- [ ] **Library Verification:** Are all libraries suggested by the AI actually present in the `package.json` or `requirements.txt`?
- [ ] **Syntax Validation:** Has the AI-suggested syntax been cross-referenced against the official language specification?

---
**Product:** The AI-Augmented Engineer: Prompt Engineering & Workflow Architect
**Protocol Version:** 1.0.0
**Audit Status:** [ ] PASS | [ ] FAIL | [ ] NEEDS REVISION