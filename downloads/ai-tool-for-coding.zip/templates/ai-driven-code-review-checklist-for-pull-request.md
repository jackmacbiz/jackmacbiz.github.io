# AI-Driven Code Review Checklist for Pull Requests

**Product:** The AI-Augmented Engineer: Prompt Engineering & Workflow Automation for Rapid Development
**Scope:** Verification of AI-generated or AI-assisted code for security, logic, and maintainability.

## 1. Prompt & Context Verification
- [ ] **Context Integrity:** Does the code reflect the specific constraints provided in the initial prompt (e.g., library versions, architectural patterns)?
- [ ] **Hallucination Check:** Are all imported libraries, functions, and API endpoints real and existing in the current environment?
- [ ] **Instruction Adherence:** Did the AI follow all "negative constraints" (e.g., "do not use deprecated methods")?

## 2. Logic & Functional Correctness
- [ ] **Edge Case Handling:** Does the code handle `null`, `undefined`, empty strings, or out-of-bounds integers?
- [ ] **Algorithmic Efficiency:** Is the complexity (Big O) appropriate for the input scale?
- [ ] **State Management:** Are side effects predictable and does the code maintain expected state transitions?

## 3. Security & Vulnerability Scanning
- [ ] **Injection Risks:** Are all inputs sanitized to prevent SQL injection, XSS, or Command Injection?
- [ ] **Secret Leakage:** Are there any hardcoded API keys, tokens, or credentials (often introduced by AI "placeholders")?
- [ ] **Dependency Safety:** Are all newly introduced packages vetted for known vulnerabilities?

## 4. Maintainability & Standards
- [ ] **Naming Convention:** Do variable and function names follow the project's established style guide?
- [ ] **Documentation:** Are complex logic blocks accompanied by clear, human-readable comments (not just AI-generated noise)?
- [ ] **Test Coverage:** Does the PR include unit tests that specifically target the logic introduced by the AI?

## 5. Workflow Automation Integration
- [ ] **CI/CD Compatibility:** Will this code pass the existing automated linting and build pipelines?
- [ ] **Schema Alignment:** If database changes are included, do they match the automated migration scripts?

---
**Reviewer Notes:**
*Use this checklist to bridge the gap between AI speed and engineering precision.*