# AI-Driven Code Review Checklist
**Product:** The AI-Augmented Engineer: Prompt Engineering & Workflow Architect
**Focus:** Verifying AI-generated code for security, logic, and maintainability.

## 1. Prompt & Context Verification
- [ ] **Context Integrity:** Does the code reflect all constraints, libraries, and versions specified in the initial prompt?
- [ ] **Hallucination Check:** Are all imported libraries, functions, and API endpoints real and documented?
- [ ] **Instruction Adherence:** Did the AI follow specific formatting or architectural instructions (e.g., "use functional programming style")?

## 2. Logic & Functional Correctness
- [ ] **Edge Case Handling:** Does the code handle null, empty, or out-of-bounds inputs?
- [ ] **Algorithmic Accuracy:** Does the logic solve the intended problem without "shortcut" errors?
- [ ] **State Management:** Are variable mutations predictable and free of unintended side effects?

## 3. Security & Vulnerability Audit
- [ ] **Injection Risks:** Are inputs sanitized to prevent SQL injection, XSS, or command injection?
- [ ] **Credential Exposure:** Are there any hardcoded API keys, tokens, or secrets?
- [ ] **Dependency Safety:** Are the suggested package versions known to be secure and up-to-date?

## 4. Maintainability & Clean Code
- [ ] **Naming Convention:** Are variables and functions descriptive and aligned with the project's style guide?
- [ ] **Complexity Check:** Is the logic overly nested or convoluted (indicating a need for refactoring)?
- [ ] **Documentation:** Are complex logic blocks accompanied by clear, human-readable comments?

## 5. Performance & Efficiency
- [ ] **Complexity Analysis:** Is the Big O notation appropriate for the expected data scale?
- [ ] **Resource Usage:** Does the code avoid unnecessary loops, redundant API calls, or memory leaks?

---
**Reviewer Notes:**
*Use this checklist to transform AI-generated drafts into production-ready engineering assets.*