# AI-Ready Documentation Boilerplate

## 1. Project Metadata
- [ ] **Project Name:** 
- [ ] **Core Objective:** (What problem does this code solve?)
- [ ] **Primary Tech Stack:** (Languages, Frameworks, DBs)
- [ ] **AI Context Window/Model Used:** (e.g., Claude 3.5 Sonnet, GPT-4o)

## 2. Prompt Engineering Context (The "System Prompt" Layer)
- [ ] **Role Definition:** (e.g., "You are a Senior Backend Engineer specializing in Python/FastAPI")
- [ ] **Constraints/Rules:** (e.g., "No external libraries except Pydantic", "Strict Type Hinting required")
- [ ] **Input Schema:** (Definition of the data being fed to the LLM)
- [ ] **Output Format:** (JSON, Markdown, or specific Class structure)

## 3. Workflow & Execution Steps
- [ ] **Step 1: Context Injection:** (What documentation or codebase snippets are provided?)
- [ ] **Step 2: Prompt Execution:** (The specific instruction/template used)
- [ ] **Step 3: Verification/Validation:** (How do we programmatically check the LLM output?)
- [ ] **Step 4: Iteration Loop:** (Instructions for handling errors or hallucinations)

## 4. Implementation Checklist
- [ ] **Dependency Check:** Are all required libraries listed in `requirements.txt` or `pyproject.toml`?
- [ ] **Environment Variables:** Are all secrets/keys abstracted from the prompt?
- [ ] **Unit Test Coverage:** Does the generated code include testable assertions?
- [ ] **Regression Plan:** How do we ensure new prompt iterations don't break existing logic?

## 5. Maintenance & Scaling
- [ ] **Prompt Versioning:** (e.g., `v1.2-refactor-logic`)
- [ ] **Token Budgeting:** (Estimated tokens per execution)
- [ ] **Known Edge Cases:** (List of scenarios where the AI currently fails)