# AI-to-Code Review Checklist for Senior Engineers
**Product:** The AI-to-Augmented Developer Workflow: From Prompt to Production

## 1. Prompt & Context Integrity
- [ ] **Context Sufficiency:** Did the prompt include necessary architectural constraints, library versions, and existing codebase patterns?
- [ ] **Instruction Clarity:** Are there ambiguous modifiers (e.g., "make it fast") that should be replaced with concrete metrics (e.g., "O(n) complexity")?
- [ ] **Constraint Adherence:** Did the output respect defined boundaries (e.g., "no external dependencies," "use existing `AuthService` interface")?

## 2. Logic & Algorithmic Correctness
- [ ] **Edge Case Handling:** Does the generated code handle null/undefined, empty collections, and boundary values (min/max)?
- [ ] **Hallucination Check:** Are all imported libraries, methods, and API endpoints real and compatible with the current environment?
- [ ] **State Management:** Does the logic correctly manage side effects and asynchronous state transitions?
- [ ] **Complexity Analysis:** Does the implementation meet the required Big O time/space complexity for the production scale?

## 3. Security & Vulnerability Assessment
- [ ] **Injection Risks:** Is user input properly sanitized/parameterized to prevent SQLi, XSS, or Command Injection?
- [ ] **Secret Exposure:** Does the code avoid hardcoded credentials, tokens, or sensitive metadata?
- [ ] **Dependency Audit:** Are any newly introduced packages or logic flows susceptible to known vulnerabilities (CVEs)?
- [ ] **Permission Scoping:** Does the code follow the Principle of Least Privilege (PoLP) for file/database/API access?

## 4. Maintainability & Standards
- [ ] **Pattern Consistency:** Does the code follow the established design patterns (e.g., Repository, Factory, Singleton) of the existing repo?
- [ ] **Type Safety:** Are types explicitly defined (TypeScript/Python Type Hints)? Are there any `any` or `unsafe` escapes?
- [ ] **Documentation:** Is the logic explained via comments where the "why" is non-obvious, and are docstrings updated?
- [ ] **Testability:** Is the code modular enough to be covered by unit and integration tests?

## 5. Production Readiness
- [ ] **Observability:** Are appropriate logs, metrics, and traces implemented for monitoring the new logic?
- [ ] **Error Handling:** Are errors caught and handled gracefully without crashing the process or leaking stack traces to the client?
- [ ] **Resource Management:** Are database connections, file handles, and memory allocations properly closed/released?