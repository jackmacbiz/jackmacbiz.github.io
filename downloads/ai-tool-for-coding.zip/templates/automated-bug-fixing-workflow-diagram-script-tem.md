# Automated Bug-Fixing Workflow Diagram & Script Template

## 1. Workflow Diagram Logic (Mermaid.js)
```mermaid
graph TD
    A[Error Trigger: Runtime/Test Failure] --> B{Log Analysis}
    B --> C[Extract Traceback & Context]
    C --> D[LLM Prompt Generation]
    D --> E[Agentic Execution: Code Patching]
    E --> F{Validation Loop}
    F -- Fail --> G[Re-run Analysis with Error Log]
    G --> D
    F -- Pass --> H[Automated Unit Test]
    H -- Fail --> G
    H -- Pass --> I[Commit & PR Generation]
    I --> J[Deployment/Merge]
```

## 2. Bug-Fixing Prompt Template
**Role:** Senior Software Engineer & Debugging Expert
**Context:** [Insert Language/Framework, e.g., Python/FastAPI]
**Error Log:**
```text
[PASTE TRACEBACK HERE]
```
**Current Code State:**
```python
[PASTE RELEVANT FUNCTION/CLASS HERE]
```
**Objective:**
1. Analyze the root cause of the error in the provided traceback.
2. Identify the specific line of code causing the regression or failure.
3. Provide a minimal, production-ready patch.
4. Ensure the fix does not introduce side effects in [Insert Related Module].

## 3. Automation Script Checklist (Python/Bash)
- [ ] **Trigger Mechanism:** Implement a file watcher (e.g., `watchdog`) or CI/CD webhook to detect `stderr` or failed test exit codes.
- [ ] **Context Extraction:** Script must scrape the last 50 lines of logs and the specific file/line number from the traceback.
- [ ] **LLM Integration:** Use `openai` or `anthropic` SDKs to pipe the extracted context into the Prompt Template.
- [ ] **Verification Step:** Script must automatically run `pytest` or `npm test` on the patched file before proposing the fix.
- [ ] **Artifact Generation:** Output a `.patch` file or a Git commit suggestion.

## 4. Implementation Worksheet
| Step | Task | Tool/Library | Status |
| :--- | :--- | :--- | :--- |
| 1 | Log Interception | `sys.stderr` / `subprocess` | [ ] |
| 2 | Context Windowing | `regex` / `ast` module | [ ] |
| 3 | Prompt Orchestration | `LangChain` / `LiteLLM` | [ ] |
| 4 | Automated Testing | `pytest` / `jest` | [ ] |
| 5 | PR Automation | `GitHub API` | [ ] |