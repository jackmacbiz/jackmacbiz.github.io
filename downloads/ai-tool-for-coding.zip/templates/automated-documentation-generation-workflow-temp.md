# Automated Documentation Generation Workflow Template
**Product:** The AI-Driven Engineer: Workflow Architect Kit
**Niche:** AI Tool for Coding

## 1. Scope & Context Definition
- [ ] **Target Audience Identification:** (e.g., Solo Devs, DevOps, Engineering Managers)
- [ ] **Source Material Audit:**
    - [ ] Existing README files
    - [ ] Code comments/Docstrings
    - [ ] Jira/Linear tickets/PR descriptions
    - [ ] Loom/Video walkthroughs
- [ ] **Output Format Specification:** (e.g., Markdown, Wiki, Confluence, API Reference)

## 2. Data Extraction Layer (The "Input" Phase)
- [ ] **Automated Scraper Setup:** Configure scripts to pull raw data from repositories.
- [ ] **Context Window Management:** Define logic to chunk large codebases into digestible LLM prompts.
- [ ] **Metadata Extraction:** Ensure commit history, author, and timestamps are captured.

## 3. AI Processing Pipeline (The "Architect" Phase)
- [ ] **Prompt Template Selection:**
    - [ ] *Summarization Prompt:* For high-level overviews.
    - [ *Technical Deep-Dive Prompt:* For function/class-level logic.
    - [ ] *Dependency Mapping Prompt:* For architectural diagrams/flowcharts.
- [ ] **LLM Configuration:**
    - [ ] Model selection (e.g., Claude 3.5 Sonnet for logic, GPT-4o for prose).
    - [ ] Temperature settings (Low for technical accuracy; Medium for tutorials).
- [ ] **Validation Step:** Implement a "Critic" agent loop to check for hallucinations in technical specs.

## 4. Formatting & Rendering (The "Output" Phase)
- [ ] **Template Application:** Inject processed text into standardized Markdown/HTML templates.
- [ ] **Diagram Generation:** Automate Mermaid.js or PlantUML generation from extracted logic.
- [ ] **Asset Integration:** Link relevant code snippets and directory structures.

## 5. Deployment & Continuous Sync
- [ ] **CI/CD Integration:** Trigger documentation rebuild on every `git push`.
- [ ] **Version Control:** Ensure documentation version matches the software version.
- [ ] **Feedback Loop:** Create a mechanism for engineers to flag/correct documentation errors.

---
**Workflow Status:** [ ] Draft  [ ] In-Progress  [ ] Validated  [ ] Deployed