# Automated Documentation Generator Template

## Project Metadata
- **Product Name:** The AI-Augmented Engineer: Prompt Engineering & Workflow Architect
- **Niche:** AI-Augmented Software Engineering / Prompt Engineering
- **Document Version:** 1.0
- **Date Created:** [Insert Date]
- **Author/Architect:** [Insert Name]

## 1. Context & Objective
- [ ] **Problem Statement:** Define the specific coding bottleneck or manual workflow being automated.
- [ ] **Target User:** Identify if this is for Junior Devs, Senior Architects, or DevOps.
- [ ] **Desired Outcome:** Describe the "Definition of Done" for the automated documentation.

## 2. Prompt Architecture Configuration
- [ ] **Role Definition:** Specify the persona (e.g., "Senior Full-Stack Engineer & Documentation Specialist").
- [ ] **Context Injection:** List required codebase snippets, file structures, or dependency manifests.
- [ ] **Constraint Set:** Define what the AI *must not* do (e.g., "Do not include deprecated API calls").
- [ ] **Output Format:** Define the schema (Markdown, JSDoc, OpenAPI, etc.).

## 3. Workflow Integration Steps
- [ ] **Trigger Mechanism:** (e.g., Git Commit, PR Creation, or Manual CLI command).
- [ ] **Data Extraction:** Identify which files/logs are parsed for context.
- [ ] **LLM Processing Pipeline:**
    - [ ] Pre-processing (Cleaning code comments/removing boilerplate).
    - [ ] Prompt Execution (The core logic).
    - [ ] Post-processing (Formatting and Markdown linting).
- [ ] **Verification Loop:** Define the "Human-in-the-loop" or "Automated Test" step to validate accuracy.

## 4. Documentation Structure Checklist
- [ ] **Executive Summary:** High-level overview of the logic.
- [ ] **Technical Implementation Details:** Step-by-step breakdown of the code logic.
- [ ] **Dependency Map:** List of libraries/modules involved.
- [ ] **Complexity Analysis:** Big O notation or architectural impact.
- [ ] **Usage Examples:** Concrete code snippets demonstrating the implementation.

## 5. Maintenance & Iteration
- [ ] **Feedback Loop:** How to log prompt failures or hallucinations.
- [ ] **Update Cadence:** Frequency of prompt/template refinement.
- [ ] **Version Control:** Tracking changes to the prompt instructions.