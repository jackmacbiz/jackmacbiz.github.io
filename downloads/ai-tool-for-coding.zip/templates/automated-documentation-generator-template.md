# Automated Documentation Generator Template

## 🛠 Project Metadata
- **Project Name:** 
- **Engineer/Architect:** 
- **Date of Generation:** 
- **Version/Iteration:** 
- **Core Objective:** (e.g., Refactor legacy module, Implement new API endpoint, Automate unit testing)

## 🧠 Prompt Architecture & Context
- [ ] **System Role Definition:** (e.g., "You are a Senior Staff Engineer specializing in Python/FastAPI...")
- [ ] **Context Injection:** (List specific documentation, codebase snippets, or library docs provided to the LLM)
- [ ] **Constraint Set:** (e.g., "No external dependencies," "Use type hints," "Adhere to PEP8")
- [ ] **Few-Shot Examples:** (Reference any provided input/output pairs used to guide the model)

## ⚙️ Workflow Workflow Steps
- [ ] **Input Data Preparation:** (Data cleaning, file parsing, or scraping steps)
- [ ] **LLM Processing Pipeline:**
    - [ ] Step 1: Extraction/Summarization
    - [ ] Step 2: Transformation/Code Generation
    - [ ] Step 3: Validation/Linting
- [ ] **Human-in-the-loop (HITL) Checkpoints:** (Specific points where manual review is required)

## 🧪 Validation & Verification
- [ ] **Unit Test Coverage:** (Did the generated code pass existing test suites?)
- [ ] **Prompt Robustness Test:** (Does the prompt yield consistent results across different temperature settings?)
- [ ] **Hallucination Audit:** (Verification of library versions and method signatures used in output)

## 📝 Post-Generation Artifacts
- [ ] **Generated Code/Documentation:** (Link to output file/repository)
- [ ] **Prompt Log:** (Record of the exact prompt string used)
- [ ] **Error Logs/Refinement Notes:** (List of failures and how the prompt was adjusted)

## 🚀 Deployment/Integration Instructions
- [ ] **Integration Point:** (Where this automated workflow sits in the CI/CD pipeline)
- [ ] **Trigger Mechanism:** (e.g., Git Commit, Webhook, Scheduled Cron)