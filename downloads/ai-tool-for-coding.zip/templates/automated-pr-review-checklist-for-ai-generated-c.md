# Automated PR Review Checklist for AI-Generated Code

**Product:** The AI-Augmented Engineer: Prompt Engineering & Workflow Architect
**Scope:** Verification of AI-synthesized code blocks within pull requests to ensure security, maintainability, and logic integrity.

## 1. Functional Correctness & Logic
- [ ] **Logic Alignment:** Does the code strictly adhere to the provided prompt/specification?
- [ ] **Edge Case Handling:** Does the code account for null, empty, or out-of-bounds inputs?
- [ ] **Hallucination Check:** Are all imported libraries, functions, and classes real and existing in the current environment?
- [ ] **Algorithmic Efficiency:** Does the generated solution avoid unnecessary complexity (e.g., $O(n^2)$ where $O(n)$ is possible)?

## 2. Security & Vulnerability Assessment
- [ ] **Injection Prevention:** Are inputs sanitized to prevent SQL, Command, or XSS injection?
- [ ] **Hardcoded Secrets:** Are there any API keys, tokens, or credentials embedded in the generated snippet?
- [ ] **Dependency Integrity:** Are the suggested package versions compatible and free of known vulnerabilities (CVEs)?
- [ ] **Data Leakage:** Does the code inadvertently log sensitive PII or internal system metadata?

## 3. Code Quality & Maintainability
- [ ] **Style Compliance:** Does the code follow the project's linting rules (e.g., PEP8, ESLint)?
- [ ] **Complexity/Cognition:** Is the code overly "clever" or dense in a way that hinders human readability?
- [ ] **Documentation:** Are there adequate docstrings and comments explaining the *intent* (not just the action)?
- [ ] **Modular Design:** Is the generated logic decoupled enough to be unit-tested independently?

## 4. Testability & Verification
- [ ] **Unit Test Coverage:** Does the PR include corresponding test cases for the new logic?
- [ ] **Deterministic Output:** Does the code produce predictable results, or does it rely on non-deterministic AI-generated randomness?
- [ ] **Mocking Requirements:** Are external API calls or database interactions properly mocked in the test suite?

---
**Reviewer Notes:**
*Identify any specific prompts used to generate this code to trace logic origin.*