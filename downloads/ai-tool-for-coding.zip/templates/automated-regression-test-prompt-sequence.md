# Automated Regression Test Prompt Sequence

**Product:** The AI-Augmented Engineer: Architecting Production-Ready Code with LLMs
**Niche:** AI Tool for Coding
**Objective:** Validate that LLM-generated code/architectures maintain functional integrity, security standards, and architectural patterns across iterative prompt updates.

---

### 1. Baseline Verification (The "Golden" State)
- [ ] **Unit Test Parity:** Run existing test suite against the new prompt output.
- [ ] **Schema Validation:** Verify that the LLM output adheres to the predefined JSON/SQL/Class structures.
- [ ] **Dependency Check:** Confirm no new, unapproved libraries were introduced by the LLM.

### 2. Regression Prompt Sequence

#### Phase A: Functional Integrity (The "Does it work?" Test)
- [ ] **Prompt 1 (Logic Check):** "Rewrite [Function/Module] using [Specific Pattern]. Ensure all original edge cases from [Reference Test Case] are handled."
- [ ] **Prompt 2 (Boundary Test):** "Analyze the output of Prompt 1. Identify potential failure points regarding null inputs, empty strings, or integer overflows."
- [ ] **Prompt 3 (Integration):** "Integrate the updated module into the existing [System/Class]. Check for breaking changes in downstream dependencies."

#### Phase B: Architectural Compliance (The "Does it fit?" Test)
- [ ] **Prompt 4 (Pattern Enforcement):** "Review the code against the [e.g., Clean Architecture/SOLID] principles defined in the project documentation. Flag any violations."
- [ ] **Prompt 5 (Complexity Audit):** "Calculate the cyclomatic complexity of the new output. If complexity > [Threshold], refactor for readability without changing logic."

#### Phase C: Security & Robustness (The "Is it safe?" Test)
- [ ] **Prompt 6 (Vulnerability Scan):** "Scan the generated code for OWASP Top 10 vulnerabilities (e.g., SQL Injection, XSS). Suggest specific sanitization logic."
- [ ] **Prompt 7 (Error Handling):** "Verify that every I/O operation in the new code is wrapped in a robust try-catch block with specific exception logging."

### 3. Pass/Fail Criteria
| Metric | Pass Threshold | Result (P/F) |
| :--- | :--- | :--- |
| **Test Suite Coverage** | $\ge$ 90% | |
| **Breaking Changes** | 0 | |
| **Security Vulnerabilities** | 0 | |
| **Complexity Score** | $\le$ [X] | |

### 4. Post-Test Action Plan
- [ ] **If Fail:** Re-run **Phase A, Prompt 1** with specific error logs provided as