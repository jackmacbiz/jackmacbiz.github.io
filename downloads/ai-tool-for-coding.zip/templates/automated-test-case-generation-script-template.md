# Automated Test Case Generation Script Template

## 1. Test Scenario Metadata
- **Test ID:** [e.g., TC-PROMPT-001]
- **Feature/Module:** [e.g., Prompt Template Injection]
- **Engineer Role:** [e.g., Workflow Architect / Prompt Engineer]
- **Complexity Level:** [Low/Medium/High]

## 2. Test Environment Configuration
- [ ] **LLM Engine:** [e.g., GPT-4o, Claude 3.5 Sonnet, Llama 3]
- [ ] **Context Window Size:** [e.g., 128k]
- [ ] **Temperature Setting:** [e.g., 0.0 for deterministic, 0.7 for creative]
- [ ] **System Prompt Version:** [Link to specific prompt version/commit]

## 3. Test Case Definition
- **Input/Prompt Payload:** 
  - *Describe the specific prompt or code snippet being tested.*
- **Pre-conditions:**
  - [e.g., RAG database contains relevant documentation]
  - [e.g., Python environment is initialized with specific libraries]
- **Execution Steps:**
  1. [Step 1: e.g., Inject prompt into API endpoint]
  2. [Step 2: e.g., Parse JSON response]
  3. [Step 3: e.g., Validate code syntax via linter]
- **Expected Output/Behavior:**
  - [e.g., Output must strictly follow the provided JSON schema]
  - [e.g., No hallucinated library dependencies present]

## 4. Validation & Assertion Checklist
- [ ] **Syntax Accuracy:** Does the generated code pass `pylint` or `eslint`?
- [ ] **Instruction Adherence:** Did the model follow all constraints (e.g., "Do not use external libraries")?
- [ ] **Format Integrity:** Is the output structure (Markdown/JSON/Python) intact?
- [ ] **Security/Safety:** Does the output contain any prompt injection vulnerabilities or insecure code patterns?

## 5. Result Logging
- **Actual Output:** [Paste or link to raw LLM response]
- **Pass/Fail Status:** [PASS / FAIL]
- **Error/Deviation Notes:** [Describe any drift from the expected architecture]
- **Timestamp:** [YYYY-MM-DD HH:MM]