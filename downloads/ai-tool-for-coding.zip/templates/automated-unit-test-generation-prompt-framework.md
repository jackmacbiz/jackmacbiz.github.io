# Automated Unit Test Generation Prompt Framework

## 1. Context & Metadata
- [ ] **Target Function/Module Name:** (e.g., `calculate_tax_liability`)
- [ ] **Language/Framework:** (e.g., Python/PyTest, TypeScript/Jest)
- [ ] **Core Logic Description:** (Briefly describe what the code is intended to do)
- [ ] **Dependencies/Mocks Required:** (List external APIs, databases, or modules that need mocking)

## 2. Test Scope Definition
- [ ] **Happy Path:** Define the expected input and successful output.
- [ ] **Edge Cases:** 
    - [ ] Boundary values (e.g., empty strings, zero, maximum integers)
    - [ ] Null/Undefined/None handling
    - [ ] Type mismatches
- [ ] **Error Handling:** Identify specific exceptions or error codes that must be triggered.

## 3. Prompt Construction Template
*Copy and fill the following block into your LLM:*

> **Role:** Senior QA Automation Engineer
> **Task:** Generate a comprehensive suite of unit tests for the provided code snippet.
> **Requirements:**
> - Use [Insert Framework] syntax.
> - Implement mocks for [Insert Dependencies].
> - **Test Cases to Include:**
>   1. [Insert Happy Path Detail]
>   2. [Insert Edge Case Detail]
>   3. [Insert Error Handling Detail]
> - **Output Format:** Provide only the executable test code with clear assertions and descriptive test names.
>
> **Code Snippet:**
> [PASTE CODE HERE]

## 4. Verification Checklist (Post-Generation)
- [ ] **Syntax Check:** Does the generated code run without immediate syntax errors?
- [ ] **Coverage Check:** Does the test suite cover all branches (if/else/try/except) in the source?
- [ ] **Assertion Accuracy:** Do the assertions match the business logic requirements?
- [ ] **Mock Integrity:** Are the mocks correctly simulating the behavior of the dependencies?