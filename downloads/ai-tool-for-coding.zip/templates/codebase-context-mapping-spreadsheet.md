# Codebase Context Mapping Spreadsheet

## 1. Repository Metadata
- [ ] **Repository Name:** (e.g., `auth-service-api`)
- [ ] **Primary Language/Framework:** (e.g., `TypeScript/Node.js`)
- [ ] **Core Dependencies:** (List critical libraries like `Prisma`, `Redis`, `Zod`)
- [ ] **Entry Point:** (e.g., `src/index.ts`)

## 2. Structural Mapping (The "Map")
- [ ] **Directory Architecture:**
    - [ ] `/src/models`: Data schemas and entities.
    - [ ] `/src/controllers`: Request handling logic.
    - [ ] `/src/services`: Business logic and third-party integrations.
    - [ ] `/src/middleware`: Auth and validation layers.
- [ ] **Data Flow Path:** Trace a single request from Route $\rightarrow$ Middleware $\rightarrow$ Controller $\rightarrow$ Service $\rightarrow$ DB.

## 3. Prompt Engineering Context Injection
- [ ] **Global Rules/Style Guide:** (e.g., "Always use functional programming patterns," "Use JSDoc for all exported functions.")
- [ ] **Domain Glossary:** (Define business-specific terms like `UserTier`, `SubscriptionState`, `ProvisioningCycle`.)
- [ ] **Known Constraints:** (e.g., "No external libraries allowed for utility functions," "Must maintain O(n) complexity.")

## 4. Contextual Dependency Inventory
- [ ] **Internal Dependencies:** List critical local modules the AI must understand to prevent hallucinated imports.
- [ ] **External API Contracts:** Summary of payloads/responses for critical external services (e.g., Stripe Webhooks).
- [ ] **Environment Variables:** List required keys (without values) to ensure the AI generates valid `.env.example` or config logic.

## 5. Workflow Integration Checklist
- [ ] **Testing Strategy:** (e.g., "Unit tests via Jest," "Integration tests via Supertest.")
- [ ] **Error Handling Pattern:** (e.g., "Use custom `AppError` class for all 4xx/5xx responses.")
- [ ] **Documentation Standard:** (e.g., "All new endpoints must be documented in Swagger/OpenAPI.")