# Context-Injection Blueprint for Large Repository Analysis

## 1. Repository Metadata
- [ ] **Repository Name/URL:**
- [ ] **Primary Language/Framework:**
- [ ] **Core Architecture Pattern:** (e.g., Microservices, Monolith, Event-Driven)
- [ ] **Dependency Map:** (List critical internal/external libraries)

## 2. Structural Context (The "Skeleton")
- [ ] **Directory Tree Summary:** (High-level folder purpose)
- [ ] **Entry Points:** (Main functions, API routes, or script starts)
- [ ] **Data Flow Path:** (Trace a single request/command from input to persistence)

## 3. Logic & Constraint Injection
- [ ] **Business Logic Rules:** (Define the "must-follow" domain rules)
- [ ] **Coding Standards:** (Linting rules, naming conventions, pattern requirements)
- [ ] **Error Handling Protocol:** (Standardized try/catch or error-response shapes)
- [ ] **Security Constraints:** (Authentication requirements, data sanitization needs)

## 4. Token Optimization (Pruning Strategy)
- [ ] **Excluded Paths:** (e.g., `node_modules`, `dist`, `tests/fixtures`)
- [ ] **Summarization Level:** (Function-level vs. Class-level vs. File-level)
- [ ] **Critical Snippet Extraction:** (Identify specific code blocks essential for the task)

## 5. Task-Specific Instructions
- [ ] **Objective:** (What is the AI being asked to do with this context?)
- [ ] **Expected Output Format:** (e.g., Refactored code, Unit tests, Documentation)
- [ ] **Verification Criteria:** (How to prove the AI respected the injected context)