# Error Log-to-Fix Prompting Workflow

## 🛠 Phase 1: Error Capture & Contextualization
- [ ] **Raw Error Dump**: Copy the full stack trace or compiler error message.
- [ ] **Code Snippet**: Isolate the specific function or block where the error triggers.
/ [ ] **Environment State**: Note the language version, library dependencies, and OS.
- [ ] **The "Last Known Good"**: Identify the last change made before the error appeared.

## 🧠 Phase 2: The Prompt Construction (The "Architect" Method)
*Use this template to structure your prompt to the LLM:*

> **Role**: You are an expert [Language/Framework] Debugging Engineer.
>
> **Context**: I am building [Project Name/Type]. The current implementation uses [Library/Version].
>
> **The Error**: 
> ```
> [Paste Error Message Here]
> ```
>
> **The Code**:
> ```
> [Paste Relevant Code Block Here]
> ```
>
> **The Objective**: 
> 1. Analyze the root cause of this error.
> 2. Explain *why* the current logic fails.
> 3. Provide a corrected code snippet.
> 4. Suggest a preventative check (e.g., unit test or guard clause) to catch this in the future.

## 🧪 Phase 3: Verification & Iteration
- [ ] **Hypothesis Validation**: Does the LLM's explanation align with the stack trace?
- [ ] **Dry Run**: Review the suggested fix for "hallucinated" library methods.
- [ ] **Implementation**: Apply the fix and run the local test suite.
- [ ] **Regression Check**: Ensure the fix does not break adjacent logic.

## 📈 Phase 4: Workflow Optimization
- [ ] **Pattern Recognition**: Is this error recurring? (If yes, add a linting rule).
- [ ] **Documentation**: Update the project `README.md` or `CONTRIBUTING.md` with this specific edge case.