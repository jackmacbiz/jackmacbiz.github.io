# LLM Context Injection Cheat Sheet
## Product: The AI-Augmented Engineer: Prompt Engineering & Workflow Architect

### 1. Core Injection Anchors
- [ ] **Role Definition**: Explicitly assign a persona (e.g., "Senior DevOps Engineer," "Rust Systems Programmer").
- [ ] **Task Boundary**: Define the start and end of the context (e.g., `### CODE START ###` ... `### CODE END ###`).
- [ ] **Constraint Set**: List hard limitations (e.g., "No external libraries," "Use only ES6 syntax").

### 2. Contextual Data Types
- [ ] **Schema/Type Definitions**: Provide interfaces, structs, or Pydantic models to enforce output structure.
- [ ] **Dependency Map**: Inject relevant snippets of imported modules or API documentation.
- [ ] **Error Logs/Stack Traces**: Provide the exact trace to prevent "hallucinated fixes."
- [ ] **Reference Implementation**: Include a "Golden Example" of a correctly implemented function.

### 3. The "Few-Shot" Injection Pattern
- [ ] **Input Example**: A raw, unformatted data string.
- [ ] **Transformation Logic**: A brief description of the desired change.
- [ ] **Output Example**: The perfectly formatted, expected result.

### 4. Workflow Integration Checklist
- [ ] **Token Budget Audit**: Are you injecting unnecessary boilerplate that eats the context window?
- [ ] **Dependency Pruning**: Have you removed irrelevant functions from the injected snippet?
- [ ] **Format Consistency**: Does the injected context use the same notation (e.g., camelCase vs snake_case) as the prompt instructions?

### 5. Injection Template (Copy/Paste)
```text
### ROLE ###
[Insert Persona]

### CONTEXTUAL REFERENCE ###
[Insert Code Snippet/Schema/Log]

### CONSTRAINTS ###
- [Constraint 1]
- [Constraint 2]

### TASK ###
[Insert Instruction]

### EXPECTED OUTPUT FORMAT ###
[Insert Format/Template]
```