# LLM-to-Code Review Checklist
**Product:** The AI-Augmented Engineer: Architecting Production-Ready Code with LLMs
**Purpose:** Use this checklist to validate LLM-generated code before merging into production environments.

## 1. Functional Correctness & Logic
- [ ] **Requirement Alignment:** Does the code strictly satisfy the original prompt/specification?
- [ ] **Edge Case Handling:** Does the code account for null, empty, or out-of-bounds inputs?
- [ ] **Logical Flow:** Are there any "hallucinated" functions or non-existent library methods?
- [ ] **State Management:** Does the code correctly manage side effects and variable mutations?

## 2. Security & Vulnerability Assessment
- [ ] **Injection Risks:** Is user input properly sanitized (SQL, Command, XSS)?
- [ ] **Hardcoded Secrets:** Are there any API keys, passwords, or tokens embedded in the code?
- [ ] **Dependency Integrity:** Are the suggested libraries/packages real, up-to-date, and secure?
- [ ] **Permission Scoping:** Does the code follow the principle of least privilege?

## 3. Architecture & Maintainability
- [ ] **Complexity (Cyclomatic):** Is the logic too nested or convoluted for a human to maintain?
- [ ] **Modular Design:** Is the code decoupled, or is it a "monolithic" block of logic?
- [ ] **Type Safety:** Are types explicitly defined (e.g., TypeScript, Python Type Hints) to prevent runtime errors?
- [ ] **Error Handling:** Are exceptions caught and handled gracefully rather than just suppressed?

## 4. Performance & Efficiency
- [ ] **Big O Complexity:** Is the algorithm optimal for the expected data scale?
- [ ] **Resource Leaks:** Are file handles, database connections, or memory buffers properly closed?
- [ ] **I/O Efficiency:** Are there unnecessary database queries or redundant API calls inside loops?

## 5. Testing & Verification
- [ ] **Unit Test Coverage:** Does the code include (or is it accompanied by) testable logic?
- [ ] **Deterministic Output:** Does the code behave predictably across different environments?
- [ ] **Traceability:** Can the logic be easily debugged using standard logging/tracing tools?

---
**Reviewer Notes:**
*Date:*
*Reviewer ID:*
*Critical Issues Found:*