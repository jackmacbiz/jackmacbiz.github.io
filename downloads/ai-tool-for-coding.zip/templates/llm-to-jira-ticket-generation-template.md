# LLM-to-Jira Ticket Generation Template

## 📋 Context & Metadata
- **Project/Epic Name:** [e.g., Feature Enhancement - Code Review Automation]
- **Target Sprint:** [e.g., Sprint 24]
- **Assignee/Developer:** [Name]
- **Priority:** [Highest/High/Medium/Low]

## 🤖 Prompt Engineering Instructions
*Use these instructions to guide the LLM in generating the ticket content.*

### 1. Input Data (The "Raw" Info)
- **Feature Description:** [Paste raw notes, Slack transcripts, or rough ideas here]
- **Technical Constraints:** [e.g., Must use Python 3.11, must integrate with GitHub Actions]
- **User Story Goal:** [e.g., As a developer, I want to automate PR summaries so I can reduce manual review time]

### 2. LLM Prompt Template
> **Role:** You are an expert Technical Product Manager and Jira Administrator.
> **Task:** Transform the provided "Raw Info" into a structured Jira Ticket.
> **Format Requirements:**
> - **Summary:** A concise, action-oriented title (max 70 chars).
> - **Description:** Use the "As a [user], I want [action], so that [value]" format.
> - **Acceptance Criteria (AC):** A numbered list of verifiable technical requirements.
> - **Technical Notes:** Implementation details, dependencies, or API endpoints.
> - **Definition of Done (DoD):** Checklist for completion (e.g., Unit tests passed, Documentation updated).
>
> **Raw Info:** [Insert Input Data from Step 1]

## ✅ Output Checklist (Verification)
- [ ] **Summary Check:** Does the title clearly state the "what" and "why"?
- [ ] **AC Granularity:** Are the Acceptance Criteria small enough to be completed in one sprint?
- [ ] **Edge Cases:** Did the LLM include error handling or negative testing requirements?
- [ ] **Definition of Done:** Are the testing and documentation requirements explicitly stated?

## 🛠️ Workflow Integration
- **Step 1:** Copy the "Raw Info" into the Prompt Template.
- **Step 2:** Run the prompt in your preferred LLM (Claude/GPT-4).
- **Step 3:** Review the output against the "Output Checklist".
- **Step 4:** Copy the structured text directly into the Jira "Description" field.