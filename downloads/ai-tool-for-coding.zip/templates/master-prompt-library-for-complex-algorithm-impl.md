# Master Prompt Library for Complex Algorithm Implementation

## 1. Pre-Implementation Analysis
- [ ] **Algorithm Specification**: Define the mathematical or logical core (e.g., Dijkstra, A*, Transformer Attention).
- [ ] **Complexity Constraints**: Specify Big O requirements for Time and Space.
- [ ] **Input/Output Schema**: Define data types, dimensions, and edge case boundaries.
- [ ] **Dependency Mapping**: List required libraries (e.g., NumPy, PyTorch, SciPy) and version constraints.

## 2. Prompt Engineering Framework
- [ ] **Role Definition**: Assign a persona (e.g., "Senior Algorithm Engineer," "Performance Optimization Expert").
- [ ] **Context Injection**: Provide the specific problem domain and existing codebase snippets.
- [ ] **Step-by-Step Reasoning (CoT)**: Instruct the LLM to derive the logic before writing code.
- [ ] **Constraint Enforcement**: Explicitly list "Do Not" rules (e.g., "No external dependencies outside stdlib").

## 3. Implementation Phases
- [ ] **Phase 1: Pseudocode Generation**: Focus on logic flow without syntax overhead.
- [ ] **Phase 2: Boilerplate & Structure**: Generate class definitions, interfaces, and method signatures.
- [ ] **Phase 3: Core Logic Implementation**: The heavy lifting of the algorithmic steps.
- [ ] **Phase 4: Error Handling & Edge Cases**: Prompting for null checks, overflows, and empty inputs.

## 4. Verification & Optimization
- [ ] **Unit Test Generation**: Prompt for specific test vectors (boundary, nominal, and error cases).
- [ ] **Complexity Audit**: A secondary prompt to verify the implemented code against the Big O goal.
- [ ] **Refactoring Loop**: Prompt to reduce cyclomatic complexity or memory footprint.
- [ ] **Documentation Generation**: Auto-generate Docstrings (Google/NumPy style) and README instructions.

## 5. Production Readiness Checklist
- [ ] **Type Hinting**: Ensure all functions use Python/TypeScript/C++ type annotations.
- [ ] **Logging Integration**: Ensure observability points are embedded in the logic.
- [ ] **Performance Benchmarking**: Scripted comparison of the new implementation vs. baseline.