# Master Prompt Library for System Architecture & Boilerplate Generation

## 🛠️ Architecture Design Phase
- [ ] **System Topology Definition**
    - *Prompt:* "Act as a Senior Solutions Architect. Design a high-level system architecture for [Project Name]. Define the microservices required, the communication protocol (REST, gRPC, or WebSockets), and the data flow between [Service A] and [BLOB Storage]. Output in Mermaid.js syntax."
- [ ] **Database Schema Modeling**
    - *Prompt:* "Generate a normalized SQL schema for a [Niche] application. Include primary/foreign keys, indexes for performance, and constraints. Provide the DDL script and an Entity-Relationship Diagram (ERD) description."
- [ ] **Infrastructure as Code (IaC) Planning**
    - *Prompt:* "Draft a Terraform configuration outline for deploying a scalable backend on [AWS/Azure/GCP]. Include VPC, Auto-scaling groups, and RDS instances. Focus on high availability and disaster recovery."

## 🏗️ Boilerplate Generation Phase
- [ ] **API Scaffold Generation**
    - *Prompt:* "Generate a production-ready boilerplate for a [Node.js/Python/Go] REST API using [Framework, e.g., FastAPI]. Include folder structure, middleware for error handling, JWT authentication integration, and Swagger/OpenAPI documentation setup."
- [ ] **Unit & Integration Test Suite**
    - *Prompt:* "Create a testing boilerplate using [Jest/PyTest]. Include a sample test suite for a CRUD controller, mocking database dependencies, and a CI/CD pipeline configuration file (.github/workflows/test.yml)."
- [ ] **Containerization & Orchestration**
    - *Prompt:* "Write a multi-stage Dockerfile for a [Language] application to minimize image size. Include a docker-compose.yml file that orchestrates the app, a Redis cache, and a PostgreSQL database with persistent volumes."

## 🧪 Validation & Refinement
- [ ] **Edge Case Stress Test Prompt**
    - *Prompt:* "Analyze the following system architecture: [Paste Architecture]. Identify potential single points of failure, latency bottlenecks, and security vulnerabilities regarding [Specific Threat, e.g., SQL Injection or DDoS]."
- [ ] **Documentation Auto-Generation**
    - *Prompt:* "Based on the provided code boilerplate, generate a README.md file including installation steps, environment variable requirements, and an API endpoint reference table."