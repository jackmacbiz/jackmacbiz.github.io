# Prompt-to-Unit-Test Specification Framework

**Product:** The AI-Augmented Engineer: Prompt Engineering & Workflow Mastery for Rapid Development
**Objective:** Transform high-level functional requirements into executable, high-coverage unit test prompts.

---

### 1. Context Injection (The "System" Prompt)
- [ ] **Role Definition:** Define the AI's persona (e.g., "Senior QA Automation Engineer specializing in Jest/PyTest").
- [ ] **Codebase Context:** Provide snippets of existing interfaces, types, or class structures relevant to the new logic.
- [ ] **Tech Stack Constraints:** Specify language version, testing framework, and assertion library (e.g., "Use Vitest with Testing Library").

### 2. Input Specification (The "Unit" Definition)
- [ ] **Function Signature:** Explicitly state the function name, parameters, and return types.
- [ ] **Dependency Mapping:** List all mocks or stubs required (e.g., "Mock the `databaseClient` and `authService`").
- [ ] **Boundary Conditions:** Define the edges (e.g., `null`, `undefined`, empty strings, maximum integer values).

### 3. Test Case Requirements (The "Logic" Prompt)
- [ ] **Happy Path:** Define the expected behavior for standard, valid inputs.
- [ ] **Negative Testing:** List specific error triggers (e.g., "Ensure a `403 Forbidden` error is thrown if the token is expired").
- [ ] **Edge Case Catalog:** 
    - [ ] Empty/Null inputs
    - [ ] Type mismatches
    - [ ] Boundary overflows
    - [ ] Network latency/timeout simulations
- [ ] **Assertion Style:** Specify preference (e.g., "Use descriptive `it` blocks" or "Use AAA pattern: Arrange, Act, Assert").

### 4. Output Format & Verification
- [ ] **Code Style:** Specify formatting (e.g., "Use ES6 syntax, no semicolons").
- [ ] **Coverage Target:** Set a minimum requirement (e.g., "Ensure 100% branch coverage for the target function").
- [ ] **Self-Correction Loop:** Instruct the AI to "Review the generated test against the provided interface to ensure no compilation errors."

---

### 🛠 Workflow Checklist for Prompt Construction
1. **Identify** the logic change.
2. **Extract** the relevant Type/Interface.
3. **Draft** the "Happy Path" prompt.
4. **Augment** with "Error/Edge Case" instructions.
5. **Execute** via AI and **Verify** with a local test run.