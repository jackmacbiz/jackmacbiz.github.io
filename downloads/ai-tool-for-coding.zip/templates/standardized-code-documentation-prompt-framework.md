# Standardized Code Documentation Prompt Framework

**Product:** The AI-Augmented Engineer: Prompt Engineering & Workflow Architect
**Purpose:** Use this framework to generate high-quality, context-aware documentation for any code module, function, or API endpoint using LLMs.

---

### 1. Contextual Foundation
- [ ] **Module Name/ID:** (e.g., `auth_service.py`)
- [ ] **Role Assignment:** "Act as a Senior Software Architect and Technical Writer."
- [ ] **Target Audience:** (e.g., Junior Developers, DevOps Engineers, API Consumers)
- [ ] **Tech Stack Context:** (e.g., Python 3.11, FastAPI, PostgreSQL, SQLAlchemy)

### 2. Input Data (The Source)
- [ ] **Code Snippet/File Content:** [Paste code here]
- [ ] **Dependency Map:** List critical upstream/downstream dependencies.
- [ ] **Known Constraints:** (e.g., "Must maintain O(1) complexity," "No external libraries allowed.")

### 3. Structural Requirements (The Output Template)
*Instruct the LLM to follow this specific Markdown structure:*

- [ ] **High-Level Summary:** One-sentence description of the logic.
- [ ] **Function/Class Signature:** Clear breakdown of parameters and return types.
- [ ] **Parameter Glossary:**
    - `name`: Type, Description, Constraints (e.g., `user_id: UUID, must be non-null`).
- [ ] **Logic Flow (Step-by-Step):** Numbered list of the algorithmic execution path.
- [ ] **Edge Case Handling:** Documentation of error states and exceptions raised.
- [ ] **Complexity Analysis:** Big O notation for Time and Space.
- [ ] **Usage Example:** A minimal, runnable code snippet.

### 4. Style & Tone Constraints
- [ ] **Tone:** (e.g., Technical, Concise, Instructional)
- [ ] **Formatting:** Use backticks for all identifiers; use Mermaid.js for flowcharts if requested.
- [ ] **Language:** Professional English; avoid fluff/adjectives.

### 5. Verification Checklist (Post-Generation)
- [ ] Does the documentation accurately reflect the provided code logic?
- [ ] Are all type hints and parameter constraints explicitly stated?
- [ ] Is the usage example functional and error-free?
- [ ] Does the documentation adhere to the "AI-Augmented Engineer" standard for clarity and precision?