# Standardized Prompt Templates for Refactoring Tasks

## 🛠️ Refactoring Task Checklist

### 1. Pre-Refactor Analysis
- [ ] **Identify Scope:** Define the specific function, class, or module targeted.
- [ ] **Identify Technical Debt:** List specific issues (e.g., high cyclomatic complexity, tight coupling, hardcoded values).
- [ ] **Define Constraints:** Note existing dependencies, required performance benchmarks, or breaking change limitations.
- [ ] **Establish Baseline:** Document current behavior/output to ensure functional parity post-refactor.

### 2. Prompt Template: The "Clean Code" Refactor
**Role:** Senior Software Architect
**Task:** Refactor the provided code snippet for readability and maintainability.
**Instructions:**
- Apply [SOLID/DRY/KISS] principles.
- Replace complex nested logic with guard clauses.
- Extract large functions into smaller, single-responsibility units.
- **Constraint:** Do not change the external API or function signatures.
**Input Code:** `[INSERT CODE]`

### 3. Prompt Template: The "Performance Optimization" Refactor
**Role:** Performance Engineer
**Task:** Optimize the following code for execution speed and memory efficiency.
**Instructions:**
- Identify and eliminate redundant computations or loops.
- Replace inefficient data structures with optimal alternatives (e.g., List to Set).
- Minimize time complexity (target $O(n)$ or better where applicable).
- **Constraint:** Maintain the exact same input/output contract.
**Input Code:** `[INSERT CODE]`

### 4. Prompt Template: The "Type-Safety & Robustness" Refactor
**Role:** QA Automation Engineer
**Task:** Refactor the code to implement strict typing and error handling.
**Instructions:**
- Add explicit type hints/annotations (e.g., Python Type Hints, TypeScript interfaces).
- Implement `try-except` or `try-catch` blocks for identified failure points.
- Replace "magic numbers" with named constants or Enums.
**Input Code:** `[INSERT CODE]`

### 5. Post-Refactor Verification
- [ ] **Functional Parity Check:** Does the refactored code produce the same output as the original for all edge cases?
- [ ] **Complexity Audit:** Has the cyclomatic complexity decreased?
- [ ] **Test Suite Execution:** Run existing unit tests; ensure 100% pass rate.
- [ ] **Documentation Update:** Ensure docstrings/comments reflect the new structure.