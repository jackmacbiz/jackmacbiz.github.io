# System Design & Schema Generation Template

## 1. Problem Definition & Scope
- [ ] **Core Objective:** Define the primary problem the system solves.
- [ ] **User Personas:** Identify primary (e.g., Solo Dev, DevOps) and secondary users.
- [ ] **Functional Requirements:** List mandatory features (Must-Have).
- [ ] **Non-Functional Requirements:** Define latency, scalability, and security constraints.
- [ ] **Out-of-Scope:** Explicitly list features/capabilities excluded from this version.

## 2. Architectural Blueprint
- [ ] **System Pattern:** (e.g., Microservices, Monolith, Event-Driven, Serverless).
- [ ] **Tech Stack:**
    - **Runtime/Language:**
    - **Database/Storage:**
    - **Message Broker/Queue:**
    - **API Gateway/Interface:**
- [ ] **Data Flow Diagram (DFD):** Map the movement of data from ingestion to storage to output.
- [ ] **Component Interaction:** Define how services communicate (REST, gRPC, WebSockets).

## 3. Data Schema & Modeling
- [ ] **Entity-Relationship Diagram (ERD) Plan:**
    - **Entities:** (e.g., User, Project, PromptTemplate, ExecutionLog).
    - **Attributes:** Define types (String, Int, JSONB, Boolean).
    - **Relationships:** (1:1, 1:N, N:M).
- [ ] **Storage Strategy:**
    - **Relational (SQL):** For structured, ACID-compliant data.
    - **NoSQL/Document:** For unstructured logs or flexible metadata.
    - **Vector Database:** For embeddings and RAG-based retrieval.
    - **Cache Layer:** (e.g., Redis) for high-frequency lookups.

## 4. API & Interface Specification
- [ ] **Endpoint Definitions:**
    - `METHOD /path` -> Description -> Required Params -> Response Shape.
- [ ] **Authentication/Authorization:** (e.g., JWT, OAuth2, API Keys).
- [ ] **Error Handling Schema:** Standardized error codes and message formats.

## 5. Workflow Automation & AI Integration
- [ ] **Prompt Orchestration:** Logic for prompt chaining or iterative refinement.
- [ ] **Agentic Loops:** Definition of decision-making steps and tool-use capabilities.
- [ ] **Context Window Management:** Strategy for truncation, summarization, or RAG injection.
- [ ] **Feedback Loops:** Mechanism for capturing user corrections to improve future prompts.

## 6. Deployment & Scalability
- [ ] **Infrastructure as Code (IaC):** (e.g., Terraform, Pulumi).
- [ ] **CI/CD Pipeline:** Automated