# System Prompt Blueprint for Custom Coding Agents

## 1. Role & Identity Definition
- [ ] **Persona Name:** (e.g., Senior Full-Stack Architect, Python Optimization Expert)
- [ ] **Core Expertise:** (List specific languages, frameworks, or design patterns)
- [ [ ] **Tone & Communication Style:** (e.g., Concise, Socratic, Verbose with explanations, Dry/Technical)

## 2. Context & Environment Constraints
- [ ] **Tech Stack Definition:** (Define exact versions, e.g., Python 3.11, React 18, PostgreSQL 15)
- [ ] **Coding Standards:** (e.g., PEP8, Google Java Style Guide, Airbnb JavaScript Style)
- [ ] **Project Scope:** (Define what the agent *should* and *should not* touch)
- [ ] **Dependency Rules:** (e.g., "Only use standard libraries," "No external CSS frameworks")

## 3. Operational Workflow (The Loop)
- [ ] **Analysis Phase:** (Instructions on how to parse requirements before coding)
- [ ] **Implementation Phase:** (Instructions on writing modular, testable code)
- [ ] **Verification Phase:** (Instructions for generating unit tests or manual verification steps)
- [ ] **Refactoring Phase:** (Instructions for optimizing complexity/readability)

## 4. Output Formatting & Structure
- [ ] **Code Block Protocol:** (e.g., "Always include file paths as comments at the top of blocks")
- [ ] **Documentation Requirements:** (e.g., "Every function must have a Docstring")
- [ ] **Error Handling Instructions:** (e.g., "Always wrap I/O operations in try-except blocks")
- [ ] **Response Structure:** (e.g., 1. Summary, 2. Code, 3. Implementation Notes, 4. Test Commands)

## 5. Error Handling & Self-Correction
- [ ] **Failure Protocol:** (What to do when a library is missing or a dependency fails)
- [ ] **Constraint Enforcement:** (How the agent should react if a user request violates the defined tech stack)
- [ ] **Verification Checklist:** (A list of things the agent must check before finalizing its response)

## 6. Knowledge Retrieval & Tool Usage
- [ ] **Documentation Reference:** (Instructions on how to prioritize official docs over training data)
- [ ] **Search Protocol:** (When to use web search vs. internal knowledge)
- [ ] **Code Execution/Testing:** (Instructions for using a REPL or sandbox to verify logic)