# System Prompt Blueprint for Custom Coding Agents

## 1. Agent Identity & Role Definition
- [ ] **Role Name:** (e.g., Senior Rust Engineer, Python Automation Specialist)
- [ ] **Core Mission:** (Define the primary objective of the agent)
- [ ] **Expertise Level:** (e.g., L7 Staff Engineer, Junior Bug Hunter)
- [ ] **Tone/Persona:** (e.g., Concise, pedantic, highly documented, or rapid-prototyping)

## 2. Context & Environment Constraints
- [ ] **Tech Stack:** (List specific languages, frameworks, and versions)
- [ ] **Library Boundaries:** (List prohibited or strictly required libraries)
- [ ] **Coding Standards:** (e.g., PEP8, Google Style Guide, Airbnb JS)
- [ ] **Architecture Patterns:** (e.g., Microservices, Hexagonal, Monolithic)

## 3. Operational Instructions (The "How")
- [ ] **Step-by-Step Workflow:** (Define the loop: Analyze -> Plan -> Code -> Test)
- [ ] **Error Handling Protocol:** (How the agent should respond to syntax or logic errors)
- [ ] **Refactoring Rules:** (When to suggest changes vs. when to implement new features)
- [ ] **Documentation Requirements:** (e.g., JSDoc, Docstrings, README updates)

## 4. Input/Output Specifications
- [ ] **Input Format:** (e.g., Raw code snippets, GitHub Issue descriptions, File trees)
- [ ] **Output Format:** (e.g., Diff format, Complete file rewrite, Markdown summary)
- [ ] **Unit Test Mandate:** (Requirement for generating PyTest, Jest, or integration tests)

## 5. Verification & Quality Control
- [ ] **Self-Correction Loop:** (Instructions for the agent to review its own code for bugs before outputting)
- [ ] **Complexity Constraints:** (Instructions to avoid "spaghetti code" or overly nested logic)
- [ ] **Security Checklist:** (Instructions to check for SQL injection, hardcoded secrets, etc.)

---
**Workflow Architect Note:** *Use this blueprint to transform generic LLM responses into specialized, high-precision coding engines for the AI-Augmented Engineer ecosystem.*