# System Prompt Templates for Custom Coding Assistants

## 🛠️ Core Persona Definition
- [ ] **Role Assignment:** Define the specific expertise (e.g., "Senior Full-Stack Engineer," "Security Auditor," "DevOps Specialist").
- [/ ] **Contextual Knowledge:** Specify the tech stack, language versions, and framework constraints.
- [ ] **Tone & Style:** Set the communication style (e.g., "Concise and technical," "Educational and verbose," "Strictly code-only").

## 🧠 Instruction Framework
- [ ] **Task Decomposition:** Instructions on how to break down complex logic into modular steps.
- [ ] **Constraint Enforcement:** Explicit "Do Not" rules (e.g., "Do not use deprecated libraries," "Do not suggest external dependencies without checking size").
- [ ] **Reasoning Protocol:** Requirement for Chain-of-Thought (CoT) or step-by-step logic before generating code.

## 💻 Coding Standards & Output Format
- [ ] **Code Quality Rules:** Instructions for linting, type safety (TypeScript/Python type hints), and documentation (JSDoc/Docstrings).
- [ ] **Testing Mandate:** Requirement to include unit tests (Jest, Pytest) or integration test snippets.
- [ ] **Error Handling:** Instructions to implement robust try/catch blocks and specific error logging.
- [ ] **Formatting:** Specification for indentation, file structure, and naming conventions (PascalCase, snake_case, etc.).

## 🧪 Verification & Iteration Loop
- [ ] **Self-Correction Prompt:** Instruction for the assistant to review its own code against the initial requirements before finalizing.
- [ ] **Edge Case Checklist:** A prompt trigger to identify potential null pointers, race conditions, or security vulnerabilities.
- [ ] **Refactoring Trigger:** Instructions on how to handle requests for optimization or technical debt reduction.

## 📋 Template Implementation Worksheet
| Component | Input/Value |
| :--- | :--- |
| **Target Role** | |
| **Primary Language/Framework** | |
| **Key Constraints** | |
| **Required Output Format** | |
| **Testing Strategy** | |