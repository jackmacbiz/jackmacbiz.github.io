# The Automated Documentation Generator: Prompt Sequences for Docstrings and READMEs

## Overview
**Product:** The AI-Augmented Engineer: Prompt Engineering & Workflow Architect
**Niche:** AI tools for coding
**Objective:** Standardize high-quality, context-aware documentation using structured prompt sequences to reduce technical debt and manual writing.

---

## 🛠 Phase 1: The Docstring Architect (Function/Method Level)
*Use this sequence to transform raw code into self-documenting modules.*

- [ ] **Step 1: Context Injection**
  - **Prompt:** "Analyze the following code snippet. Identify the core logic, input types, output types, and any side effects or dependencies. Do not write docstrings yet; just provide a technical summary."
- [ ] **Step 2: Standardized Format Generation**
  - **Prompt:** "Using the technical summary, generate a [Google/NumPy/reStructuredText] formatted docstring. Ensure every parameter is typed, every return value is described, and any raised exceptions are explicitly documented."
- [ ] **Step 3: Edge Case Audit**
  - **Prompt:** "Review the generated docstring against the code. Are there any unhandled edge cases or null-pointer risks that should be mentioned in the 'Notes' section of the docstring?"

---

## 📖 Phase 2: The README Architect (Repository Level)
*Use this sequence to build a professional project landing page.*

- [ ] **Step 1: Feature Extraction**
  - **Prompt:** "Scan the directory structure and the main entry point of this repository. List the primary features, installation requirements, and core dependencies."
- [ ] **Step 2: The 'Quick Start' Draft**
  - **Prompt:** "Based on the dependency list, write a 'Quick Start' guide. Include a single-command installation instruction and a minimal, runnable code example that demonstrates the primary feature."
- [ ] **Step 3: Usage & Configuration Template**
  - **Prompt:** "Create a 'Configuration' section. Detail all environment variables, config file parameters, and available flags. Use a Markdown table for clarity."
- [ ] **Step 4: The 'Architecture' Narrative**
  - **Prompt:** "Synthesize the module relationships into a high-level 'Architecture' overview. Explain how data flows from the input interface to the final output."

---

## ✅ Documentation Quality Checklist
*Run this checklist before finalizing any documentation artifact.*

- [ ] **Type Accuracy:** Do all docstring types match the actual Python/TypeScript type hints?
- [ ] **Dependency Alignment:** Does the README list every library found in `requirements.txt` or `package.json`?
- [ ] **Copy-Paste Test:** Can a developer copy the 'Quick Start' code block and run it