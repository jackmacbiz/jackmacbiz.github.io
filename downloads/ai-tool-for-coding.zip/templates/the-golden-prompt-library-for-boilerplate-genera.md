# The 'Golden Prompt' Library for Boilerplate Generation

## 🛠️ Prompt Template Checklist

### 1. Context & Role Definition
- [ ] **Persona Assignment**: Define the LLM as a Senior Staff Engineer or Software Architect.
- [ ] **Tech Stack Specification**: Explicitly list languages, frameworks, and versions (e.g., "Python 3.11, FastAPI, SQLAlchemy 2.0").
- [ ] **Domain Context**: Describe the business logic or system purpose.

### 2. Structural Requirements (The Boilerplate Core)
- [ ] **Project Scaffolding**: Instruction to generate folder structures (e.g., `/src`, `/tests`, `/docs`).
- [/ ] **Dependency Management**: Prompt to generate `requirements.txt`, `pyproject.toml`, or `package.json`.
- [ ] **Interface/Contract Definition**: Instruction to create Type Hints, Pydantic models, or TypeScript interfaces first.

### 3. Implementation Standards
- [ ] **Design Patterns**: Explicitly request patterns (e.g., Repository Pattern, Dependency Injection, Singleton).
- [ ] **Error Handling**: Mandate specific error-handling logic (e.g., "Use custom exception classes and global middleware for error catching").
- [ ] **Testing Suite**: Instruction to generate unit tests using `pytest` or `jest` alongside the implementation.

### 4. Documentation & Compliance
- [ ] **Docstring Standard**: Specify format (e.g., Google Style, NumPy, or JSDoc).
- [ ] **README Generation**: Prompt to include installation, usage, and environment variable instructions.
- [ ] **Security Hardening**: Instruction to include input validation and sanitization logic.

---

## 📝 Worksheet: Prompt Construction Lab

| Component | Your Input (Drafting Area) |
| :--- | :--- |
| **Role** | *e.g., Senior DevOps Engineer* |
| **Core Task** | *e.g., Create a CI/CD pipeline template* |
| **Constraints** | *e.g., Must use GitHub Actions and Docker* |
| **Output Format** | *e.g., YAML configuration + Dockerfile* |
| **Validation Step** | *e.g., Include a linting step in the workflow* |