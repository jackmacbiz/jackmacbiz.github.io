# The 'Golden Prompt' Library for Python, TypeScript, and SQL

## 🛠️ Core Framework: The Context-Task-Constraint (CTC) Method
*Use this structure for every prompt to ensure high-quality, production-ready code.*

- [ ] **Context**: Define the environment (e.g., "Node.js v20, TypeScript, strict mode").
- [ ] **Task**: Use imperative verbs (e.g., "Refactor," "Implement," "Optimize").
- [ ] **Constraint**: Define boundaries (e.g., "No external dependencies," "O(n) complexity").
- [ ] **Output Format**: Specify the structure (e.g., "Single file," "Unit tests included").

---

## 🐍 Python: Logic & Data Engineering
| Prompt Type | Golden Prompt Template |
| :--- | :--- |
| **Refactoring** | "Analyze the following Python function for PEP8 compliance and time complexity. Refactor it to reduce memory overhead without changing the external API. [Insert Code]" |
| **Unit Testing** | "Generate a `pytest` suite for this module. Include edge cases for `None` types, empty collections, and extremely large integers. [Insert Code]" |
| **Data Parsing** | "Write a Python script using `pandas` to clean this CSV. Handle missing values by interpolating, and convert the 'timestamp' column to ISO format. [Insert Data Schema]" |

## 🟦 TypeScript: Type Safety & Scalability
| Prompt Type | Golden Prompt Template |
| :--- | :--- |
| **Type Definition** | "Based on this JSON response, generate TypeScript `interface` definitions. Ensure all optional fields are marked correctly and use `readonly` where applicable. [Insert JSON]" |
| **API Integration** | "Create a service class in TypeScript using `axios` to fetch data from [URL]. Implement error handling with custom error classes and include a retry logic pattern." |
| **Logic Migration** | "Convert this JavaScript function to TypeScript. Implement strict typing for all parameters and return values, and eliminate all uses of `any`." |

## 🗄️ SQL: Performance & Schema Integrity
| Prompt Type | Golden Prompt Template |
| :--- | :--- |
| **Query Optimization** | "Review this PostgreSQL query. Identify potential full table scans and suggest indexing strategies or CTE rewrites to improve execution time. [Insert Query]" |
| **Schema Design** | "Design a normalized SQL schema for a [System Name, e.g., E-commerce] platform. Include foreign key constraints, appropriate data types, and an ERD description." |
| **Data Migration** | "Write a SQL script to migrate data from `table_a` to `table_b`. Ensure data integrity by using a transaction block and