# The 'Golden Prompt' Library for System Design

## 📋 Prompt Engineering Checklist for System Architecture

### 1. Context & Scope Definition
- [ ] **Role Assignment**: Did you define the LLM as a "Senior Staff Systems Engineer" or "Distributed Systems Architect"?
- [ ] **Constraint Mapping**: Have you explicitly listed latency requirements, throughput targets, and budget constraints?
- [ ] **Domain Specification**: Is the architectural pattern (e.g., Microservices, Event-Driven, Monolith) clearly stated?

### 2. Structural Requirements
- [ ] **Component Breakdown**: Does the prompt instruct the AI to identify specific services, databases, and message brokers?
- [ ] **Interface Definition**: Are API contracts (REST, gRPC, GraphQL) or event schemas required in the output?
- [ ] **Data Flow Logic**: Did you prompt for a step-by-step trace of a single request through the system?

### 3. Quality & Reliability Constraints
- [ ] **Failure Mode Analysis**: Did you ask the AI to identify Single Points of Failure (SPOFs)?
- [ ] **Scalability Strategy**: Is there a requirement to explain horizontal vs. vertical scaling approaches?
- [ ] **Security Integration**: Does the prompt mandate the inclusion of AuthN/AuthZ and encryption at rest/transit?

### 4. Output Format & Documentation
- [ ] **Diagram Syntax**: Did you request Mermaid.js or PlantUML code for visual representation?
- [ ] **Trade-off Analysis**: Did you force the AI to provide a "Pros vs. Cons" table for each architectural decision?
- [ ] **Implementation Roadmap**: Is there a requirement for a phased deployment plan (MVP to Scale)?

---

## 🛠️ Golden Prompt Template (Copy & Paste)

**Role:** You are a Senior Systems Architect specializing in [Insert Tech Stack, e.g., AWS/Kubernetes/Python].

**Objective:** Design a highly scalable, resilient system for [Insert Product/Feature Name] that handles [Insert Load, e.g., 10k requests/sec].

**Constraints:**
- **Latency:** Max [X]ms for P99.
- **Consistency:** [Strong/Eventual] consistency required.
- **Budget:** [Low/Medium/High] infrastructure cost tolerance.

**Required Output Sections:**
1. **High-Level Architecture Diagram:** (Provide Mermaid.js syntax).
2. **Component Registry:** List all services, databases, and caching layers.
3. **Data Schema & Flow:** Describe how data moves from ingestion to persistence.
4. **Failure Analysis:** Identify 3 critical failure points and their mitigation strategies.
5. **Trade-off Matrix:** A table comparing [Option A] vs [Option B].