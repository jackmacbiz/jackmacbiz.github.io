# The 'Master Architect' Prompt Library (Python, JS, Rust)

## 🏗️ Core Architecture Prompts
- [ ] **System Role Definition**: Define the LLM persona (e.g., "Senior Rust Systems Engineer focusing on memory safety and zero-cost abstractions").
- [ ] **Context Injection**: Template for providing existing codebase snippets, dependency trees, and architectural constraints.
- [ ] **Constraint Enforcement**: Instructions for strict adherence to specific language standards (e.g., PEP 8, Airbnb Style Guide, or Clippy compliance).

## 🛠️ Implementation Workflows

### 1. Feature Implementation (The "Blueprint" Method)
- [ ] **Step 1: Logic Skeleton**: Prompt to generate interface/trait definitions without implementation.
- [ ] **Step 2: Iterative Implementation**: Prompt to fill method bodies using the skeleton as a guide.
- [ ] **Step 3: Dependency Integration**: Prompt to integrate third-party crates/libraries (e.g., `tokio`, `serde`, `numpy`).

### 2. Refactoring & Optimization (The "Optimizer" Method)
- [ ] **Complexity Analysis**: Prompt to identify $O(n)$ bottlenecks in existing loops.
- [ ] **Pattern Replacement**: Prompt to swap imperative loops for functional iterators (Python/JS) or zero-copy patterns (Rust).
- [ ] **Type Safety Upgrade**: Prompt to transition from `any` (JS) or dynamic types (Python) to strict, typed interfaces.

### 3. Testing & Validation (The "Validator" Method)
- [ ] **Unit Test Generation**: Prompt to generate `pytest`, `Jest`, or `cargo test` suites.
- [ ] **Edge Case Discovery**: Prompt to identify null pointers, integer overflows, or async race conditions.
- [ ] **Property-Based Testing**: Prompt to design test generators for Hypothesis (Python) or Proptest (Rust).

## 🧪 Language-Specific Tuning
| Feature | Python Focus | JavaScript Focus | Rust Focus |
| :--- | :--- | :--- | :--- |
| **Memory** | Garbage Collection/Ref Counting | Heap/Stack/Event Loop | Ownership/Borrow Checker |
| **Concurrency** | Asyncio/Threading | Promises/Worker Threads | Send/Sync Traits/Tokio |
| **Typing** | Type Hints (mypy) | TypeScript/JSDoc | Strong Static Typing |

## 📝 Prompt Engineering Checklist
- [ ] **Input**: Did I provide the specific version of the language/runtime?
- [ ] **Context**: Did I include the relevant `Cargo.toml`, `package.json`, or `requirements.txt`?
- [ ] **Output Format**: Did I specify the desired output (e.g., "Single file," "Modularized," "Markdown-ready