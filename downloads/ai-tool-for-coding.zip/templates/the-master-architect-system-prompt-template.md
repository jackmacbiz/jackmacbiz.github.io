# The 'Master Architect' System Prompt Template

## 1. Role & Persona Definition
- [ ] **Core Identity:** Define the specific engineering persona (e.g., Senior Full-Stack Architect, DevOps Specialist, Embedded Systems Expert).
- [ ] **Expertise Level:** Specify years of experience, specific tech stacks, and architectural patterns (e.g., Microservices, Event-Driven, Monolithic).
- [ ] **Tone & Communication Style:** Set the output style (e.g., "Concise and technical," "Educational and step-by-step," "Strictly PEP8 compliant").

## 2. Context & Domain Constraints
- [ ] **Project Scope:** Define what the AI is working on (e.g., "Refactoring a legacy Python 2.7 API to FastAPI").
- [ ] **Tech Stack Constraints:** List mandatory languages, frameworks, and libraries (e.g., "Use TypeScript, React, and Tailwind CSS; avoid external UI libraries").
- [ ] **Environmental Context:** Specify runtime or deployment targets (e.g., "AWS Lambda, Dockerized environment, edge computing constraints").

## 3. Task Specification (The "Instruction" Layer)
- [ ] **Primary Objective:** A single, clear sentence stating the goal.
- [ ] **Step-by-Step Workflow:** Break the task into discrete, logical phases (e.g., 1. Analyze, 2. Draft, 3. Refactor, 4. Test).
- [ ] **Edge Case Handling:** Explicit instructions for error handling, null checks, or boundary conditions.

## 4. Output Requirements & Formatting
- [ ] **Code Standards:** Specify linting rules, naming conventions, and documentation requirements (e.g., "Include JSDoc comments for all functions").
- [ ] **Structure:** Define how the response should be organized (e.g., "File structure tree first, followed by implementation, then unit tests").
- [ ] **Format Constraints:** (e.g., "Output only raw code blocks," "Use Markdown headers for each module").

## 5. Verification & Evaluation (The "Self-Correction" Loop)
- [ ] **Self-Review Instructions:** Instruct the AI to check its own code against specific criteria (e.g., "Verify that no hardcoded credentials exist").
- [ ] **Testing Mandate:** Require the generation of specific test cases (e.g., "Provide Pytest snippets for the happy path and failure modes").
- [ ] **Complexity Check:** A command to ensure the solution meets the required Big O complexity or performance threshold.

---
**Usage Note:** *Populate each section with specific details before injecting this template into your LLM interface to ensure high-fidelity, production-ready code generation.*