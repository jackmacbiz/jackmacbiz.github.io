# The 'Master Logic' Prompt Library (Python, JavaScript, and SQL)

## 🛠️ Implementation Checklist
- [ ] **Context Injection**: Define the language version (e.g., Python 3.11, ES2022) and specific framework (e.g., FastAPI, React, PostgreSQL).
- [ ] **Constraint Definition**: Explicitly state complexity limits (e.g., "Use only standard libraries," "No external dependencies").
- [ ] **Logic Pattern Selection**: Choose the pattern (Boilerplate, Refactor, Debug, or Unit Test).
- [ ] **Output Schema**: Define the required structure (e.g., "Return only the modified function," "Provide a Markdown table of changes").

## 🧠 Prompt Templates

### 1. The Boilerplate Generator (Python/JS/SQL)
**Goal:** Rapidly scaffold functional code structures.
> "Act as a Senior [Language] Engineer. Generate a production-ready boilerplate for [Feature Name]. 
> **Requirements:**
> - Use [Framework/Library].
> - Implement error handling for [Specific Error].
> - Include type hints/TypeScript interfaces.
> - Ensure the code follows [PEP8/Airbnb] style guides.
> **Output:** Code block followed by a brief explanation of the architectural choices."

### 2. The Logic Refactor (Complexity Reduction)
**Goal:** Transform "spaghetti code" into clean, maintainable logic.
> "Analyze the following [Language] snippet. 
> **Task:** Refactor the code to reduce cyclomatic complexity and improve readability.
> **Constraints:**
  - Maintain the exact same input/output signature.
>   - Replace nested loops with [List Comprehensions/Higher-Order Functions].
>   - Ensure O(n) complexity where possible.
> **Output:** Original vs. Refactored comparison and a summary of optimizations."

### 3. The SQL Query Optimizer
**Goal:** Optimize slow-running queries and prevent full table scans.
> "Review this [SQL Dialect] query: `[Insert Query]`.
> **Objective:** Optimize for execution speed and resource efficiency.
> **Instructions:**
> - Check for unnecessary JOINs or subqueries.
> - Suggest specific indexing strategies (e.g., B-Tree, GIN).
> - Identify potential full table scans.
> **Output:** Optimized Query + a list of recommended `CREATE INDEX` statements."

### 4. The Unit Test Architect
**Goal:** Generate high-coverage test suites.
> "Generate a comprehensive test suite for the following [Language] function: `[Insert Code]`.
> **Coverage Requirements:**
> - Test happy path scenarios.
> - Test edge cases