# The Master Prompt Library for Rapid Feature Scaffolding
## Product: The AI-Driven Engineer: Workflow Architect Kit

### 🛠️ Scaffolding Checklist
- [ ] **Context Injection**: Define the tech stack, existing architecture, and dependency constraints.
- [ ] **Role Assignment**: Explicitly set the LLM persona (e.g., Senior Staff Engineer, DevOps Specialist).
- [ ] **Interface Definition**: Define input/output schemas (JSON, Typescript interfaces, or Protobuf).
- [ ] **Logic Constraints**: List "Never" rules (e.g., "Do not use external libraries for basic logic").
- [ ] **Test-Driven Prompting**: Include a requirement for generating unit tests alongside the feature.

### 📋 Prompt Templates

#### 1. The Boilerplate Generator (Foundation)
> "Act as a Senior Software Architect. Generate the boilerplate for a new [Feature Name] using [Tech Stack]. Include folder structure, necessary configuration files (e.g., tsconfig, dockerfile), and a README.md outlining the implementation roadmap. Ensure all imports follow the existing project pattern: [Insert Pattern]."

#### 2. The Logic Implementation (Core)
> "You are a Staff Engineer. Implement the business logic for [Feature Name] based on the following requirements: [Requirements]. Constraints: Use [Library Name], maintain O(n) complexity, and ensure strict type safety. Output only the functional code and a brief explanation of the algorithmic choice."

#### 3. The API/Interface Contract (Integration)
> "Act as a Backend Engineer. Define the API contract for [Feature Name]. Provide the OpenAPI/Swagger specification in YAML format. Ensure the schema includes validation rules for [Data Type] and handles error states for [Error Case]."

#### 4. The Test Suite Architect (Validation)
> "Act as a QA Automation Engineer. Review the following code: [Code Snippet]. Generate a comprehensive test suite using [Testing Framework]. Include unit tests for edge cases, integration tests for [Dependency], and mock data for [Scenario]."

#### 5. The Refactor & Optimization (Maintenance)
> "Act as a Performance Engineer. Analyze the following implementation for [Feature Name]. Identify potential bottlenecks, memory leaks, or redundant computations. Provide a refactored version of the code that optimizes for [Latency/Throughput] without changing the external API signature."