# The 'Zero-Bug' Prompt Library: Context-Rich Templates for Python, JS, and Rust

## 🛠️ Implementation Checklist
- [ ] **Context Injection**: Did you include the specific library versions and environment constraints?
- [ ] **Type Safety Definition**: Are the expected input/output types explicitly defined in the prompt?
- [ ] **Error Handling Mandate**: Does the prompt instruct the LLM to write `try/except` or `Result` types for all I/O?
- [ ] **Edge Case Enumeration**: Have you listed specific null, empty, or out-of-bounds scenarios to test?
- [ ] **Unit Test Requirement**: Does the prompt demand a corresponding test suite (pytest, Jest, or cargo test)?

## 📋 Template Worksheets

### 1. The Python "Logic Verifier" (Data Processing)
**Goal:** Generate robust, type-hinted Python functions with error handling.
*   **Role:** Senior Python Engineer (PEP 8 compliant).
*   **Context:** [Insert Library, e.g., Pandas/FastAPI] version [X.X].
*   **Task:** Implement [Function Name] to transform [Input Data Structure] into [Output Data Structure].
*   **Constraints:** 
    *   Use `typing` module for all signatures.
    *   Implement specific error handling for [Specific Error, e.g., KeyError].
    *   Complexity must be $O(n)$.
*   **Validation:** Generate a `pytest` script covering: 1. Happy path, 2. Empty input, 3. Malformed input.

### 2. The JavaScript/TypeScript "Interface Guard" (Frontend/API)
**Goal:** Ensure strict type adherence and interface consistency.
*   **Role:** TypeScript Architect.
*   **Context:** [React/Node.js] environment using [ESLint/Prettier] rules.
*   **Task:** Create an interface/type definition for [Data Object] and a function to fetch/mutate it.
*   **Constraints:**
    *   Strict null checks enabled.
    *   Use `Zod` for runtime schema validation.
    *   Handle loading and error states in the UI component.
*   **Validation:** Provide a mock data generator that adheres to the interface.

### 3. The Rust "Memory Safety & Ownership" Template (Systems)
**Goal:** Minimize borrow checker errors and ensure zero-cost abstractions.
*   **Role:** Rust Systems Programmer.
*   **Context:** [Edition, e.g., 2021] with `no_std` [or standard] capability.
*   **Task:** Implement [Algorithm/Module] focusing on memory efficiency.
*   **Constraints:**
    *   Explicitly define ownership (