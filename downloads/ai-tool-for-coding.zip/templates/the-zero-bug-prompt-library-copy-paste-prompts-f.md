# The 'Zero-Bug' Prompt Library (Copy-Paste Prompts for Python, JS, and SQL)

## 🛠️ Implementation Checklist
- [ ] **Context Injection**: Ensure the prompt includes the specific library versions (e.g., Python 3.11, Node 20, PostgreSQL 15).
- [ ] **Constraint Definition**: Explicitly state "No external dependencies" or "Use only standard libraries" to prevent hallucinated imports.
- [ ] **Edge Case Mandate**: Always include the instruction: "Identify and handle null, undefined, and empty string inputs."
- [ ] **Verification Step**: Require the LLM to generate a corresponding Unit Test for every logic block produced.

## 📋 Prompt Templates

### 🐍 Python: Logic & Data Processing
**Goal**: Generate clean, type-hinted, and error-resistant Python functions.
- [ ] **Template**: 
  > "Act as a Senior Python Engineer. Write a function `[FUNCTION_NAME]` that takes `[INPUT_TYPE]` and returns `[OUTPUT_TYPE]`. 
  > **Requirements**: 
  > 1. Use Python 3.10+ type hinting.
  > 2. Implement `try-except` blocks for `[SPECIFIC_ERROR]`.
  > 3. Ensure O(n) complexity.
  > 4. Include a Google-style docstring.
  > **Constraints**: Do not use `pandas`; use only `standard library` or `math`."

### 🟨 JavaScript/TypeScript: UI & API Logic
**Goal**: Prevent race conditions and undefined errors in async operations.
- [ ] **Template**:
  > "Act as a Lead Frontend Engineer. Implement an async function `[FUNCTION_NAME]` to handle `[API_ENDPOINT/ACTION]`.
  > **Requirements**:
  > 1. Use `async/await` syntax.
  > 2. Implement an `AbortController` to prevent memory leaks on unmounted components.
  > 3. Validate the response schema using `[ZOD/Joi/Manual Check]`.
  > 4. Handle 401, 404, and 500 error states explicitly."

### 💾 SQL: Schema & Query Optimization
**Goal**: Prevent SQL injection and ensure index-friendly queries.
- [ ] **Template**:
  > "Act as a Database Administrator. Write a `[SELECT/UPDATE/DELETE]` query for the table `[TABLE_NAME]`.
  > **Requirements**:
  > 1. Use parameterized queries to prevent SQL injection.
  > 2. Optimize the `JOIN` logic for `[INDEXED_COLUMN]`.
  > 3. Ensure the query avoids `SELECT *