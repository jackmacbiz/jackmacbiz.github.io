# Unit Test Generation Prompt Sequence: Python/TypeScript

**Product:** The AI-Augally Engineered: Prompt Engineering & Workflow Automation for Rapid Development
**Niche:** AI Tool for Coding
**Objective:** Transform raw logic/functions into comprehensive, edge-case-aware test suites using a multi-step prompting chain.

---

### Phase 1: Context & Interface Analysis
**Goal:** Feed the LLM the source code and force it to map the "contract" before writing tests.
- [ ] **Prompt 1 (The Architect):** "Analyze the following [Python/TypeScript] code. Identify all exported functions, input types, return types, and side effects (I/O, database, global state). List all potential failure points and edge cases (null, undefined, empty strings, out-of-bounds, type mismatches)."
- [ ] **Verification:** Ensure the LLM identifies all dependencies and mocks required.

### Phase 2: Test Strategy & Mocking Plan
**Goal:** Define the testing framework and dependency isolation strategy.
- [ ] **Prompt 2 (The Strategist):** "Based on the analysis, design a testing strategy using [Pytest/Jest]. Define the mocking requirements for all external dependencies identified. Outline the test categories: Unit (logic only), Integration (module interaction), and Boundary (edge cases)."
- [ ] **Verification:** Check that the strategy includes specific instructions for `unittest.mock` (Python) or `jest.mock` (TypeScript).

### Phase 3: Test Skeleton Generation
**Goal:** Generate the boilerplate code structure without writing the logic yet.
- [ ] **Prompt 3 (The Scaffolder):** "Generate the boilerplate test file structure. Include all necessary imports, mock setups, and empty `test_` or `it()` blocks for every identified scenario from Phase 1. Use descriptive naming conventions (e.g., `test_functionName_scenario_expectedResult`)."
- [ ] **Verification:** Confirm every edge case from Phase 1 has a corresponding empty test block.

### Phase 4: Implementation & Assertion Logic
**Goal:** Populate the skeleton with high-fidelity assertions.
- [ ] **Prompt 4 (The Implementer):** "Populate the test skeleton. For each test block: 1. Arrange the necessary inputs. 2. Mock the identified dependencies. 3. Execute the function. 4. Assert the specific expected output or state change. Ensure coverage for both 'happy path' and 'error path' scenarios."
- [ ] **Verification:** Review assertions for precision (e.g., checking specific object properties rather than just truthiness).

### Phase 5: Refinement & Coverage Audit
**Goal:** Close the loop by identifying missing branches.
- [ ] **Prompt 5 (The Auditor):** "Review the generated test suite against the original