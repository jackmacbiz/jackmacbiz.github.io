# The Prompt Engineer's Blueprint: Masterclass for Midjourney & DALL-E 3

## The Anatomy of a Perfect Prompt: Subject, Lighting, and Lens

High-quality AI imagery is not achieved by describing a "picture." It is achieved by describing a "photograph." To move from amateur to professional, you must stop using adjectives and start using technical specifications.

### The Structural Framework
Every professional prompt must follow this hierarchy:
**[Core Subject] + [Action/Context] + [Environment/Background] + [Lighting Specification] + [Camera Lens/Technical Settings] + [Artistic Style/Medium]**

### 1. The Subject & Action
Be specific about materials and textures. Instead of "a man," use "a weathered 60-scale fisherman with deep facial wrinkles and salt-crusted skin."

### 2. Lighting: The Emotional Driver
Lighting dictates the mood and the "cost" of the image.
*   **Golden Hour:** Warm, soft, long shadows (Ideal for lifestyle/travel).
*   **Rembrandt Lighting:** High contrast, dramatic, one side of the face in shadow (Ideal for portraits).
*   **Volumetric Lighting:** Beams of light visible through dust/fog (Ideal for cinematic/epic scenes).
*   **Rim Lighting:** A thin line of light around the subject (Ideal for separating subjects from dark backgrounds).
*   **Softbox/Studio Lighting:** Even, shadowless light (Ideal for product photography).

### 3. The Lens: Defining Depth of Field
The lens tells the AI how much of the background to blur.
*   **85mm or 100mm Macro:** Extreme detail, blurred background (Bokeh). Use for jewelry, food, or close-up portraits.
*   **35mm Lens:** Natural field of view. Use for street photography and environmental portraits.
*   **14mm Wide-Angle:** Captures vast landscapes and architecture.
*   **f/1.8 vs f/11:** Use "f/1.8" for shallow depth of field (blurry background) and "f/11" for deep focus (everything sharp).

---

## Mastering Style Modifiers: From Cinematic Realism to Vector Art

Style modifiers act as the "filter" applied to your technical prompt.

### Category A: Hyper-Realism & Cinematography
To achieve "expensive" looking imagery, use film stock and rendering engine keywords.
*   **Keywords:** *Shot on 35mm Kodak Portra 400, cinematic color grading, IMAX, photorealistic, Unreal Engine 5 render, ray tracing, highly detailed skin texture.*
*   **Avoid:** "Hyperrealistic" (this often triggers a "plastic" look). Use "Raw photo" or "unfiltered" instead.

### Category B: Commercial Vector & Flat Illustration
Essential for UI/UX and branding.
*   **Keywords:** *Flat vector illustration, Adobe Illustrator style, minimalist, bold outlines, isometric view, corporate Memphis, pastel color palette, clean lines.*

### Category C: Editorial & Magazine
*   **Keywords:** *Vogue editorial, high-fashion photography, grainy film texture, high-contrast black and white, avant-garde.*

---

## The Negative Prompting Framework: Eliminating Artifacts and Distortions

Negative prompting is the process of telling the AI what *not* to include. This is critical in Midjourney (using `--no`) and DALL-E 3 (via descriptive instruction).

### The "Artifact Eraser" List
To prevent common AI failures, include these terms in your negative parameters:
*   **Anatomy Errors:** `extra fingers, mutated hands, poorly drawn face, deformed limbs, fused fingers, double heads.`
*   **Visual Noise:** `blurry, low resolution, grainy, watermark, text, signature, blurry background (unless intended), motion blur.`
*   **Aesthetic Failures:** `cartoonish (if seeking realism), oversaturated, plastic skin, uncanny valley, flat lighting.`

**Pro Tip:** In Midjourney, use the `--no` parameter at the end of your prompt: `--no text watermark blurry hands`.

---

## Advanced Parameter Control: Aspect Ratios, Stylize, and Chaos Settings

Parameters are the "hidden levers" of the AI engine.

### 1. Aspect Ratio (`--ar`)
Never use the default 1:1 square for everything.
*   **Instagram Stories/TikTok:** `--ar 9:16`
*   **Cinematic/Website Hero:** `--ar 21:9` or `--ar 16:9`
*   **Professional Portraits:** `--ar 4:5`

### 2. Stylize (`--s`)
This controls how much "artistic liberty" Midjourney takes.
*   **Low Stylize (`--s 50`):** Follows your prompt literally. Good for precise product placement.
*   **High Stylize (`--s 750`):** Adds intense artistic flair, often ignoring specific details for beauty.

### 3. Chaos (`--c`)
Controls the variation between the 4 images in a single grid.
*   **Low Chaos (`--c 0`):** All 4 images look very similar.
*   **High Chaos (`--c 80`):** Each image is wildly different, great for brainstorming unexpected concepts.

---

## Consistency Secrets: Maintaining Character and Brand Identity

The biggest challenge in AI is "Character Drift." Use these three methods to maintain identity.

### Method 1: The "Seed" Method (Midjourney)
Every image has a unique ID called a Seed.
1.  Find an image you love.
2.  React to the image with the ✉️ (envelope) emoji to get the Seed number.
3.  Use `--seed [number]` in your next prompt to maintain the same noise pattern and composition.

### Method 2: Character Reference (`--cref`)
Midjourney's most powerful tool for branding.
1.  Upload a reference image of your character/product.
2.  Use the command `--cref [URL of your image]`.
3.  The AI will attempt to map the facial features and clothing of the URL onto the new prompt.

### Method 3: The "Style Reference" (`--sref`)
To ensure every social media post has the same "brand look":
1.  Identify a "Master Brand Image."
2.  Use `--sref [URL]` to force the AI to adopt the color palette, lighting, and texture of that specific image.

---

## Workflow Automation: Integrating AI Imagery into Canva and Adobe Suite

AI images are raw materials, not finished products.

### The Professional Pipeline
1.  **Generation (Midjourney):** Generate the high-resolution base.
2.  **Upscaling (Gigapixel AI / Magnific):** AI-generated images are often low-res. Use an AI Upscaler to increase resolution to 4K or 8K for print.
3.  **Cleanup (Adobe Photoshop):** Use the "Generative Fill" tool to remove unwanted artifacts or extend the canvas (Outpainting).
4.  **Composition (Canva/Adobe Express):** Import your cleaned assets. Add typography, brand logos, and UI elements.

**Workflow Hack:** Always generate images with "Negative Space" (empty areas) in the composition. This allows you to place text in Canva without obscuring the subject.

---

## The Prompt Library: 500+ Pre-Tested Prompt Formulas for Rapid Deployment

*Note: Due to space constraints, here are the 5 core "Master Formulas" that serve as the foundation for the full 500+ library.*

### Formula 1: The Product Hero (E-commerce)
`[Product Name] placed on [Material Surface], [Lighting Type], macro photography, 100mm lens, f/2.8, high-end commercial aesthetic, clean background, --ar 4:5`

### Formula 2: The Lifestyle Portrait (Social Media)
`[Subject Description] in [Location], [Time of Day], [Camera Lens], natural lighting, candid moment, shot on 35mm film, authentic textures, --ar 9:16`

### Formula 3: The UI/UX Asset (Web Design)
`[Icon/Object] in [Style: e.g., 3D Claymorphism or Flat Vector], isometric view, soft shadows, pastel color palette, high resolution, white background, --no shadows`

### Formula 4: The Architectural Concept (Real Estate/Design)
`[Building/Interior Type], [Architectural Style], [Lighting: e.g., twilight], wide angle lens, 14mm, hyper-realistic, architectural photography, cinematic lighting, --ar 16:9`

### Formula 5: The Brand Pattern (Backgrounds)
`Seamless pattern of [Subject/Element], [Color Palette], minimalist, vector art, high contrast, repeating texture, --tile`