# High-Conversion Ad Creative Prompt Templates

## 1. The "Problem/Solution" Framework (Direct Response)
*   **Hook:** Identify a common frustration (e.g., "Tired of muddy, unrecognizable AI images?")
*   **The Gap:** Explain why standard prompting fails (e.g., "Generic prompts lead to generic results.")
*   **The Solution:** Introduce *The Prompt Engineer's Blueprint*.
*   **The Mechanism:** Highlight specific mastery of Midjourney/DALL-E 3 syntax.
*   **Call to Action (CTA):** Direct link to checkout/enrollment.

## 2. The "Visual Transformation" Framework (Before/After)
*   **Visual Asset Requirement:** Split-screen image (Left: Low-quality/vague prompt result; Right: Hyper-realistic/detailed Blueprint result).
*   **Caption Hook:** "Stop guessing. Start engineering."
*   **Feature Callout:** List 3 specific technical improvements (e.g., Lighting control, Texture depth, Compositional precision).
*   **CTA:** "Get the Blueprint."

## 3. The "Authority/Expert" Framework (Educational)
*   **Hook:** "The secret to photorealism isn't the model; it's the prompt structure."
*   **Educational Value:** Share one "micro-win" (e.g., a specific parameter or keyword).
*   **The Upsell:** "Master the full logic in our Masterclass."
*   **Social Proof:** Mention student success or specific image quality benchmarks.
*   **CTA:** "Enroll Now."

## 4. Ad Creative Checklist (Pre-Launch)
- [ ] **Aspect Ratio Check:** Are assets optimized for 9:16 (Reels/TikTok) and 1:1 (Instagram/FB)?
- [ ] **Text Overlay:** Is the primary hook readable in under 2 seconds?
- [ ] **Brand Consistency:** Do the generated images reflect the high-quality standard promised in the course?
*   [ ] **Compliance Check:** Ensure no "get rich quick" claims; focus on "skill mastery."
- [ ] **Landing Page Alignment:** Does the ad creative match the hero image on the sales page?