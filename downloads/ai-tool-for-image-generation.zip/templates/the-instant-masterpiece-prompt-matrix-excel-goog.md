# The 'Instant Masterpiece' Prompt Matrix

## 1. Core Subject (The Anchor)
- [ ] **Primary Subject:** (e.g., Cyberpunk Samurai, Victorian Botanist, Hyper-realistic Golden Retriever)
- [ ] **Action/Pose:** (e.g., Running through rain, Meditating, Floating in zero-gravity)
- [ ] **Clothing/Texture:** (e.g., Iridescent silk, Weathered leather, Polished chrome)

## 2. Environment & Setting (The Stage)
- [ ] **Location:** (e.g., Neon-lit Tokyo alley, Overgrown ancient ruins, Minimalist studio)
- [ ] **Time of Day/Lighting:** (e.g., Golden hour, Cinematic rim lighting, Harsh midday sun, Bioluminescent glow)
- [ ] **Atmospheric Effects:** (e.g., Volumetric fog, Floating dust motes, Heavy rain, Heat haze)

## 3. Artistic Style & Medium (The Aesthetic)
- [ ] **Artistic Era/Movement:** (e.g., Art Deco, Surrealism, Ukiyo-e, Cyberpunk)
- [ ] **Medium/Technique:** (e.g., Oil painting on canvas, 35mm film photography, Digital concept art, Watercolor)
- [ ] **Artist Influence (Optional):** (e.g., In the style of Hayao Miyazaki, Greg Rutkowski, or Annie Leibovitz)

## 4. Technical Parameters (The Engine)
- [ ] **Camera Angle/Lens:** (e.g., Wide angle, Macro close-up, Bird's eye view, Low angle)
- [ ] **Depth of Field:** (e.g., Deep focus, Shallow depth of field, Bokeh background)
- [ ] **Resolution/Detail Keywords:** (e.g., 8k, Highly detailed, Intricate textures, Unreal Engine 5 render)
- [ ] **Aspect Ratio (Midjourney Specific):** (e.g., `--ar 16:9`, `--ar 9:16`, `--ar 1:1`)

## 5. Final Assembly Formula
> **[Core Subject]** performing **[Action]**, wearing **[Texture]**, set in **[Location]** during **[Lighting]** with **[Atmospheric Effects]**, rendered in **[Artistic Style]** using **[Medium]**, **[Camera Angle]**, **[Technical Parameters]** --ar [Ratio]