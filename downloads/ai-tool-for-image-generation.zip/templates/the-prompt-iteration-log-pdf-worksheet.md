# The Prompt Iteration Log (PDF Worksheet)

**Product:** The Prompt Engineer's Blueprint: Mastermid-journey & DALL-E 3
**Objective:** Track prompt evolution, parameter adjustments, and stylistic successes to build a repeatable high-quality generation workflow.

---

### 1. Session Metadata
*   **Date/Time:** ___________________________
*   **Model Used:** [ ] Midjourney (v6/Niji)  [ ] DALL-E 3  [ ] Other: __________
*   **Aspect Ratio/Resolution:** ___________________________
*   **Primary Subject/Concept:** ___________________________

---

### 2. The Iteration Tracker

| Iteration # | Base Prompt & Keywords | Parameters (--ar, --stylize, --chaos, etc.) | Resulting Image Quality (1-10) | Specific Failures/Artifacts (e.g., "extra limbs", "blurry texture") |
| :--- | :--- | :--- | :--- | :--- |
| **v1 (Base)** | | | | |
| **v2 (Refined)** | | | | |
| **v3 (Advanced)** | | | | |
| **v4 (Final)** | | | | |

---

### 3. Variable Analysis
*Check the elements you modified between iterations:*

*   [ ] **Subject Detail:** (Added specific textures, clothing, or facial expressions)
*   [ ] **Lighting/Atmosphere:** (Changed from "natural light" to "cinematic volumetric lighting")
*   [ ] **Camera/Lens Settings:** (Added "macro 85mm" or "wide angle")
*   [ ] **Stylistic References:** (Added artist names, era, or specific art movements)
*   [ ] **Negative Prompting/Weighting:** (Added `--no` commands or increased/decreased importance)

---

### 4. Post-Generation Reflection
*   **What was the "Golden Keyword" that unlocked the desired look?**
    ___________________________________________________________________________
*   **What prompt element caused the most unexpected distortion?**
    ___________________________________________________________________________
*   **Key Takeaway for next session:**
    ___________________________________________________________________________

---
**Masterclass Note:** *A prompt is not a single command; it is a repeatable formula. Use this log to identify the specific tokens that drive your revenue-grade assets.*