# Visual Brand Identity Checklist for AI Generation
**Product:** The Prompt Engineer's Blueprint: Masterclass for Midjourney & DALL'E 3

## 1. Core Brand Foundation
- [ ] **Brand Persona:** Define if the brand is "The Technical Expert," "The Creative Visionary," or "The Efficiency Hacker."
- [ ] **Core Color Palette:** Identify 3 primary hex codes (e.g., Deep Neural Blue, Cyber Lime, Slate Grey).
- [ ] **Typography Pairing:** Select one high-impact Sans-Serif for headers and one legible Sans-Serif for body text.
- [ ] **Logo Concept:** Define the visual metaphor (e.g., abstract neural networks, stylized cursor, or geometric light).

## 2. Midjourney Style Consistency (The "Style Reference" Setup)
- [ ] **Lighting Profile:** Define standard lighting (e.g., "Cinematic volumetric lighting," "Soft studio rim light," or "High-contrast noir").
- [ ] **Texture & Materiality:** Define recurring textures (e.g., "Hyper-realistic skin pores," "Matte 3D render," or "Grainy film stock").
- [ ] **Camera Settings/Lens:** Establish a default focal length (e.g., "85mm portrait" or "Wide-angle 24mm") to maintain depth consistency.
- [ ] **Color Grading:** Define a consistent color temperature (e.g., "Warm amber tones" or "Cool desaturated cinematic grade").

## 3. DALL-E 3 Prompting Parameters
- [ ] **Descriptor Density:** Determine if prompts should be "Descriptive & Narrative" or "Keyword-driven & Technical."
- [ ] **Compositional Rules:** Standardize use of "Rule of Thirds," "Bird's Eye View," or "Macro Close-up."
- [ ] **Negative Constraints:** List recurring elements to exclude (e.g., "No text," "No blur," "No distorted limbs").

## 4. Visual Asset Inventory
- [ ] **Master Prompt Template:** A reusable structure for all brand marketing assets.
- [ ] **Iconography Set:** A defined set of symbols for UI/UX elements in the course materials.
- [ ] **Background Library:** A collection of 5 consistent "Brand Environment" prompts for use in social media overlays.

## 5. Implementation Audit
- [ ] **Cross-Platform Check:** Do the generated images look cohesive when placed on Instagram, YouTube Thumbnails, and Course Slideware?
- [ ] **Resolution/Aspect Ratio:** Are all brand assets generated in the correct ratio (e.g., `--ar 16:9` for YouTube, `--ar 9:16` for TikTok)?