# AI-to-Real-World Material Specification Checklist

**Project Name:** ___________________________
**AI Prompt/Render ID:** ____________________
**Designer Name:** __________________________

### 1. Surface & Texture Verification
- [ ] **Finish Match:** Does the AI-generated finish (e.g., "brushed gold") correspond to a specific, obtainable manufacturer finish (e.g., PVD coating)?
- [ ] **Reflectivity Check:** Is the specular highlight/gloss level realistic for the physical material (e.g., matte vs. high-gloss lacquer)?
  - *Target Gloss Level (Gloss Units):* ________
- [ ] **Pattern Scale:** Does the AI-generated pattern scale (e.g., marble veining or wallpaper motif) match the actual physical dimensions of the material?
  - *Pattern Repeat Size:* ________

### 2. Dimensional & Structural Integrity
- [ ] **Thickness Validation:** Is the AI-rendered thickness (e.g., a thin marble slab) structurally viable for the intended substrate/support?
- [ ] **Seam/Joint Planning:** Have realistic grout lines, expansion joints, or panel seams been accounted for in the physical layout?
- [ ] **Weight Assessment:** Does the material weight (e.g., solid stone vs. porcelain tile) align with the structural capacity of the floor/wall?

### 3. Material Sourcing & Compatibility
- [ ] **Availability Check:** Has the specific color/texture been verified as "In Stock" or "Available for Order" with the supplier?
- [ ] **Chemical/Safety Compliance:** Does the material meet local VOC, fire rating (Class A), or slip-resistance (COF) requirements?
- [ ] **Compatibility:** Are the adhesives, sealants, or mounting hardware compatible with the selected material?

### 4. Lighting & Color Accuracy
- [ ] **Metamerism Check:** Will the color shift significantly under different light temperatures (2700K vs 4000K)?
- [ ] **Color Hex/Pantone Mapping:** Has the AI color been mapped to a physical swatch or RAL/Pantone equivalent?
  - *Physical Match Code:* ________

### 5. Budget & Logistics
- [ ] **Cost Variance:** Is the estimated cost per unit/sqft within the project's approved budget?
- [ ] **Lead Time:** Does the delivery window align with the construction schedule?
  - *Estimated Delivery Date:* ________

**Notes/Discrepancies Found:**
___________________________________________________________________________
___________________________________________________________________________