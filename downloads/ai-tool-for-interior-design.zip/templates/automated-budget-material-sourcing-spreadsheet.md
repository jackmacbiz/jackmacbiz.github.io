# Automated Budget & Material Sourcing Worksheet

## Project Overview
- **Project Name:** 
- **Designer/Client:** 
- **Total Budget Ceiling:** $
- **Design Style/Theme:** 

## 1. Room-by-Room Budget Allocation
| Room | Estimated Budget | Actual Spent | Variance (+/-) | Status |
| :--- | :--- | :--- | :--- | :--- |
| Living Room | $ | $ | $ | [ ] Pending [ ] Ordered [ ] Delivered |
| Kitchen | $ | $ | $ | [ ] Pending [ ] Ordered [ ] Delivered |
| Master Bedroom | $ | $ | $ | [ ] Pending [ ] Ordered [ ] Delivered |
| Bathroom | $ | $ | $ | [ ] Pending [ ] Ordered [ ] Delivered |

## 2. Material Sourcing Tracker
| Item Category | Material/Product Name | Vendor/Link | Unit Cost | Quantity | Total Cost | Lead Time (Days) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Flooring | | | $ | | $ | |
| Wall Treatment | | | $ | | $ | |
| Lighting | | | $ | | $ | |
| Textiles/Rug | | | $ | | $ | |
| Hardware/Fixtures| | | $ | | $ | |

## 3. Procurement Checklist
- [ ] **AI Render Verification:** Cross-reference AI-generated textures with real-world availability.
- [ ] **Lead Time Audit:** Ensure all long-lead items (custom cabinetry, imported stone) arrive before installation dates.
- [ ] **Sample Approval:** Physical samples ordered and approved for color/texture accuracy.
- [ ] **Shipping & Tax Calculation:** Include freight, handling, and sales tax in final budget line items.
- [ ] **Contingency Fund:** Allocate 10-15% of total budget for unforeseen shipping delays or price fluctuations.

## 4. Vendor Contact List
| Vendor Name | Contact Person | Email/Phone | Account/Discount Code |
| :--- | :--- | :--- | :--- |
| | | | |
| | | | |