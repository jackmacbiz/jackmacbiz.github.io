# Client Project Brief Template for AI Input Generation

## 1. Project Overview
- **Client Name/ID:** [Insert Name]
- **Project Name:** [Insert Project Title]
- **Design Style:** (e.g., Mid-Century Modern, Scandinavian, Industrial, Japandi, Maximalist)
- **Primary Room/Area:** [e.g., Living Room, Master Bedroom, Open Concept Kitchen]

## 2. Spatial Constraints & Dimensions
- **Room Dimensions:** [Length x Width x Height]
- **Fixed Elements:** [e.g., Fireplace location, Window positions, Built-in cabinetry, Structural pillars]
- **Existing Furniture to Retain:** [List items and their dimensions]

## 3. Aesthetic & Material Requirements
- **Color Palette:** [Specific hex codes or descriptive palette, e.g., Earth tones, Sage green and Terracotta]
- **Key Materials:** [e.g., Polished concrete, Reclaimed wood, Velvet, Brass accents]
- **Lighting Preferences:** [e.g., Natural light focus, Layered ambient lighting, Statement pendant]

## 4. Functional Requirements
- **Primary Use Case:** [e.g., Entertaining guests, Quiet reading nook, Child-friendly zone]
- **Required Furniture Pieces:** [e.g., L-shaped sectional, Marble coffee table, Ergonomic desk]
- **Storage Needs:** [e.g., Hidden media storage, Open shelving, Built-in wardrobe]

## 5. AI Generation Parameters (Prompt Engineering Data)
- **Visual Mood/Atmosphere:** [e.g., Airy and bright, Moody and cinematic, Warm and cozy]
- **Level of Detail/Complexity:** [Low/Medium/High]
- **Reference Image Links/Uploads:** [Insert URLs to Pinterest/Moodboard]
- **Negative Constraints:** [What to avoid, e.g., No clutter, No dark colors, No patterned wallpaper]

## 6. Deliverables & Timeline
- **Required Render Angles:** [e.g., Wide shot, Close-up texture, Top-down floor plan]
- **Deadline:** [YYYY-MM-DD]
- **Final Output Format:** [e.g., 4K PNG, 3D Model file, PDF Moodboard]