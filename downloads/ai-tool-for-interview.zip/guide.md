# The AI-Powered Interview Architect: Master the Prompt-to-Offer Workflow

## The AI Interview Framework: Mapping Job Descriptions to Prompt Engineering

Generic preparation fails because it lacks context. To win, you must treat the Job Description (JD) as a dataset and the LLM as your analytical engine. The goal is to extract the "Hidden Rubric"—the specific competencies the hiring manager is actually testing for.

### The Extraction Workflow
Do not simply ask an LLM to "summarize this JD." Use a **Deconstruction Prompt**.

**The Deconstruction Prompt Template:**
> "Act as an expert technical recruiter. Analyze the following Job Description [Paste JD]. 
    1. Identify the top 5 'Critical Success Factors' (skills that, if missing, result in immediate rejection).
    2. Map these factors to specific 'Behavioral Indicators' (actions a candidate must demonstrate to prove competence).
    3. Identify 'Implicit Values' (cultural cues hidden in the language).
    Output this as a structured table."

### Creating the Competency Matrix
Once you have the extracted data, create a **Prompt-to-Competency Map**. Every interview answer you prepare must map back to one of the "Critical Success Factors" identified. If the JD emphasizes "cross-functional stakeholder management," your entire preparation library must be weighted toward that specific pillar.

---

## Reverse-Engineering the Recruiter: Using LLMs to Predict Interviewer Questions

Interviewers rarely invent questions from scratch; they follow a pattern based on the role's pain points. You can use LLMs to simulate the "Interviewer Persona."

### The Persona Simulation Technique
To predict questions, you must prompt the LLM to adopt the specific professional identity of your interviewer.

**The Persona Prompt:**
> "I am interviewing for [Job Title] at [Company Name]. Based on the attached JD [Paste JD], act as the Hiring Manager for this role. Your personality is [e.g., highly analytical, skeptical, and focused on scalability]. Generate 10 interview questions: 
> - 3 Technical/Hard Skill questions.
> - 4 Behavioral questions using the 'Conflict/Resolution' framework.
> - 3 'Pressure' questions designed to test my ability to handle ambiguity.
> For each question, explain the 'Hidden Intent'—what specific competency are you actually testing?"

### The "Edge Case" Generation
Ask the LLM to identify "Red Flag" questions. These are questions designed to trip up candidates who lack deep experience. 
*Prompt:* "Identify 5 'Trap Questions' for this role where a mediocre answer would signal a lack of seniority, and suggest the 'High-Signal' way to respond."

---



## The STAR-AI Method: Structuring High-Impact Responses with LLM Assistance

The STAR (Situation, Task, Action, Result) method is standard, but most candidates provide "low-density" stories. The **STAR-AI Method** uses LLMs to inject "High-Signal Data" into your narratives.

### Step 1: The Raw Data Dump
Write your story in bullet points. Do not worry about grammar or structure. Include every metric, tool, and person involved.

### Step 2: The Refinement Prompt
Use this prompt to transform your notes into a high-impact narrative:
> "I will provide a raw account of a professional achievement. Use the STAR method to restructure it. 
> **Constraints:**
> 1. **Action Density:** Focus 60% of the response on 'Action' (the specific technical or strategic steps I took).
> 2. **Quantifiable Impact:** Ensure every 'Result' includes a metric (%, $, or time saved). If I didn't provide one, insert a placeholder like [INSERT METRIC].
> 3. **Vocabulary Upgrade:** Replace generic verbs (e.g., 'managed', 'helped') with high-impact leadership verbs (e.g., 'orchestrated', 'mitigated', 'optimized').
> 
> Raw Account: [Paste your notes]"

### Step 3: The "So What?" Audit
After the LLM generates the response, run an audit:
*Prompt:* "Read this STAR response. Identify any parts that sound like 'fluff' or lack concrete evidence. Suggest how I can make the 'Action' section more technically specific."

---

## Real-Time Simulation: Setting Up an AI Mock Interview Environment

Preparation is useless without stress testing. You need a closed-loop simulation.

### The Setup
1.  **The Engine:** Use GPT-4o or Claude 3.5 Sonnet (for superior reasoning).
2.  **The Interface:** Use the **Voice Mode** on the ChatGPT mobile app. This mimics the real-time pressure of a verbal exchange.

### The Simulation Protocol
**The Setup Prompt:**
> "We are starting a Mock Interview. You are [Interviewer Persona]. You will ask one question at a time. I will respond via voice. 
> **Rules:**
> 1. Do not provide feedback until the end of the session.
> 2. If my answer is vague, follow up with a probing 'Why' or 'How' question to test my depth.
> 3. After 5 questions, stop and provide a 'Performance Scorecard' based on: Technical Accuracy, Communication Clarity, and Alignment with the JD."

**The Workflow:**
*   Put your phone on a stand. 
*   Use headphones to ensure the AI's voice is clear.
*   **Crucial:** Record the session (using a tool like Otter.ai or built-in screen recording) so you can transcribe your own verbal mistakes for later analysis.

---

## Post-Interview Intelligence: Using AI to Draft Personalized, High-Conversion Thank You Notes

A thank-you note should not be a "thank you for your time" template. It should be a **Value Reinforcement Document**.

### The Reinforcement Framework
The note must connect a specific moment from the interview to a solution for the company's problems.

**The Post-Interview Prompt:**
> "I just finished an interview with [Interviewer Name]. During the interview, we discussed [Topic A] and [Problem B]. I want to send a thank-you note that reinforces my expertise in [Skill]. 
> 
> Draft a concise, professional email that:
> 1. References our specific discussion about [Topic A].
> 2. Briefly mentions a thought/solution regarding [Problem B] that I forgot to mention or want to expand upon.
> 3. Maintains a tone of [e.g., confident yet humble].
> 4. Avoids sounding like an AI wrote it (use varied sentence length and natural transitions)."

---

## The AI Toolkit: Essential Browser Extensions and LLM Custom Instructions

To move fast, you need a pre-configured environment.

### Essential Extensions
*   **Perplexity AI:** Use this during your research phase to find real-time company news, recent quarterly earnings, and recent product launches.
*   **Claude/ChatGPT Sidebar:** To instantly analyze LinkedIn profiles of your interviewers.

### Custom Instructions (The "Interview Architect" Profile)
Set these in your LLM "Custom Instructions" settings so you don't have to re-prompt every time:
> "When I provide a Job Description, always analyze it through the lens of 'Competency Mapping.' When I provide a story, always optimize it for the STAR method with a focus on 'High-Signal' metrics. Always prioritize technical depth and leadership verbs over generic descriptions."

---

## Continuous Learning: Using AI to Analyze Feedback and Bridge Skill Gaps

The interview process is a data-gathering mission. Every "No" is a dataset.

### The Gap Analysis Workflow
If you receive feedback (or realize you struggled with a specific question), use the **Gap Analysis Prompt**:

> "During an interview, I was asked [Question] and I struggled to answer it because [Reason/Lack of Knowledge]. 
> 1. Identify the underlying competency this question is testing.
> 2. Create a 3-day intensive learning roadmap to bridge this specific knowledge gap.
> 3. Suggest 3 'High-Signal' talking points I can use in future interviews to demonstrate I have since mastered this topic."

### The Feedback Loop
Keep a "Failure Log" in a Notion or Obsidian database. Feed these logs into your LLM once a month to identify patterns in your interview performance. If the AI detects a pattern of "vague responses in technical segments," you know exactly where to refocus your preparation.