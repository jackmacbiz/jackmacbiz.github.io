# AI-Generated STAR Response Framework (Pre-filled for common behavioral prompts)

## Instructions
Use this framework to transform raw experiences into high-impact interview responses. For every prompt, follow the **S**ituation, **T**ask, **A**ction, and **R**esult structure. Ensure every **Action** highlights a specific skill and every **Result** includes a quantifiable metric.

---

## 🛠 The STAR Workflow Checklist
- [ ] **Situation:** Set the scene (Who, Where, When). Keep it under 2 sentences.
- [ ] **Task:** Define the specific challenge or goal. What was the "pain point"?
- [ ] **Action:** Detail the specific steps **you** took. Use active verbs (e.g., *Architected*, *Negotiated*, *Automated*).
- [ ] **Result:** State the outcome. Use numbers, percentages, or time saved.
- [ ] **Reflection (The Pro Move):** Briefly state what you learned or how you would apply this to the new role.

---

## 📝 Pre-filled Response Templates

### Prompt 1: "Tell me about a time you handled a difficult conflict within a team."
*   **Situation:** [Insert project/team context]
*   **Task:** [Identify the disagreement/friction point]
*   **Action:** [Describe how you initiated a 1-on-1 or facilitated a resolution meeting]
*   **Result:** [e.g., Project timeline maintained; team morale stabilized; zero turnover]

### Prompt 2: "Describe a time you failed to meet a deadline or expectation."
*   **Situation:** [Insert specific deadline/deliverable]
*   **Task:** [What was the expected outcome?]
*   **Action:** [How did you communicate the delay? What corrective measures did you implement?]
*   **Result:** [e.g., New deadline met; implemented a new tracking system to prevent recurrence]

### Prompt 3: "Give an example of a time you used data to solve a problem."
*   **Situation:** [Insert business problem/metric in decline]
*   **Task:** [Identify the specific metric that needed improvement]
*   **Action:** [Describe the data analysis/tooling used to identify the root cause]
*   **Result:** [e.g., Reduced churn by 15%; increased conversion by 2.5%]

### Prompt 4: "Tell me about a time you had to lead a project with little direction."
*   **Situation:** [Insert ambiguous project launch/assignment]
*   **Task:** [Define the undefined goal]
*   **Action:** [How did you research, stakeholder-map, or build the initial framework?]
*   **Result:** [e.g., Successful delivery of