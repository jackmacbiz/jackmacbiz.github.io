# Post-Interview Follow-up Email Generator (Prompt sequences for different outcomes)

## Product: The AI-Powered Interview Architect: Master the Prompt-to-Offer Workflow

### Instructions
Use the following prompt sequences to generate high-impact follow-up emails. For best results, paste the specific "Context Data" into the bracketed sections of the prompt before running it through your LLM.

---

### Scenario 1: The "Standard Professional" (Post-Interview Thank You)
**Goal:** Reinforce interest and reiterate key value propositions discussed during the interview.

**Prompt Sequence:**
1. **Role:** Act as a Career Communications Expert.
2. **Task:** Draft a professional thank-you email following an interview for the [INSERT JOB TITLE] position at [INSERT COMPANY NAME].
3. **Context Data:** 
   - Interviewer Name: [INSERT NAME]
   - Key Topic Discussed: [INSERT SPECIFIC PROJECT/SKILL]
   - Connection Point: [INSERT PERSONAL DETAIL OR SHARED INTEREST]
   - Value Add: [INSERT 1-SENTENCE RECAP OF HOW YOU SOLVE THEIR PROBLEM]
4. **Constraint:** Keep the tone appreciative but concise. Avoid fluff. Ensure the subject line is clear and professional.

---

### Scenario 2: The "Value-Add" (Sending a Follow-up Resource)
**Goal:** Demonstrate "Day 1" utility by providing a solution or insight related to an interview pain point.

**Prompt Sequence:**
1. **Role:** Act as a High-Level Consultant.
2. **Task:** Write a follow-up email that provides a "value-add" resource mentioned during the interview.
3. **Context Data:**
   - Interviewer Name: [INSERT NAME]
   - Problem Discussed: [INSERT CHALLENGE THE TEAM IS FACING]
   - Resource/Idea: [INSERT LINK TO ARTICLE, PORTFOLIO PIECE, OR BRIEF STRATEGY IDEA]
   - Connection: Link this resource directly to how it addresses [INSERT PROBLEM].
4. **Constraint:** The email must not feel like "homework" for the interviewer. It should be a "thought you might find this useful" approach.

---

### Scenario 3: The "Nudge" (Checking Status After Silence)
**Goal:** Politely request an update on the hiring timeline without appearing desperate.

**Prompt Sequence:**
1. **Role:** Act as a Professional Executive.
2. **Task:** Draft a follow-up email to check the status of my application for [INSERT JOB TITLE].
3. **Context Data:**
   - Last Interview Date: [INSERT DATE]
   - Interviewer Name: [INSERT NAME]
   - Deadline Mentioned: [INSERT DATE IF APPLICABLE, OTHERWISE DELETE]
4. **Constraint:** Use a