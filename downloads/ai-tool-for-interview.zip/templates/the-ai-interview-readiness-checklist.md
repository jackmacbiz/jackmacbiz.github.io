# The AI Interview Readiness Checklist

## Phase 1: Input Optimization (The Prompt Foundation)
- [ ] **Job Description Scrape**: Have you pasted the full, raw job description into the Architect to identify core competencies?
- [ ] **Resume Alignment**: Has your current resume been uploaded to the tool to identify "experience gaps" relative to the JD?
- [ ] **Context Injection**: Have you provided specific details regarding company culture, recent news, or mission statements to the prompt?

## Phase 2: Scenario Generation (The Simulation)
- [ ] **Behavioral Question Bank**: Has the tool generated at least 10 STAR-method (Situation, Task, Action, Result) prompts based on the JD?
- [ ] **Technical/Role-Specific Deep Dive**: Have you run the "Technical Stress Test" prompt to generate industry-specific edge cases?
- [ ] **Reverse Interviewing**: Have you used the tool to generate 5 high-impact questions to ask the interviewer?

## Phase 3: Response Refinement (The Polish)
- [ ] **The STAR Refiner**: Have you processed your raw answers through the Architect to ensure every "Action" and "Result" is quantifiable?
- [ ] **Tone Check**: Has the tool audited your responses for professional confidence and alignment with the target company's brand voice?
- [ ] **Gap Mitigation**: Have you drafted "Bridge Statements" for any identified weaknesses or missing skills in your profile?

## Phase 4: Final Execution (The Rehearsal)
- [ ] **Verbal Dry Run**: Have you read the AI-optimized responses aloud to ensure natural cadence?
- [ ] **Follow-up Automation**: Have you used the tool to draft a personalized "Thank You" template based on the interview's specific discussion points?