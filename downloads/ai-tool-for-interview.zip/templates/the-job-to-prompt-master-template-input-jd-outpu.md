# The 'Job-to-Prompt' Master Template (Input JD, Output Interview Guide)

## Phase 1: The Input (Raw Data)
*Paste the following details from the Job Description (JD) below:*
- **Job Title:** [Insert Title]
- **Core Responsibilities:** [Paste key bullet points]
- **Required Technical Skills:** [List hard skills/tools]
- **Soft Skill Requirements:** [List behavioral traits]
- **Company Culture/Values:** [Paste mission statement or values]
- **Target Interview Stage:** [e.g., Recruiter Screen, Technical, or Hiring Manager]

## Phase 2: The Prompt Construction (The Engine)
*Use this structured prompt template to generate your guide. Copy/Paste into your LLM:*

> **Role:** You are an expert Technical Recruiter and Interview Coach.
> **Task:** Transform the provided Job Description into a comprehensive Interview Preparation Guide.
/
> **Context:** I am preparing for an interview for the [Insert Job Title] position.
>
> **Instructions:**
> 1. **Analyze the JD:** Identify the top 3 "Critical Success Factors" for this role.
> 2. **Generate Behavioral Questions:** Create 5 STAR-method questions based on the soft skills identified.
> 3. **Generate Technical/Skill Questions:** Create 5 deep-dive questions targeting the [Insert Technical Skills] listed.
> 4. **Predict "Curveball" Questions:** Identify 2 high-difficulty questions based on potential gaps in the JD.
> 5. **Draft "Reverse Interview" Questions:** Provide 3 sophisticated questions for me to ask the interviewer to demonstrate high-level strategic thinking.
> 6. **Answer Framework:** For every question, provide a "Winning Logic" snippet (what the interviewer is actually looking for).
>
> **Input Data:**
> [PASTE PHASE 1 DATA HERE]

## Phase 3: The Output Checklist (Verification)
*Once the AI generates the guide, verify it against these criteria:*
- [ ] **Alignment Check:** Does every question map directly to a requirement in the JD?
- [ ] **Depth Check:** Are the technical questions specific enough to test actual competency?
- [ ] **Strategy Check:** Does the "Reverse Interview" section include questions about company growth or pain points?
- [ ] **Actionability:** Do the "Winning Logic" snippets provide clear instructions on how to structure my answers?