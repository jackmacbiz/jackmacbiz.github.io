# AI Prompt Library for Hardscape and Softscape Textures

## 🛠️ Hardscape Texture Prompts
*Use these prompts to define structural elements and-built environments.*

- [ ] **Paving & Stone:** `[Material Type: e.g., Bluestone, Flagstone, Pavers] + [Pattern: e.g., Herringbone, Running Bond] + [Finish: e.g., Honed, Sandblasted, Riven] + [Setting: e.g., Patio, Walkway, Driveway]`
- [ ] **Retaining Walls:** `[Material: e.g., Stacked Slate, Timber, Concrete Block] + [Texture: e.g., Rough-heced, Smooth, Weathered] + [Scale: e.g., Low-profile, Multi-tiered]`
- [ ] **Water Features:** `[Type: e.g., Infinity Edge, Cascading Waterfall] + [Basin Material: e.g., Polished Granite, Natural River Rock] + [Water Movement: e.g., Still, Turbulent, Rushing]`
- [ ] **Edging & Borders:** `[Material: e.g., Steel Edging, Cobblestone, Corten Steel] + [Visual Weight: e.g., Minimalist, Chunky, Integrated]`

## 🌿 Softscape & Planting Prompts
*Use these prompts to define organic elements and biological density.*

- [ ] **Groundcover Density:** `[Species: e.g., Creeping Thyme, Mondo Grass] + [Coverage: e.g., Carpet-like, Sparse, Interspersed with Mulch]`
- [ ] **Foliage Texture:** `[Leaf Type: e.g., Needle-like, Broad-leaf, Serrated] + [Gloss: e.g., Matte, Waxy, Glossy] + [Color Palette: e.g., Deep Forest Green, Variegated Silver]`
- [ ] **Shrubbery & Layering:** `[Structure: e.g., Rounded, Columnar, Spreading] + [Density: e.g., Dense Screen, Airy/Transparent, Massed]`
- [ ] **Seasonal State:** `[State: e.g., Spring Budding, Autumnal Decay, Winter Dormancy, Full Bloom]`

## 📐 Technical Modifiers (Global Settings)
*Append these to any prompt to ensure architectural accuracy.*

- [ ] **Lighting/Shadow:** `[Time of Day: e.g., Golden Hour, High Noon, Overcast] + [Shadow Quality: e.g., Sharp/Defined, Soft/Diffuse]`
- [ ] **Camera Angle:** `[Perspective: e.g., Bird's Eye View, Eye-Level, Close-up Macro, Wide-Angle]`
- [ ] **Rendering Style:** `[Style: