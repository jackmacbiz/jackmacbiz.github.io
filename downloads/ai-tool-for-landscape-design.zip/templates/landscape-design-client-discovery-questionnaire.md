# Landscape Design Client Discovery Questionnaire

## 1. Project Overview
- [ ] **Client Name/Contact Information:**
- [ ] **Property Address:**
- [ ] **Project Type:** (e.g., Residential, Commercial, Public Space)
- [ ] **Primary Goal:** (e.g., Entertaining, Relaxation, Curb Appeal, Food Production)
- [  ] **Estimated Budget Range:**

## 2. Site Analysis & Environment
- [ ] **Sun Exposure:** (Full Sun, Partial Shade, Deep Shade)
- [ ] **Soil Type:** (Clay, Sandy, Loamy, Silt)
- [ ] **Existing Features to Keep:** (Trees, Retaining Walls, Water Features, Hardscape)
- [ ] **Existing Features to Remove:** (Old Decks, Overgrown Shrubs, Broken Fencing)
- [ ] **Drainage Concerns:** (Low spots, pooling water, runoff issues)

## 3. Functional Requirements (The "Program")
- [ ] **Hardscape Needs:**
    - [ ] Patio/Deck
    - [ ] Walkways/Paths
    - [ ] Fire Pit/Outdoor Kitchen
    - [ ] Pergola/Arbor
- [ ] **Softscape/Planting Preferences:**
    - [ ] Native Species Focus
    - [ ] Pollinator/Wildlife Friendly
    - [ ] Low Maintenance/Xeriscaping
    - [ ] Seasonal Color Interest
- [ ] **Specialized Zones:**
    - [ ] Children's Play Area
    - [ ] Pet-Friendly Zones
    - [ ] Vegetable/Herb Garden
    - [ ] Water Feature (Pond/Stream)

## 4. Aesthetic & Style
- [ ] **Preferred Design Style:** (e.g., Modern/Minimalist, English Cottage, Mediterranean, Zen/Japanese, Tropical)
- [ ] **Color Palette Preference:** (e.g., Monochromatic, High Contrast, Warm Tones, Cool Tones)
- [ ] **Texture/Form Preference:** (e.g., Structured/Geometric, Wild/Naturalistic)

## 5. Logistics & Constraints
- [ ] **Timeline/Deadline:**
- [ ] **Accessibility Needs:** (ADA compliance, wide paths, flat surfaces)
- [ ] **Maintenance Level:** (Low, Medium, High)
- [ ] **Privacy Requirements:** (Screening from neighbors, fencing, tall hedges)

## 6. Additional Notes & Inspiration
*Use this space to note specific imagery, textures, or "must-have" elements discussed during the consultation.*