# Project Costing and Material Estimation Worksheet

## 1. Project Overview
- [ ] Project Name: ____________________
- [ ] Client Name: ____________________
- [ ] Site Address: ____________________
- [ ] Design Date: ____________________
- [ ] Estimated Completion Date: ____________________

## 2. Hardscape Materials (Calculated via AI Blueprint)
| Material Type | Unit (sq ft / linear ft / cubic yd) | Quantity Required | Unit Cost ($) | Total Cost ($) |
| :--- | :--- | :--- | :--- | :--- |
| Pavers/Stone | | | | |
| Gravel/Decomposed Granite | | | | |
| Retaining Wall Blocks | | | | |
| Concrete (Yardage) | | | | |
| Edging/Bordering | | | | |

## 3. Softscape & Planting
| Plant Species | Quantity (Units) | Pot/Root Size | Unit Cost ($) | Total Cost ($) |
| :--- | :--- | :--- | :--- | :--- |
| Trees | | | | |
| Shrubs | | | | |
| Perennials/Flowers | | | | |
| Groundcover/Mulch | | | | |
| Sod/Turf | | | | |

## 4. Infrastructure & Irrigation
- [ ] Sprinkler Heads/Zones: $__________
- [ ] Drip Irrigation Tubing: $__________
- [ ] Lighting Fixtures/Wiring: $__________
- [ ] Drainage/French Drain Components: $__________

## 5. Labor & Equipment
- [ ] Site Preparation/Demolition: $__________
- [ ] Grading/Excavation: $__________
- [ ] Installation Labor (Hours x Rate): $__________
- [ ] Equipment Rental (Skid steer, etc.): $__________

## 6. Summary Totals
- [ ] **Subtotal Materials:** $__________
- [ ] **Subtotal Labor/Equipment:** $__________
- [ ] **Contingency Fund (15%):** $__________
- [ ] **TOTAL PROJECT ESTIMATE:** $__________