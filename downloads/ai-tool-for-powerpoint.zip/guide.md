# The AI-Powered Presentation Architect: A Professional Kit for Automated Slide Generation

## Overview

The traditional method of creating presentations is a manual, labor-intensive process of "Copy-Paste-Format." This approach is not only slow but prone to human error and inconsistent design. As a professional, your value lies in your insight and strategy, not in your ability to align text boxes or select hex codes.

This guide introduces the **Hybrid Automation Framework**. We are not simply using "AI to write text"; we are building a pipeline that uses Large Language Models (LLM) to act as the **Logic Layer** (structuring information) and Python-based automation to act as the **Visual Layer** (executing design).

By the end of this guide, you will possess a repeatable system to transform a raw, unstructured document into a formatted, professional `.pptx` file using a combination of GPT-4o and the `python-pptx` library. This method ensures that every slide follows a strict template, every bullet point is precisely placed, and the "hallucination" risk of AI-generated visuals is mitigated by programmatic control.

---

## The Core Method: The Three-Layer Pipeline

To move beyond superficial AI slide generation, you must implement a Three-Layer Pipeline. Most users fail because they ask ChatGPT to "make a PowerPoint." This results in a text dump. Instead, you must separate the **Cognition** from the **Execution**.

### 1. The Logic Layer (The Architect)
In this layer, you use an LLM (GPT-4, Claude 3.5 Sonnet) to ingest raw data and output a structured data format—specifically **JSON**. We do not want prose; we want a schema that defines:
*   Slide Titles
*   Bullet Point Arrays
*   Image Descriptions (for DALL-E or Midjourney)
*   Data Table Arrays

### 2. The Parsing Layer (The Bridge)
This is where **Prompt Chaining** occurs. You take the JSON output from the Logic Layer and pass it through a secondary instruction set that cleans the data, ensures no illegal characters exist for Python, and maps the "Slide Type" (e.g., Title Slide vs. Content Slide) to specific layout IDs.

### 3. The Visual Layer (The Builder)
This layer uses a Python script utilizing `python-pptx`. The script reads the JSON, iterates through the objects, and physically places text, shapes, and images onto the slides using precise coordinate geometry (Inches).

---

## Step-by-Step Implementation

### Step 1: Designing the JSON Schema
Before prompting, you must define your "Contract." If the AI provides a key called `Slide_Title` and your Python script looks for `title`, the automation will crash.

**Your Prompt Instruction for the Logic Layer:**
> "Extract the key insights from the attached text. Output ONLY a JSON object following this schema: 
> `{"presentation_title": str, "slides": [{"layout": "title" | "content", "title": str, "bullets": [str], "image_prompt": str}]}`. 
> Do not include any conversational text."

### Step 2: The Python Automation Engine
Below is the production-ready script. This script handles the heavy lifting of converting your structured JSON into a physical file.

```python
import json
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN

def generate_presentation(json_data, output_file="output_presentation.pptx"):
    """
    Parses JSON data and generates a formatted PowerPoint presentation.
    """
    # Load the data
    try:
        data = json.loads(json_data)
    except json.JSONDecodeError as e:
        print(f"Error: Failed to parse JSON. {e}")
        return

    # Initialize Presentation
    prs = Presentation()

    # 1. Create Title Slide
    title_slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(title_slide_layout)
    title = slide.shapes.title
    subtitle = slide.placeholders[1]
    
    title.text = data.get("presentation_title", "Untitled Presentation")
    subtitle.text = "Generated via AI-Automated Pipeline"

    # 2. Iterate through content slides
    # We assume layout 1 is the 'Title and Content' layout in standard templates
    content_layout = prs.slide_layouts[1]

    for slide_info in data.get("slides", []):
        slide = prs.slides.add_slide(content_layout)
        
        # Set Title
        title_shape = slide.shapes.title
        title_shape.text = slide_info.get("title", "No Title")

        # Set Body Content
        body_shape = slide.placeholders[1]
        tf = body_shape.text_frame
        tf.word_wrap = True

        bullets = slide_info.get("bullets", [])
        for i, bullet_text in enumerate(bullets):
            if i == 0:
                p = tf.paragraphs[0]
            else:
                p = tf.add_paragraph()
            
            p.text = bullet_text
            p.level = 0
            p.font.size = Pt(18)

        # 3. Advanced: Adding a placeholder for an image if prompt exists
        # In a full pipeline, you would use an API call to DALL-E here
        image_desc = slide_info.get("image_prompt", "")
        if image_desc:
            # Creating a text box to act as an 'Image Caption' placeholder
            left = Inches(5)
            top = Inches(4)
            width = Inches(4)
            height = Inches(1)
            txBox = slide.shapes.add_textbox(left, top, width, height)
            tf_img = txBox.text_frame
            tf_img.text = f"[IMAGE PLACEHOLDER: {image_desc}]"

    # Save the presentation
    prs.save(output_file)
    print(f"Success: {output_file} has been created.")

# --- TEST DATA (Simulating LLM Output) ---
raw_llm_output = """
{
    "presentation_title": "The Future of Renewable Energy",
    "slides": [
        {
            "layout": "content",
            "title": "Solar Energy Trends",
            "bullets": [
                "Photovoltaic efficiency increased by 22% in 2023.",
                "Cost per watt has dropped below $0.03.",
                "Integration with smart grids is accelerating."
            ],
            "image_prompt": "A high-tech solar farm at sunset with blue and orange lighting"
        },
        {
            "layout": "content",
            "title": "Wind Power Expansion",
            "bullets": [
                "Offshore wind capacity is projected to triple by 2030.",
                "New turbine designs allow for lower wind speeds.",
                "Maintenance is being automated via drones."
            ],
            "image_prompt": "Cinematic shot of massive wind turbines in the ocean"
        }
    ]
}
"""

if __name__ == "__main__":
    generate_presentation(raw_llm_output)
```

### Step 3: Prompt Chaining (The Intelligence Layer)
To ensure the "Visual Layer" (Python) doesn't fail, you must implement a **Verification Prompt**. 

**The Chain:**
1.  **Prompt A (Extraction):** "Read this report and summarize the 5 key points."
2.  **Prompt B (Structuring):** (Input = Output of Prompt A) "Take these 5 points and format them into the JSON schema provided [Insert Schema]. Ensure every bullet is a single sentence."
3.  **Prompt C (Validation):** (Input = Output of Prompt B) "Check this JSON for syntax errors. Ensure all keys match the schema. Output ONLY the valid JSON."

---

## Advanced Prompt Engineering for Data Visualization

When your presentation includes data, you cannot rely on the LLM to "draw" a chart. Instead, you must prompt the LLM to output **Data Arrays**.

**The Technique: The "Data-to-Table" Prompt**
Instead of asking for a summary, use this prompt:
> "Analyze the following revenue data. Output a JSON array called `chart_data` where each element contains `label` (string) and `value` (float). 
> Example: `[{"label": "Q1", "value": 45000}, {"label": "Q2", "value": 52000}]`."

In your Python script, you then use `slide.shapes.add_chart()` to ingest this specific array. This prevents the AI from hallucinating numbers that don't exist in your source text.

---

## Deep Dive: The Transformation Process

Let’s look at a real-world transformation of a messy input into a structured output.

**Input Text (The Mess):**
*"Hey, so we looked at the sales. Basically, January was okay at 10k, but February crashed to 2k because of the blizzard. March bounced back to 15k. We need to focus on marketing for Q2. Also, maybe add a slide about the new team members: Sarah and Mike joined."*

**The Logic Layer Prompt:**
*"Transform this unstructured text into a JSON slide array. Group the sales data into a 'Sales Performance' slide and the new hires into a 'Team Update' slide."*

**The Resulting Raw Output (The JSON):**
```json
{
  "presentation_title": "Monthly Sales & Team Update",
  "slides": [
    {
      "title": "Sales Performance",
      "bullets": ["Jan: $10,000", "Feb: $2,000 (Weather Impact)", "Mar: $15,000"],
      "image_prompt": "A professional bar chart showing upward trend"
    },
    {
      "title": "Team Update",
      "bullets": ["Welcome Sarah!", "Welcome Mike!"],
      "image_prompt": "A group of diverse professionals smiling"
    }
  ]
}
```
**The Transformation Benefit:** The Python script now has exact strings to place in `title.text` and `tf.text`, removing all the "Hey, so..." and "Basically..." conversational filler.

---

## Troubleshooting Common `python-pptx` Errors

1.  **`KeyError: 'bullets'`**: This occurs when the LLM forgets to include the `bullets` key for a specific slide. 
    *   *Fix:* Always use `.get("bullets", [])` in your Python code to provide a default empty list.
2.  **`TypeError: object of type 'NoneType' has no len()`**: This happens when the LLM returns `null` for a slide.
    *   *Fix:* Implement a check: `if slide_info is not None:`.
3.  **Text Overflow**: AI-generated bullets are often too long for the standard text box.
    *   *Fix:* In your Python script, implement a character counter. If `len(text) > 200`, programmatically truncate the text or trigger a "Prompt B" to "Summarize this bullet point to under 100 characters."
4.  **Missing `Inches` Import**: If you attempt to position an image using `Inches(1)` without `from pptx.util import Inches`, the script will throw a `NameError`. Always verify your imports.

---

## Checklist for Success

- [ ] **Schema Lockdown**: Have you provided the LLM with a strict JSON schema?
- [ ] **Prompt Chaining**: Are you using a secondary prompt to validate the JSON syntax?
- [ ] **Coordinate Precision**: Are you using `Inches` or `Pt` for all text placements to ensure consistency?
- [ ] **Error Handling**: Does your Python script use `.get()` instead of direct key access?
- [ ] **Image Strategy**: Have you included an `image_prompt` key in your JSON to facilitate future DALL-E integration?
- [ ] **Data Integrity**: Are you extracting numbers as `floats` rather than strings to allow for automated charting?