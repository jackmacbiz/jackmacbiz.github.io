# AI PowerPoint Generator: Pre-Flight Checklist

## 1. Input Preparation
- [ ] **Core Topic Defined**: Clear, singular subject matter identified.
- [ ] **Target Audience Identified**: (e.g., Investors, Students, Internal Stakeholders).
- [ ] **Key Message/Thesis**: The one thing the audience must remember.
- [ ] **Raw Data/Notes Ready**: Gathered bullet points, statistics, or research snippets.

## 2. Prompt Engineering (The "AI Instruction" Phase)
- [ ] **Context Injection**: Did you tell the AI *who* is presenting and *why*?
- [ ] **Structure Specification**: Defined slide count and specific section headers.
- [ ] **Tone Setting**: (e.g., Professional, Minimalist, High-Energy, Academic).
- [ ] **Constraint Check**: Specified "No jargon" or "Use specific terminology" instructions.

## 3. Visual & Design Audit
- [ ] **Image Consistency**: Do all AI-generated images follow the same style/aesthetic?
- [ ] **Brand Alignment**: Are colors and fonts consistent with company branding?
- [ ] **Layout Readability**: Text-to-image ratio allows for easy scanning.
- [ ] **Data Visualization**: Charts and graphs are legible and accurately represent the data.

## 4. Fact-Checking & Human Review (Critical)
- [ ] **Hallucination Sweep**: Verified all dates, names, and statistics against primary sources.
- [ ] **Logical Flow**: Transitions between slides create a coherent narrative.
- [ ] **Grammar/Syntax**: Removed "AI-typical" phrasing or repetitive sentence structures.
- [ ] **Call to Action (CTA)**: Final slide clearly directs the audience on next steps.

## 5. Final Export
- [ ] **Format Check**: Exported to `.pptx` or `.pdf` as required.
- [ ] **Compatibility Test**: Opened in standard PowerPoint/Google Slides to check for broken elements.