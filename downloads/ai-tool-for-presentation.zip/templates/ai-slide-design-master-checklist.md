# AI Slide Design Master Checklist
**Product:** The AI-Powered Pitch Deck Architect

## 1. Pre-Generation Strategy
- [ ] **Core Narrative Defined:** Is the "Problem/Solution" arc clearly articulated for the AI prompt?
- [ ] **Audience Persona Identified:** (e.g., VC, Seed Stage, Enterprise)
- [ ] **Key Value Proposition (KVP):** Is the one-sentence "hook" ready for the AI to expand?
- [ ] **Data Readiness:** Are all critical metrics, market sizes (TAM/SAM/SOM), and milestones compiled?

## 2. AI Prompt Engineering (The Input)
- [ ] **Context Injection:** Does the prompt include industry-specific terminology?
- [ ] **Tone Setting:** Is the persona defined (e.g., "Professional, minimalist, data-driven, visionary")?
- [ ] **Structural Constraints:** Have you specified the slide count and required sections (e.g., "Include a Team slide and a Roadmap slide")?
- [ ] **Visual Directives:** Are instructions for imagery style (e.g., "Photorealistic," "Flat vector," "Isometric") included?

## 3. Visual & Layout Audit (The Output)
- [ ] **Hierarchy Check:** Does the AI-generated text follow a logical flow (Headline $\rightarrow$ Sub-headline $\rightarrow$ Body)?
- [ ] **Consistency Check:** Do all slides use the same font families and color palette?
- [ ] **Image Relevance:** Do the AI-generated images/icons directly support the slide's text, or are they generic filler?
- [ ] **Whitespace Management:** Are slides cluttered, or is there enough "breathing room" for readability?

## 4. Data & Accuracy Verification
- [ ] **Fact-Check:** Have all AI-generated claims and statistics been verified against real-world data?
- [ ] **Placeholder Audit:** Have all "[Insert Data Here]" or "[Insert Name]" markers been replaced with actual content?
- [ ] **Chart Integrity:** Do the AI-generated charts accurately represent the provided numerical data?

## 5. Final Polish & Export
- [ ] **Call to Action (CTA):** Is the final slide a clear, actionable instruction for the investor?
- [ ] **Format Compatibility:** Is the deck exported in a high-resolution, editable format (PPTX/PDF)?
- [ ] **Link Verification:** Do all embedded links or prototype links function correctly?