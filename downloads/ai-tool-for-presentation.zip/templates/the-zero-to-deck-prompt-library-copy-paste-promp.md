# The 'Zero-to-Deck' Prompt Library (Copy-Paste Prompts)

## 📋 Instructions
Use these prompts in sequence to transform a raw idea into a professional, investor-ready pitch deck using The AI-Powered Pitch Deck Architect.

## 🛠️ Phase 1: The Foundation (Narrative & Structure)
- [ ] **The Vision Prompt:** "I am building [Product Name], a [Product Category] that solves [Problem] for [Target Audience]. Write a 10-slide pitch deck outline following the Sequoia Capital framework, focusing on the 'Why Now' and 'Market Opportunity' slides."
- [ ] **The Problem Deep-Dive:** "Analyze the following pain points: [List Pain Points]. Generate three compelling problem statements for my pitch deck that emphasize the cost of inaction for [Target Audience]."
- [ ] **The Value Prop Refiner:** "Transform this feature list: [List Features] into high-impact value propositions. Each proposition must follow the format: 'Feature + Benefit = Outcome for User'."

## 🎨 Phase 2: Visual & Content Generation
- [ ] **The Slide Script Generator:** "For a slide titled '[Slide Title]', write a concise script for a presenter. Include 3 bullet points (max 10 words each) and a suggestion for a high-impact visual/diagram that illustrates [Specific Data/Concept]."
- [ ] **The Data Storyteller:** "I have this data: [Insert Raw Data/Metrics]. Convert this into a narrative-driven caption for a 'Traction' slide that highlights growth momentum and scalability."
- [ ] **The Hook Creator:** "Generate 5 different 'Opening Hook' options for my presentation. Mix styles: one data-driven, one storytelling-based, and one provocative question regarding [Industry Trend]."

## ⚖️ Phase 3: The Stress Test (Investor Q&A Prep)
- [ ] **The Devil's Advocate:** "Act as a skeptical Venture Capitalist. Review this slide content: [Paste Slide Text]. Identify 3 logical gaps or weaknesses in the argument and suggest how to strengthen the supporting evidence."
- [ ] **The Competitor Comparison Prompt:** "Based on my product [Product Name], create a feature-comparison matrix text for a 'Competition' slide. Compare us against [Competitor A] and [Competitor B] across [Metric 1], [Metric 2], and [Metric 3]."

## ✅ Final Checklist Before Export
- [ ] All slides follow a single, cohesive narrative thread.
- [ ] Text density is low (no "walls of text").
- [ ] Every claim is backed by a specific metric or visual cue.
- [ ] The "Ask" slide clearly defines the funding amount and use of proceeds.