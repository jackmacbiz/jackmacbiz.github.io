# Automated Literature Review Checklist

**Product:** The AI-Powered Research Engine: A Systematic Framework for Rapid Intelligence Gathering

## 1. Pre-Search Configuration
- [ ] **Research Question Defined:** Is the core inquiry specific, measurable, and bounded?
- [ ] **Keyword Matrix Developed:** Have primary, secondary, and Boolean (AND/OR) terms been identified?
- [ ] **Scope Parameters Set:** Are inclusion/exclusion criteria (date range, language, peer-review status) documented?
- [ ] **Database Selection:** Have relevant repositories (arXiv, PubMed, Google Scholar, etc.) been identified?

## 2. Automated Discovery & Extraction
- [ ] **Query Execution:** Have all identified search strings been run across selected engines?
- [ ] **Deduplication Complete:** Has a tool (e.g., Zotero, Mendeley) been used to remove duplicate entries?
- [ ] **Metadata Extraction:** Are titles, authors, abstracts, and publication dates captured in a structured format?
- [ ] **Full-Text Retrieval:** Have accessible PDFs or HTML versions been downloaded/linked?

## 3. AI-Assisted Screening
- [ ] **Title/Abstract Screening:** Has an LLM/AI tool been used to filter papers based on inclusion criteria?
- [ ] **Automated Relevance Scoring:** Has each paper been assigned a confidence score for relevance?
- [ ] **Conflict Resolution:** Have discrepancies in AI-driven screening been manually verified?

## 4. Data Extraction & Synthesis
- [ ] **Feature Extraction:** Has the AI extracted key methodologies, sample sizes, and findings?
- [ ] **Gap Analysis:** Has the tool identified contradictions or missing information in the current literature?
- [ ] **Citation Mapping:** Has the "snowballing" process (forward/backward citation tracking) been automated?

## 5. Quality Assessment & Final Output
- [ ] **Bias Check:** Has the AI-generated summary been audited for hallucination or omission?
- [ ] **Structured Summary Generated:** Is the final output formatted into a synthesis matrix or systematic review table?
- [ ] **Audit Trail Ready:** Are all source URLs and DOI links preserved for verification?