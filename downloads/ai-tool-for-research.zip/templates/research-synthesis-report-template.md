# Research Synthesis Report Template

## 1. Executive Summary
- [ ] **Core Objective:** Define the primary research question or hypothesis.
- [ ] **Key Findings:** Summarize the top 3 critical insights discovered.
- [ ] **Actionable Recommendation:** State the immediate next step or decision required.

## 2. Intelligence Scope
- [ ] **Search Parameters:** List keywords, databases, and specific AI tools utilized.
- [ ] **Data Sources:** Document URLs, paper titles, or datasets analyzed.
- [ ] **Timeframe:** Specify the temporal range of the data gathered.

## 3. Systematic Framework Analysis
- [ ] **Pattern Recognition:** Identify recurring themes or contradictions across sources.
- [ ] **Signal vs. Noise:** Filter out low-relevance data; highlight high-impact signals.
- [ ] **Tool Performance:** Evaluate the accuracy and efficiency of AI agents/engines used.

## 4. Evidence Matrix
| Source ID | Key Data Point | Confidence Score (1-10) | Impact on Decision |
| :--- | :--- | :--- | :--- |
| [ID] | [Extracted Fact] | [Score] | [High/Med/Low] |

## 5. Gap Analysis
- [ ] **Missing Information:** Identify specific unknowns or "blind spots."
- [ ] **Verification Requirements:** List items requiring manual human verification or secondary tool validation.

## 6. Strategic Implementation Plan
- [ ] **Phase 1 (Immediate):** Low-effort, high-impact actions.
- [ ] **Phase 2 (Follow-up):** Deep-dive research or secondary validation.
- [ ] **Phase 3 (Scale):** Integration into larger workflows or automated pipelines.

## 7. Metadata & Audit Trail
- [ ] **Researcher/Agent ID:**
- [ ] **Timestamp of Completion:**
- [ ] **Raw Data Artifact Link:**