# Source Credibility Scoring Matrix

**Project:** The AI-Powered Research Engine: A Systematic Framework for Rapid Intelligence Gathering
**Date:** [Insert Date]
**Researcher:** [Insert Name]

### 1. Source Metadata
*   **Source Name/URL:**
*   **Topic/Claim being verified:**
*   **Date of Publication:**

### 2. Scoring Rubric (Scale 1-5)
*Assign a score of 1 (Unreliable) to 5 (Gold Standard) for each criterion.*

| Criterion | Description | Score (1-5) |
| :--- | :--- | :--- |
| **Authority** | Does the author/organization have recognized expertise or credentials in this specific niche? | |
| **Verifiability** | Are there citations, raw data, or primary sources provided to support the claims? | |
| **Objectivity** | Is the content free from promotional bias, sponsored content, or inflammatory language? | |
| **Recency** | Is the information up-to-date and relevant to the current technological landscape? | |
| **Consensus** | Does this information align with or provide a documented rebuttal to established industry data? | |

### 3. Evaluation Summary
*   **Total Score (out of 25):**
*   **Confidence Level:** [Low / Medium / High]
*   **Actionable Verdict:**
    *   [ ] **USE:** High-confidence data; integrate into research engine.
    *   [ ] **CROSS-REFERENCE:** Medium-confidence; requires secondary validation.
    *   [ ] **DISCARD:** Low-confidence; potential hallucination or bias detected.

### 4. Notes & Observations
*   *Identify specific red flags (e.g., lack of author bio, circular reporting, or paywalled/unverifiable claims).*