# The Master Prompt Library for Deep-Dive Extraction

## 1. Phase: Initial Scoping & Surface Scanning
- [ ] **Entity Identification**: "Identify all key stakeholders, competitors, and core technologies mentioned in [URL/Document]."
- [ ] **Thematic Mapping**: "Extract the primary themes and recurring arguments from this dataset and categorize them into [Category A, B, C]."
- [ ] **Terminology Glossary**: "List all technical terms, acronyms, and jargon found in this text with a one-sentence definition based on context."

## 2. Phase: Structural Decomposition
- [ ] **Logic Flow Mapping**: "Trace the causal chain of arguments presented in this text. Map 'Premise -> Evidence -> Conclusion' for each section."
- [ ] **Data Point Extraction**: "Extract every numerical value, date, and statistical metric into a structured list with its associated unit and context."
- [ ] **Framework Extraction**: "Identify any underlying methodologies or step-by-step processes described in the source material."

## 3. Phase: Deep-Dive Intelligence Extraction
- [ ] **Sentiment & Bias Audit**: "Analyze the tone of the author regarding [Topic]. Identify specific linguistic markers that indicate bias or subjective opinion."
- [ ] **Gap Analysis**: "Based on the provided information, identify three specific areas where data is missing or where the argument lacks empirical support."
- [ ] **Contradiction Detection**: "Compare [Source A] and [Source B]. Highlight any direct contradictions in facts, dates, or stated outcomes."

## 4. Phase: Synthesis & Actionable Output
- [ ] **Executive Summary Generation**: "Synthesize the extracted data into a 3-bullet point summary for a C-suite audience, focusing only on revenue and risk implications."
- [ ] **SWOT Synthesis**: "Using the extracted intelligence, populate a SWOT matrix (Strengths, Weaknesses, Opportunities, Threats) for [Subject]."
- [ ] **Actionable Intelligence Conversion**: "Convert the identified 'Risks' into a prioritized list of mitigation tasks with estimated impact scores (1-10)."

## 5. Verification Checklist
- [ ] **Source Attribution**: Does every extracted fact link back to a specific section/page of the source?
- [ ] **Context Integrity**: Has the meaning been preserved, or was the data stripped of critical nuance?
- [ ] **Format Compliance**: Does the output match the required schema (JSON, Markdown, CSV, or Table)?