# ATS Keyword Extraction & Mapping Worksheet

**Target Job Title:** [Insert Job Title]
**Target Job Description URL:** [Insert URL]

### Phase 1: Job Description Decomposition
*Scan the job description and extract the following elements:*

- [ ] **Hard Skills (Technical):** (e.g., Python, SQL, Project Management, Salesforce, AWS)
- [ ] **Soft Skills (Behavioral):** (e.g., Cross-functional leadership, Stakeability, Agile methodology)
- [ ] **Required Certifications/Education:** (e.g., PMP, MBA, AWS Certified Solutions Architect)
- [ ] **Action Verbs used in description:** (e.g., Orchestrated, Developed, Streamlined, Spearheaded)

### Phase 2: Keyword Frequency & Priority Mapping
*Identify high-frequency terms to ensure they appear in your resume headers and bullet points.*

| Keyword/Skill | Frequency in JD | Priority (High/Med/Low) | Status (Matched/Missing) |
| :--- | :--- | :--- | :--- |
| | | | |
| | | | |
| | | | |

### Phase 3: Resume Bullet Point Engineering
*Rewrite your existing experience using the extracted keywords. Use the formula: [Action Verb] + [Quantifiable Result] + [Keyword/Skill].*

- **Original Bullet:** [Paste old bullet point here]
- **Engineered Bullet:** [Rewrite using extracted keywords and metrics]

### Phase 4: Final ATS Audit Checklist
- [ ] **Formatting Check:** No tables, images, or complex graphics that break parsing.
- [ ] **Header Check:** Standard headers used (e.g., "Work Experience" instead of "My Career Journey").
- [ ] **File Type:** Saved as .docx or .pdf (as specified by the JD).
- [ ] **Keyword Density:** All "High Priority" keywords from Phase 2 are present in the text.