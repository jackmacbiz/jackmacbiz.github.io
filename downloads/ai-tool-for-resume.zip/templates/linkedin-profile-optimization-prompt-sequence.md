# LinkedIn Profile Optimization Prompt Sequence

**Product:** The ATS-Crusher: AI-Powered Resume Engineering Kit
**Target Audience:** Job seekers, recruiters, and career professionals.
**Goal:** Use the engineering principles from the ATS-Crusher kit to transform a passive LinkedIn profile into an active, keyword-optimized magnet for recruiters.

---

### 🛠 Phase 1: The Headline Reconstruction (Keyword Injection)
*Objective: Move from a "Job Title" headline to a "Value + Keyword" headline.*

**Prompt Template:**
> "I am using the ATS-Crusher methodology to optimize my LinkedIn headline. Here is my current resume/experience: [Paste Resume Text]. Based on the high-ranking keywords found in the ATS-Crusher engineering kit for [Target Job Title] roles, rewrite my LinkedIn headline into 5 different versions. Each version must include: 1. Core Job Title, 2. Top 3 hard skills/keywords, and 3. A measurable achievement or value proposition. Avoid fluff like 'passionate' or 'motivated'."

---

### 📝 Phase 2: The 'About' Section (The Narrative Engine)
*Objective: Convert a summary into a searchable, achievement-driven story.*

**Prompt Template:**
> "Using the 'Achievement-First' framework from the ATS-Crusher kit, rewrite my LinkedIn 'About' section. 
> **Input Data:** [Paste Resume/Experience]. 
> **Instructions:** 
> 1. Write in the first person. 
> 2. Start with a 'Hook' that highlights a major professional win. 
> 3. Integrate a 'Core Competencies' block using industry-standard keywords identified in the kit. 
> 4. Use bullet points for readability. 
> 5. End with a clear Call to Action (e.g., 'Open to discussing [Industry] opportunities')."

---

### 📈 Phase 3: Experience Deep-Dive (Bullet Point Engineering)
*Objective: Transform task-based descriptions into impact-based metrics.*

**Prompt Template:**
> "I am optimizing my Experience section using the ATS-Crusher 'Action-Metric-Result' (AMR) formula. 
> **Current Bullet Point:** [Paste old bullet point]. 
> **Task:** Rewrite this bullet point to be more impactful. Ensure it starts with a strong action verb, includes a quantifiable metric (even if I need to provide a placeholder like [X%]), and clearly states the business impact. Ensure the language is optimized for ATS scanning algorithms."

---

### ✅ Final Audit Checklist
- [ ] **Keyword Density:** Does the profile contain the top 10 keywords identified in the ATS-Crusher research for your specific niche?
- [ ] **Metric Presence:** Does every experience bullet point contain at least one number