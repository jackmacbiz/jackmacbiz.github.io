# Resume Formatting Checklist (ATS-Friendly)
**Product:** The ATS-Crusher: AI-Powered Resume Engineering Kit

## 1. File Integrity & Format
- [ ] **File Type:** Saved as .docx or .pdf (Avoid .png, .jpg, or .txt).
- [ ] **Text Layer:** Content is selectable/searchable (No scanned images of text).
- [ ] **No Tables/Columns:** Removed complex tables or multi-column layouts that break parsing.
- [ ] **No Headers/Footers:** Essential contact info is in the main body, not the header/footer margin.

## 2. Structural Hierarchy
- [ ] **Standard Headings:** Used standard labels (e.g., "Work Experience" instead of "My Professional Journey").
- [ ] **Chronological Order:** Most recent experience is listed first.
- [ ] **Clear Section Breaks:** Each section is clearly separated by line breaks or bold headers.

## 3. Keyword Optimization (The "Crusher" Method)
- [ ] **Job Description Match:** Scanned JD for high-frequency nouns and skills.
- [ ] **Hard Skill Integration:** Incorporated specific software, tools, and methodologies found in the JD.
- [ ] **No Keyword Stuffing:** Keywords are woven into achievement bullets, not just a list at the bottom.
- [ ] **Acronym + Long-form:** Used both versions (e.g., "Search Engine Optimization (SEO)").

## 4. Content & Impact
- [ ] **Action Verbs:** Every bullet starts with a strong verb (e.g., "Engineered," "Optimized," "Accelerated").
- [ ] **Quantifiable Metrics:** Every major bullet contains a number, %, or $ (e.g., "Increased revenue by 22%").
- [ ] **No First-Person Pronouns:** Removed "I," "me," or "my."
- [ ] **No Graphics/Icons:** Removed skill bars, headshots, or decorative icons that confuse parsers.

## 5. Final Audit
- [ ] **Contact Info:** Phone, Email, LinkedIn, and Location are present and hyperlinked.
- [ ] **Spelling/Grammar:** Zero typos (ATS cannot "guess" corrected spelling).
- [ ] **Font Consistency:** Used standard, web-safe fonts (e.g., Arial, Calibri, Roboto).