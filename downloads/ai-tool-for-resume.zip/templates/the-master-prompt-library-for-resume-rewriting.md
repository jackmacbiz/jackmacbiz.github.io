# The 'Master Prompt' Library for Resume Rewriting

## 🛠️ Phase 1: The Foundation (Context Injection)
*Use these prompts to feed the AI your raw data before asking for rewrites.*

- [ ] **The Raw Data Dump:** "I am going to provide my current resume, a target job description, and my core achievements. Do not rewrite anything yet. Simply acknowledge you have received the data and summarize the key requirements of the job description to confirm understanding."
- [ ] **The Skill Gap Analysis:** "Compare my current resume against the provided job description. Identify the top 5 missing keywords and 3 specific technical skills I need to emphasize to pass ATS filters."

## ✍️ Phase 2: The Engineering (The Rewrites)
*Use these prompts to transform bullet points into high-impact, metric-driven statements.*

- [ ] **The Google XYZ Formula Prompt:** "Rewrite the following bullet point using the Google XYZ formula: 'Accomplished [X] as measured by [Y], by doing [Z]'. Ensure you use strong action verbs and quantify the impact with numbers, percentages, or dollar amounts: [Insert Bullet Point]"
- [ ] **The Action Verb Injection:** "Scan my 'Experience' section. Replace all passive verbs (e.g., 'responsible for', 'handled', 'worked on') with high-impact, industry-specific action verbs (e.g., 'orchestrated', 'leveraged', 'surpassed') while maintaining the original meaning."
- [ ] **The ATS Keyword Integration:** "Seamlessly integrate the following keywords from the job description into my existing professional summary and experience bullets without making the text sound robotic or keyword-stuffed: [Insert Keywords List]"

## 🔍 Phase 3: The Polish (Optimization & Verification)
*Use these prompts for the final audit.*

- [ ] **The 'So What?' Audit:** "Read each bullet point in my rewritten resume. If a bullet point does not clearly demonstrate a measurable result or a specific value added to the company, flag it and suggest a way to add impact."
- [ ] **The Tone Consistency Check:** "Review the entire document. Ensure the tone is professional, confident, and consistent. Remove any fluff, filler words, or first-person pronouns (I, me, my) to maintain a standard executive resume format."
- [ ] **The Formatting Integrity Check:** "Analyze the structure of this resume. Ensure that headings, dates, and job titles are clearly distinguishable for a parser. Suggest any structural changes needed to ensure maximum readability for both AI and human recruiters."