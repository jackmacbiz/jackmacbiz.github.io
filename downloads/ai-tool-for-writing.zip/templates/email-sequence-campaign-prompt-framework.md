# Email Sequence Campaign Prompt Framework

## 1. Campaign Metadata
- [ ] **Product Name:** The Prompt-to-Profit Framework: AI Content Engineering for High-Conversion Copy
- [ ] **Target Audience Persona:** (e.g., Freelance Copywriters, Content Marketers, Agency Owners)
- [ ] **Core Pain Point:** (e.g., High cost of human writers, slow turnaround, low-quality AI output)
- [ ] **Primary Value Proposition:** (e.g., Transform generic AI text into high-converting, human-grade copy using engineered prompts)
- [ ] **Campaign Goal:** (e.g., Direct Sale, Webinar Registration, Lead Magnet Download)

## 2. Sequence Structure & Logic
- [ ] **Sequence Type:** (e.g., Welcome, Abandoned Cart, Nurture, Re-engagement)
- [ ] **Total Email Count:** (Number of emails in the sequence)
- [ ] **Sending Cadence:** (e.g., Day 1, Day 2, Day 4, Day 7)

## 3. Email-by-Email Prompt Instructions
*For each email in the sequence, define the following:*

### Email [Number]: [Phase Name, e.g., The Problem/Agitation]
- [ ] **Subject Line Angle:** (e.g., Fear of missing out, Curiosity, Direct Benefit)
- [ ] **The Hook:** (Specific opening line strategy)
- [ ] **The Narrative/Body:**
    - [ ] **Problem Identification:** (Describe the specific struggle with current AI usage)
    - [ ] **Agitation:** (Highlight the cost of inaction/bad copy)
    - [ ] **The Solution (The Framework):** (Introduce how the product solves the specific problem)
- [ ] **Call to Action (CTA):** (Specific link/instruction)
- [ ] **Tone/Voice Guidelines:** (e.g., Authoritative, Empathetic, Urgent)

## 4. Prompt Engineering Constraints (The "Guardrails")
- [ ] **Forbidden Words/Phrases:** (List any "AI-isms" to avoid)
- [ ] **Formatting Requirements:** (e.g., Short paragraphs, heavy use of bullet points, bolded key phrases)
- [ ] **Required Elements:** (e.g., P.S. section, testimonial snippet, link to checkout)

## 5. Post-Campaign Analysis Metrics
- [ ] **Open Rate Target:** (%)
- [ ] **CTR Target:** (%)
- [ ] **Conversion Target:** (%)