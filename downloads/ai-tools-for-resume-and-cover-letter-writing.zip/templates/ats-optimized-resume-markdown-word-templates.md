# ATS-Optimized Resume Markdown & Word Templates

## 📋 Pre-Flight Checklist: ATS Compatibility
- [ ] **File Format:** Saved as .docx or .pdf (Standard fonts only).
- [ ] **Layout:** Single-column layout (Avoid tables, headers/footers, or sidebars).
- [ ] **Parsing Check:** No images, icons, or graphics used for critical information.
- [ ] **Keywords:** Integrated specific nouns/verbs from the job description.
- [ ] **Standard Headings:** Used "Experience," "Education," and "Skills" (Avoid creative titles).

## 🛠️ Template Structure (Markdown/Word)

### 1. Contact Information
*   **Full Name**
*   **Phone Number** | **Professional Email**
*   **LinkedIn URL** | **Portfolio/GitHub Link**
*   **Location** (City, State/Remote)

### 2. Professional Summary
*   *Instruction: 3-4 lines of high-impact text. Focus on years of experience, core expertise, and one major quantifiable achievement.*
*   [Insert Summary Here]

### 3. Core Competencies (Keyword Cloud)
*   *Instruction: Use a pipe-separated list to maximize ATS keyword density.*
*   Skill A | Skill B | Skill C | Skill D | Skill E

### 4. Professional Experience
**[Company Name]** | **[Job Title]** | **[Start Date] – [End Date/Present]**
*   *Instruction: Use the STAR Method (Situation, Task, Action, Result). Start every bullet with a strong action verb.*
*   **[Action Verb]** [Quantifiable Metric] by [Action Taken] resulting in [Outcome].
*   **[Action Verb]** [Specific Tool/Technology] to optimize [Process] by [Percentage/Dollar Amount].
*   **[Action Verb]** Managed [Team Size/Budget] to achieve [Key Milestone].

### 5. Education
*   **[Degree Name]** | [University Name] | [Graduation Year]
*   *Optional: Relevant Coursework or Honors*

### 6. Technical Skills & Certifications
*   **Software/Tools:** [List relevant AI tools, CRM, or industry software]
*   **Certifications:** [Certification Name] – [Issuing Body] ([Year])

## 🤖 AI Prompting Worksheet (For Use with LLMs)
*Use these prompts to populate the templates above.*

*   **Prompt 1 (Keyword Extraction):** "I am applying for [Job Title] at [Company]. Here is the job description: [Paste JD]. Extract the top 15 most important hard skills and keywords for an ATS scan."
*   **Prompt 2 (Bullet Point Transformation):