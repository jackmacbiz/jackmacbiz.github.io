# Job Description Keyword Extraction Checklist
**Product:** The AI-Powered Career Accelerator: Resume & Cover Letter Mastery Kit

### 1. Core Competencies & Hard Skills
- [ ] Identify specific software, tools, or platforms mentioned (e.g., Python, Salesforce, Adobe Suite).
- [ ] List technical methodologies or frameworks (e.g., Agile, Six Sigma, SEO, Data Modeling).
- [ ] Note industry-specific regulations or certifications required (e.g., GDPR, CPA, PMP).

### 2. Action Verbs & Impact Indicators
- [ ] Extract high-priority verbs used to describe responsibilities (e.g., "Spearheaded," "Optimized," "Architected").
- [ ] Note verbs related to scale or growth (e.g., "Increased," "Scaled," "Reduced churn").

### 3. Soft Skills & Behavioral Traits
- [ ] Highlight interpersonal requirements (e.g., "Cross-functional collaboration," "Stakeholder management").
- [ ] Identify leadership or cultural fit descriptors (e.g., "Self-starter," "Adaptable," "Mentorship").

### 4. Role-Specific Keywords
- [ ] Capture job title variations or synonyms.
- [ ] List specific departmental terminology (e.g., "Full-cycle recruiting," "End-to-end deployment").

### 5. Priority Weighting (The "Must-Haves")
- [ ] **High Priority:** Keywords appearing in the first 3 bullets of "Requirements" or "Qualifications."
- [ ] **Medium Priority:** Keywords appearing in "Preferred Qualifications" or "Bonus Skills."
- [ ] **Low Priority:** Contextual keywords found in "About the Company" or "Company Culture" sections.

---
**Instructions for AI Prompting:**
*Copy the extracted keywords above into your AI prompt to instruct the Kit to align your existing resume bullets with these specific signals.*