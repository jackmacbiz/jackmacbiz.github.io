# Post-Interview AI Follow-up Email Scripts

### 📋 Preparation Checklist
- [ ] **Timing:** Send within 24 hours of the interview.
- [ ] **Personalization:** Reference a specific topic or challenge discussed during the interview.
- [ ] **Value Reinforcement:** Briefly reiterate how your skills solve their specific pain points.
- [ ] **Call to Action:** Confirm next steps or offer additional documentation (e.g., portfolio, references).
- [ ] **Proofread:** Use an AI grammar checker to ensure zero errors in professional tone.

---

### 📧 Template 1: The "Standard Professional" (Best for Corporate/Formal Roles)
**Subject:** Thank you: [Job Title] Interview - [Your Name]

Dear [Interviewer Name],

Thank                you for the opportunity to discuss the [Job Title] position earlier today. I truly enjoyed learning more about [Company Name]’s goals regarding [Specific Project/Goal discussed].

Our conversation reinforced my interest in the role, particularly how my experience with [Specific Skill] aligns with your current need to [Solve a specific problem]. 

I look forward to hearing from you regarding the next steps. Please let me know if you require any further information.

Best regards,

[Your Name]
[Your LinkedIn Profile]

---

### 📧 Template 2: The "Value-Add" (Best for High-Competition/Technical Roles)
**Subject:** Follow-up: [Your Name] / [Job Title]

Hi [Interviewer Name],

Thank you for your time today. I particularly enjoyed our deep dive into [Technical Topic/Challenge]. 

Reflecting on our discussion about [Problem discussed], I thought you might find this [Article/Brief Thought/Resource] interesting, as it relates to how I handled a similar situation at [Previous Company]. 

I am very excited about the possibility of bringing this proactive approach to the [Department Name] team. I am eager to continue the conversation.

Best,

[Your [Your Name]

---

### 📧 Template 3: The "Short & Sweet" (Best for Startups/Casual Cultures)
**Subject:** Great meeting you, [Interviewer Name]!

Hi [Interviewer Name],

Just wanted to send a quick note to say thank you for the chat today. It was great to hear about the vision for [Company Name].

I'm even more excited about the [Job Title] role after hearing about the team's culture of [Culture Trait]. I'm confident I can hit the ground running.

Looking forward to the next steps!

Cheers,

[Your Name]

---

### 💡 Pro-Tip for Career Accelerator Users
*Use the **AI-Powered Career Accelerator** to feed the specific "Problem/Solution" details from your interview notes into a