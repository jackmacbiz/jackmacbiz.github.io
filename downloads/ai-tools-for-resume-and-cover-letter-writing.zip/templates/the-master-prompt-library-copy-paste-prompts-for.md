# The Master Prompt Library (Copy-•Paste Prompts for ChatGPT/Claude)
## Product: The AI-Powered Career Accelerator: Resume & Cover Letter Mastery Kit

### 🛠️ Phase 1: Resume Optimization
- [ ] **The Role Alignment Prompt**
  *Goal: Tailor your existing resume to a specific job description.*
  > "I am applying for [Job Title] at [Company]. Here is the job description: [Paste JD]. Here is my current resume: [Paste Resume]. Rewrite my professional summary and bullet points to highlight the specific keywords and technical skills mentioned in the JD. Ensure you use strong action verbs and quantify achievements where possible."

- [ ] **The Achievement Quantifier**
  *Goal: Turn vague duties into metric-driven accomplishments.*
  > "I have this bullet point in my resume: '[Insert weak bullet point]'. Transform this into a high-impact, metric-driven achievement using the Google XYZ formula: 'Accomplished [X] as measured by [Y], by doing [Z]'. If I don't provide a specific number, suggest three realistic placeholder metrics I could use."

- [ ] **The Skill Gap Analyzer**
  *Goal: Identify what is missing from your profile.*
  > "Compare my resume [Paste Resume] against this job description [Paste JD]. Create a table showing: 1. Matching Skills, 2. Missing Critical Skills, and 3. Suggested Projects or Certifications I can add to bridge the gap."

### ✍️ Phase 2: Cover Letter Generation
- [ ] **The Narrative Builder**
  *Goal: Create a personalized, non-generic cover letter.*
  > "Write a professional cover letter for the [Job Title] position at [Company]. Use a tone that is [e.g., Enthusiastic/Formal/Confident]. Connect my experience in [Specific Skill] to the company's mission of [Company Mission]. Avoid clichés like 'I am writing to express my interest.' Instead, start with a hook regarding a recent achievement or a shared value."

- [ ] **The 'Why Us' Deep Dive**
  *Goal: Generate specific reasons for interest to avoid sounding generic.*
  > "Based on the company website info [Paste Info/Snippet], generate three unique 'Value Alignment' paragraphs for a cover letter that explain why I am specifically drawn to [Company Name]'s culture and recent work in [Industry/Product]."

### 🔍 Phase 3: Final Polish & Audit
- [ ] **The ATS Scanner Simulation**
  *Goal: Check for readability and keyword density.*
  > "Act as an Applicant Tracking System (ATS). Scan my resume [Paste Resume] against this JD [Paste JD]. Rate the match from 0-100% and list the top 5 keywords that are missing from my text."