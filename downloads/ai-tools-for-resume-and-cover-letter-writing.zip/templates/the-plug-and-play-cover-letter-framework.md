# The 'Plug-and-Play' Cover Letter Framework

## 1. The Hook (The Opening)
*   [ ] **The Connection:** Mention the specific role and where you found it.
*   [ ] **The Value Statement:** One sentence summarizing your "superpower" related to the job description.
*   [ *Avoid:* "I am writing to apply for..." (Too generic).
*   [ *Use:* "As a [Job Title] with a track record of [Key Metric], I was thrilled to see the opening at [Company]..."

## 2. The Bridge (The "Why You" Section)
*   [ ] **Keyword Alignment:** Identify 2-3 high-priority keywords from the job description.
*   [ ] **Evidence Injection:** Use the **Action + Context + Result** formula.
    *   *Example:* "Implemented [AI Tool] to automate [Process], resulting in [Number]% efficiency gain."
*   [ ] **Skill Mapping:** Directly link your past achievement to a specific pain point mentioned in the job posting.

## 3. The Cultural Fit (The "Why Them" Section)
*   [ ] **Company Research:** Reference a recent company milestone, mission statement, or value.
*   [ ] **Alignment Statement:** Explain why your professional philosophy matches their mission.
*   [ ] **The "Extra Mile":** Mention a specific project or product of theirs that resonates with your expertise.

## 4. The Call to Action (The Closing)
*   [ ] **Confidence Statement:** Reiterate enthusiasm for the opportunity.
*   [ ] **The Low-Friction Ask:** Suggest a brief conversation or meeting.
*   [ ] **Contact Info:** Ensure your LinkedIn and Portfolio links are hyperlinked.

## 5. Final AI-Optimization Checklist
*   [ ] **ATS Scan:** Have you used the exact terminology found in the job description?
*   [ ] **Tone Check:** Does the voice match the company culture (e.g., Professional vs. Startup/Casual)?
*   [ ] **Formatting:** Is the document clean, readable, and free of AI-generated "fluff" or repetitive sentence structures?