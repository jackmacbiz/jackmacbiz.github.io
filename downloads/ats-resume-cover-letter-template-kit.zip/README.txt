ATS RESUME TEMPLATE + COVER LETTER KIT — what's inside

1. guide.md / guide.html       — Beat the Bots: the ATS survival guide
2. ats-resume-template.txt     — single-column, ATS-safe resume (paste into Word/Google Docs/Pages)
3. cover-letter-template.txt   — fill-in 3-paragraph cover letter
4. keyword-checklist.md        — mirror the exact keywords each posting scans for
5. impact-bullet-builder.md    — turn duties into quantified, recruiter-grabbing bullets

HOW TO USE: read guide.html in any browser. Copy the resume/cover-letter templates
into your editor, replace the bracketed text, and save as .docx or a true text-layer PDF.

Personal use license. Not for resale or redistribution. Questions? Message the shop.
