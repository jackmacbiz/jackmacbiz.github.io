# Beat the Bots: The ATS Resume Survival Guide

## Your resume is read by a machine first
Before a recruiter ever sees you, an Applicant Tracking System (ATS) — Workday,
Greenhouse, Taleo, Lever — parses your file into a database and scores it against the
job. Most rejections aren't about your experience; they're about formatting the robot
couldn't read. This guide + the included templates fix that.

---

## The 5 things that get a resume auto-rejected
1. Multi-column layouts and text boxes. Parsers read top-to-bottom, left-to-right.
   A two-column template scrambles your work history into nonsense. Use ONE column.
2. Headers/footers with key info. Many ATS ignore the header/footer region — never
   put your name, phone, or email only there.
3. Graphics, icons, photos, skill bars. The robot can't read an image of a "90%
   Python" bar. Write the skill as text.
4. Non-standard section names. Use the exact headings parsers expect: "Experience,"
   "Education," "Skills," "Summary." Cute headings ("Where I've Made Magic") don't map.
5. Smart quotes and odd characters. Curly quotes and special bullets can break the
   text layer. Use straight quotes and simple bullets ( - or • ).

## File format: what parses vs. what breaks
- BEST: .docx exported from Word/Google Docs, or a TRUE text-layer PDF (Save as PDF,
  not "Print to PDF" or scan).
- The 10-second test: open your PDF, highlight a sentence, copy it, paste into a plain
  text editor. If it pastes back as garbled or merged words, the ATS sees that too —
  re-export from the source document.

## How to read a job description like the ATS does
Use the included Keyword Checklist. The ATS scores you on overlap between your resume
and the posting's language:
- Pull the exact hard skills and tools named (e.g., "Salesforce," "Python," "Six Sigma").
- Mirror the job TITLE in your summary line if it's honest to do so.
- Use the posting's wording, not synonyms. If they say "stakeholder management," don't
  write "managing partners" and hope the system connects them.

## Writing bullets that score AND impress humans
Use the Impact Bullet Builder formula:
   [Strong action verb] + [what you did] + [measurable result]
- Weak: "Responsible for managing the sales team."
- Strong: "Led a 6-person sales team to 124% of quota, adding $1.2M in new ARR."
Numbers do double duty: they raise relevance for the bot and credibility for the human.

## The 6-section resume order that always parses
1. Name + contact (in the BODY, not the header)
2. Professional Summary (3 lines, includes the target title + top keywords)
3. Skills (a clean text list of the exact tools/skills from the posting)
4. Experience (reverse-chronological, each role: title, company, dates, 3–5 impact bullets)
5. Education
6. Certifications / Projects (optional)

## Final pre-submit checklist
- [ ] Single column, no text boxes, no images of text
- [ ] Standard section headings
- [ ] Contact info in the body
- [ ] Straight quotes, simple bullets
- [ ] Top 3 job keywords appear at least twice, in context
- [ ] Saved as .docx or true text-layer PDF, copy-paste test passed
- [ ] File named: FirstName-LastName-Resume.pdf

Do this and your resume reaches a human. The rest is the interview — and the cover
letter template helps you win that, too.
