# The Impact Bullet Builder

## The formula
[Strong action verb] + [what you did] + [measurable result]

## 30 strong action verbs by category
LED / OWNED: Led, Directed, Spearheaded, Owned, Orchestrated, Managed
BUILT / CREATED: Built, Designed, Launched, Developed, Created, Engineered
GREW / IMPROVED: Increased, Grew, Accelerated, Boosted, Improved, Optimized
SAVED / REDUCED: Reduced, Cut, Streamlined, Automated, Eliminated, Consolidated
WON / DELIVERED: Delivered, Achieved, Closed, Negotiated, Secured, Exceeded

## Before -> After examples
- Before: "Responsible for social media."
  After:  "Grew Instagram following 3x (4k -> 12k) in 6 months, lifting referral traffic 40%."
- Before: "Helped with the budget."
  After:  "Managed a $250k department budget, cutting overspend 18% via vendor renegotiation."
- Before: "Worked on customer support."
  After:  "Resolved 60+ tickets/day at 98% CSAT, reducing average response time from 9h to 2h."

## Your turn (fill 3–5 per role)
1. [Verb] _______________________________ , [result with a number] _______________
2. [Verb] _______________________________ , [result with a number] _______________
3. [Verb] _______________________________ , [result with a number] _______________

## No numbers? Estimate honestly.
"Roughly how many / how much / how often / how fast?" A defensible estimate beats a
vague duty. "Handled ~40 accounts" is stronger than "handled accounts."
