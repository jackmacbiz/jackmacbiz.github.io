# Job Description Keyword Checklist

Target Role: ______________________   Company: ______________________

## 1. Hard skills & tools (exact nouns the ATS scans for)
- [ ] Primary technical skills: ________________________________________________
- [ ] Software / platforms: ___________________________________________________
- [ ] Methodologies / frameworks: _____________________________________________
- [ ] Certifications / licenses required: _____________________________________

## 2. Soft skills & behaviors (used for "fit" ranking)
- [ ] Leadership words (e.g. stakeholder, mentorship, cross-functional): _______
- [ ] Operational words (e.g. optimization, compliance, scalability): __________
- [ ] Communication words (e.g. reporting, presentation, client-facing): _______

## 3. Action verbs & outcomes to mirror in your bullets
- [ ] Action verbs found in the posting: ______________________________________
- [ ] Quantifiable targets mentioned (%, $, timeframes, headcount): ____________

## 4. Alignment check (do before you submit)
- [ ] My summary line reflects the exact job title
- [ ] Top 3 hard skills appear at least twice, in context (not just listed)
- [ ] I used the posting's wording, not synonyms
- [ ] Standard section headings the parser recognizes
