# Standard Operating Procedure (SOP) Template for New Workflows

**Product:** The Autopilot Life: A Blueprint for Personal Automation
**Niche:** Automate My Life
**Workflow Name:** [Insert Name]
**Version:** 1.0
**Owner:** [Insert Name/Role]

---

## 1. Overview
*   **Objective:** [What is the specific outcome of this automation/workflow?]
*   **Trigger:** [What event starts this process? e.g., New email, scheduled time, webhook, manual input]
*   **Frequency:** [Daily / Weekly / Monthly / On-Demand]
*   **Complexity Level:** [Low / Medium / High]

## 2. Prerequisites & Tools
*   **Required Accounts/Software:** [e.g., Zapier, Make.com, Notion, Gmail, OpenAI API]
*   **Required Credentials/API Keys:** [List necessary permissions/keys needed]
*   **Input Data Needed:** [e.g., URL, CSV file, specific email subject line]

## 3. Step-by-Step Execution Logic
- [ ] **Step 1: Trigger Activation**
    - [Detail the exact action that initiates the workflow]
- [ ] **Step 2: Data Extraction/Parsing**
    - [Detail how data is captured or transformed]
- [ ] **Step 3: Processing/Transformation**
    - [Detail any logic, AI prompts, or filtering applied]
- [ ] **Step 4: Action/Output**
    - [Detail where the final result is sent or stored]
- [ ] **Step 5: Verification/Logging**
    - [Detail how to confirm the workflow completed successfully]

## 4. Error Handling & Troubleshooting
*   **Common Failure Point:** [e.g., API Timeout, Invalid Input Format]
*   **Error Recovery Step:** [e.g., Re-run manual trigger, check API quota]
*   **Escalation Path:** [Who to contact if the automation breaks permanently]

## 5. Maintenance Schedule
*   **Audit Frequency:** [e.g., Every 30 days]
*   **Checklist for Audit:**
    - [ ] Verify API token expiration dates.
    - [ ] Check logs for failed runs.
    - [ ] Ensure input data format hasn't changed.

---
**Date Created:** [YYYY-MM-DD]
**Last Updated:** [YYYY-MM-DD]