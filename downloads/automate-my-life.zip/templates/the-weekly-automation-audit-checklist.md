# The Weekly Automation Audit Checklist

**Product:** The Autopilot Life: A Blueprint for Personal Automation
**Date:** __________
**Review Period:** [ ] Week [ ] Month [ ] Quarter

---

### 1. Digital Maintenance & Security
- [ ] **Credential Check:** Are all passwords/keys updated in the password manager?
- [ ] **2FA Audit:** Are all two-factor authentication methods active and functional?
- [ ] **Subscription Scrub:** Identify and cancel one unused digital subscription.
- [ ] **Backup Verification:** Confirm recent automated backups (Cloud/Local) completed without errors.

### 2. Workflow Efficiency (The "Friction" Test)
- [ ] **Identify Bottlenecks:** List one manual task performed this week that felt "heavy" or repetitive.
- [ ] **Trigger Analysis:** Did any automated workflows fail or require manual intervention?
- [ ] **Input/Output Check:** Are data transfers between apps (e.g., Zapier, Make, IFTTT) flowing correctly?
- [ ] **Notification Audit:** Mute or remove one non-essential notification source to reduce cognitive load.

### 3. Financial Automation Review
- [ ] **Transaction Sync:** Verify all automated transfers/savings moves occurred as scheduled.
- [ ] **Error Detection:** Check for any failed automated bill payments or subscription renewals.
- [ ] **Budget Variance:** Review if automated budget alerts triggered any unexpected spending warnings.

### 4. Personal Ecosystem Health
- [ ] **Smart Home/IoT Check:** Ensure all sensors, lights, or climate automations are responding to schedules.
- [ ] **Calendar Sync:** Verify all recurring event automations (e.g., prep time, travel buffers) are accurate.
- [ ] **Information Diet:** Review automated RSS/Newsletter aggregators; prune low-value sources.

### 5. The "Next Step" Action Plan
- [ ] **Automation Candidate:** Identify one new task to automate next week.
- [ ] **Tool Selection:** Identify the tool needed (e.g., Python script, No-code, Browser extension).
- [ ] **Complexity Score:** Rate the difficulty of the new task (1-10): ____

---
**Notes/Observations:**
*(Record any friction points or ideas for new automations here)*