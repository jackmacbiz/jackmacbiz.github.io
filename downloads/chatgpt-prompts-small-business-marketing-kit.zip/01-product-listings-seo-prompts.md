# Category 1 — Product Listings & SEO Prompts
# Replace every [BRACKET]. Works in ChatGPT, Claude or Gemini.

1. You are an expert Etsy SEO copywriter. Write a keyword-rich Etsy title (max 140
   characters) for a [product] aimed at [audience]. Front-load the highest-intent
   search terms. Give me 3 options.

2. Generate 13 Etsy tags (max 20 chars each) for a [product]. Mix broad and
   long-tail buyer-intent phrases people actually search. No single repeated words.

3. Write an Etsy listing description for [product]. Structure: a 2-line hook, a
   "What you get" bulleted list, "Who it's for," "Format/instant download," and a
   friendly closing line. Tone: [warm and clear]. Audience: [audience].

4. Rewrite this listing title to be more search-friendly without keyword-stuffing:
   "[paste current title]". Keep it under 140 characters.

5. Suggest 5 product variations or bundles I could create from [product] to widen
   my catalog and capture more searches.

6. Act as a shopper searching for [product]. List the 10 exact phrases you'd type
   into Etsy. Then tell me which of my tags I'm missing.

7. Write a concise "How to use this digital download" section for [product] so
   buyers know exactly what they're getting and reviews stay 5 stars.

8. Give me 5 benefit-driven first lines (the hook) for a [product] listing. Lead
   with the buyer's outcome, not the features.
