# Category 2 — Social Media Caption Prompts

1. You are a friendly social media manager for a small [niche] shop. Write 7
   Instagram captions (one per day) for [product]. Each under 150 characters, ends
   with a soft CTA, includes 3 relevant hashtags. Tone: [warm, a little playful].

2. Write 5 hook lines for a Reel/TikTok about [product/topic] that stop the scroll
   in the first 2 seconds.

3. Turn this product into a "3 reasons you need this" carousel: give me 3 slide
   headlines + 1 caption for [product].

4. Write a "behind the scenes" caption about making [product] that builds trust and
   feels human, not salesy.

5. Give me 15 niche hashtags for [niche] — a mix of small (under 50k posts) and
   medium reach, no banned or spammy tags.

6. Write a Pinterest pin title + description for [product] optimized for search,
   under 100 characters for the title.

7. Draft a poll/question Story to boost engagement for an audience of [audience].
