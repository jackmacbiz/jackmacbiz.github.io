# Category 3 — Email Marketing & Customer Service Prompts

## Email marketing
1. Write a 3-email launch sequence for [product]: Email 1 = tease/story, Email 2 =
   value + how it helps, Email 3 = limited-time offer. Keep each under 150 words,
   tone [warm and direct], one clear CTA each.

2. Write a "welcome" email for new subscribers of a [niche] shop, including a
   first-order discount code [CODE] and what to expect.

3. Write a restock / "back in stock" announcement email for [product].

4. Write a cart/abandoned-interest follow-up that's helpful, not pushy, for [product].

## Customer service replies
5. Write a polite reply to a buyer asking [common question] about [product]. Friendly,
   solves it in 3 sentences.

6. Write a calm, professional response to a 3-star review that mentions [issue],
   offering to make it right without being defensive.

7. Write a "thank you for your order" message to include with the digital download,
   encouraging a review and offering help.
