# 10 Plug-and-Play Workflows
# Paste the whole block; fill the brackets; run it as one prompt.

## Workflow 1 — A full Etsy listing in one go
"You are an Etsy SEO expert. For a [product] aimed at [audience] priced at [$X],
give me: (1) three title options under 140 chars, (2) 13 tags under 20 chars each,
(3) a full description with a hook, 'what you get' bullets, 'who it's for', format,
and a friendly close. Tone: [warm and clear]."

## Workflow 2 — A week of Instagram captions
"Write 7 Instagram captions for [product], one per day, each under 150 characters,
each ending with a soft CTA and 3 hashtags. Vary the angle: benefit, story,
behind-the-scenes, testimonial-style, tip, question, offer."

## Workflow 3 — A 3-email launch sequence
"Write 3 launch emails for [product] (tease, value, offer). Each under 150 words,
one CTA, tone [warm]. Include subject lines."

## Workflow 4 — FAQ from your reviews
"Here are 5 questions buyers keep asking: [paste]. Turn them into a clear FAQ section
I can add to my listing and shop policies."

## Workflow 5 — Sale/promo announcement
"Write a promo announcement for [X% off] [product] running [dates] — give me a
caption, an email subject + body, and a Story line."

## Workflow 6 — Brand story
"Write a 120-word 'About' story for my [niche] shop. I started it because [reason].
What makes it different: [point]. Tone: [warm, genuine]."

## Workflow 7 — Blog post from one keyword
"Write a 600-word, helpful blog post targeting the keyword '[keyword]' for an
audience of [audience], with an intro, 3 H2 sections, and a soft CTA to [product]."

## Workflow 8 — Product photoshoot shot list
"Give me a 6-shot list to photograph [product] for an Etsy listing: hero, in-context,
detail, scale, lifestyle, and a flat-lay. Note props and angle for each."

## Workflow 9 — Restock email
"Write a short 'it's back' email for [product] with urgency but no hype."

## Workflow 10 — Order thank-you insert
"Write a warm 60-word thank-you note to include with a digital order, asking for a
review and offering help if they have questions."
