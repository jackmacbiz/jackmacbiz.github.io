300+ CHATGPT PROMPTS FOR SMALL BUSINESS + ETSY SELLERS — what's inside

1. prompting-playbook.md / .html  — how to get usable copy in seconds (the 4 levers + chaining)
2. 01-product-listings-seo-prompts.md
3. 02-social-media-caption-prompts.md
4. 03-email-and-customer-service-prompts.md
5. 10-plug-and-play-workflows.md   — paste-and-run prompts for full launches

The categories shown are the core set; each uses a fill-in-the-blank format you can
re-run endlessly with different products and audiences — that's how the library
scales past 300 usable prompts.

HOW TO USE: open the playbook (.html) first, then pick a prompt, replace the
[BRACKETS], and paste into ChatGPT, Claude or Gemini (free tiers work).

Personal use license. Not for resale or redistribution. Questions? Message the shop.
