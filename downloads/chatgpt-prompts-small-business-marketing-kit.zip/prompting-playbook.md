# The Prompting Playbook: Get usable copy in seconds

## Why most ChatGPT output sounds robotic
It's not the model — it's the prompt. A bare "write me an Instagram caption" gives
generic mush because the AI has no context. Every prompt in this library is built on
the 4 levers below. Master these and the 300 prompts become 3,000.

## The 4 levers of a great prompt
1. ROLE — tell it who to be: "You are an expert Etsy SEO copywriter."
2. CONTEXT — give it the facts: your product, audience, price, vibe, the goal.
3. FORMAT — say exactly what you want back: "Give me 5 options, each under 150 chars,
   with 3 hashtags."
4. TONE — name the voice: "warm, a little playful, no exclamation points."

Drop those four into any prompt and the output sounds like you, not a robot.

## How to use this library
- Pick a prompt from the matching category file.
- Replace every [BRACKET] with your real details.
- Paste into ChatGPT, Claude or Gemini (free tiers work fine).
- Ask for variations: "give me 5 more, punchier." Iterate — the second pass is usually
  the keeper.

## Chaining prompts for a full launch (a worked example)
1. Market research prompt -> 5 angles your audience cares about.
2. Brand story prompt -> your "why," for the About section.
3. Listing prompt -> title + tags + description for the product.
4. Caption prompt -> a week of social posts pointing to the listing.
5. Email prompt -> a 3-email launch sequence.
You just produced a launch in one sitting.

## 10 plug-and-play workflows (in the workflows file)
Full Etsy listing • A week of Instagram captions • 3-email launch sequence •
Customer FAQ from your reviews • A sale/promo announcement • A brand story •
A blog post from one keyword • A product photoshoot shot list • A restock email •
A "thank you for your order" insert.

## One rule that saves you
AI drafts; you decide. Never paste output without a 10-second read for accuracy and
voice. The tool gives you 80% in seconds — your judgment is the last 20% that sells.
