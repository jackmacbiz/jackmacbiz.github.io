# The Digital Planner For Ipad Toolkit — Quick-Start Manual

The Digital Planner For Ipad Toolkit is a set of fillable spreadsheets and checklists for digital planner for ipad. Each tool below is a file you open in Excel, Google Sheets, or Numbers (CSV) or any text/markdown app (.md). Fill them in as you go — the value is in the structure, not in reading prose.

## Checklists & Worksheets

- `ipad-planner-setup-guide.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `monthly-spread-template.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `weekly-layout-grid.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `habit-tracker-data.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `index-hyperlinks.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `goal-setting-template.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.


## How the tools work together

Open `ipad-planner-setup-guide.md`, `monthly-spread-template.csv`, `weekly-layout-grid.csv`, `habit-tracker-data.csv`, `index-hyperlinks.md`, `goal-setting-template.md` in order. Each file is a working tool for digital planner for ipad — fill it in as you go and revisit it on your next work block; the value is in using the structure, not in reading prose.