# The Digital Planner For Ipad Toolkit — Quick-Start Manual

This toolkit provides essential resources and step-by-step guidance to help you set up and optimize your digital planner on an iPad. It covers core features, customization options, and workflow tips designed specifically for users managing their schedules digitally. The goal is to streamline your planning process and improve daily productivity from the very first use.

## Progress Tracker

Open `progress-tracker.csv` and add one row per check-in. Fill `goal`, the `metric` you're moving, your `target_value`, and the `actual_value` so far.

- `pct_to_target` = `actual_value` / `target_value` * 100

Worked example (row 1): 4 of 10 tasks done -> pct_to_target = 4 / 10 * 100 = **40%**, status `on_track`. Update `status` to `behind` the moment actuals slip so you catch a stall early instead of at the deadline.

## Planner

Open `planner.csv` and plan one row per week. Set the single `top_priority`, write `why_it_matters` in one line, list the `key_tasks`, and block `time_block_hours`. Mark `done` YES/NO at week's end.

Pick ONE top priority per week — a planner with five priorities has none. If `done` is NO two weeks running, the task is too big; split it.

## Weekly Review

Open `weekly-review.csv` every Friday. Capture `what_worked`, `what_didnt`, and exactly `one_change_next_week`. Note which `metric_moved` and `by_how_much`.

The discipline is one change per week — small, compounding corrections beat occasional overhauls. Read last week's `one_change` before you plan the next.

## Checklists & Worksheets

- `getting-started-checklist.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.


## How the tools work together

Set this week's single priority in `planner.csv`. Track the metric that priority moves in `progress-tracker.csv`. Every Friday, close the loop in `weekly-review.csv` with one concrete change for next week. Repeat until `pct_to_target` reaches 100% — then set the next goal.