# The Digital Planner For Ipad Toolkit — Quick-Start Manual

The Digital Planner For Ipad Toolkit is a set of fillable spreadsheets and checklists for digital planner for ipad. Each tool below is a file you open in Excel, Google Sheets, or Numbers (CSV) or any text/markdown app (.md). Fill them in as you go — the value is in the structure, not in reading prose.

## Checklists & Worksheets

- `ipad-planner-setup-guide.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `weekly-budget-tracker.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `habit-streak-log.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `goal-setting-canvas.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `apple-pencil-stroke-library.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `monthly-expense-summary.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.


## How the tools work together

Open `ipad-planner-setup-guide.md`, `weekly-budget-tracker.csv`, `habit-streak-log.csv`, `goal-setting-canvas.md`, `apple-pencil-stroke-library.csv`, `monthly-expense-summary.md` in order. Each file is a working tool for digital planner for ipad — fill it in as you go and revisit it on your next work block; the value is in using the structure, not in reading prose.