# Recommended Color Palette for Digital Planners

## Soft Pastels
- Background: #F5F5F5 (Light Gray)
- Text: #333333 (Dark Gray)
- Accents: #FFB6C1 (Light Pink), #87CEEB (Sky Blue), #98FB98 (Pale Green)

## Dark Mode
- Background: #121212 (Almost Black)
- Text: #E0E0E0 (Light Gray)
- Accents: #FF6347 (Tomato), #FFD700 (Gold), #00FA9A (Medium Spring Green)

## Monochrome
- Background: #FFFFFF (White)
- Text: #000000 (Black)
- Accents: #808080 (Gray), #C0C0C0 (Silver)