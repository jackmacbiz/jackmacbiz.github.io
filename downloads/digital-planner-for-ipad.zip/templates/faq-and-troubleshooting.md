# Frequently Asked Questions

## Q: Does this work on Android?
A: No, the hyperlinks are optimized for Apple's iOS ecosystem and apps like GoodNotes and Notability.

## Q: Can I use this in OneNote?
A: Yes, but you will need to manually insert links for navigation as OneNote does not support PDF hyperlinks natively.

## Q: How do I add my own stickers?
A: Save your PNG stickers to your iPad's Photos app. In GoodNotes, go to Insert > Image and select the sticker from your library.

## Q: The links aren't working!
A: Ensure you are using a compatible app version. Update GoodNotes or Notability to the latest version from the App Store.