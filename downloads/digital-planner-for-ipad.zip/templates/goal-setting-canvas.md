# Quarterly Goal Setting Canvas

## Vision Statement
What do I want to achieve in the next 90 days?
I want to establish a consistent morning routine and save $1,200 for an emergency fund.

## SMART Goals

### Goal 1: Financial Health
- **Specific:** Save $400 per month automatically.
- **Measurable:** Check bank balance on the 1st of each month.
- **Achievable:** Yes, by cutting dining out expenses.
- **Relevant:** Builds emergency fund for peace of mind.
- **Time-bound:** By March 31, 2024.

### Goal 2: Personal Growth
- **Specific:** Read one book per month related to productivity.
- **Measurable:** Finish 4 books total.
- **Achievable:** Dedicate 20 minutes before bed daily.
- **Relevant:** Improves focus and work efficiency.
- **Time-bound:** By March 31, 2024.

## Action Steps
1. Set up automatic transfer on January 5th.
2. Purchase "Deep Work" by Cal Newport on Amazon.
3. Create a dedicated reading nook in the living room.