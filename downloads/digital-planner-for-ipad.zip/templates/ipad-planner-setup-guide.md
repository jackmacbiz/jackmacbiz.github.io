# iPad Digital Planner Setup Guide

## Compatible Apps
- GoodNotes 6
- Notability
- Noteshelf 3
- Procreate (for annotation)

## Installation Steps
1. Download the ZIP file to your iPad Files app.
2. Extract the folder named 'Digital_Planner_Toolkit'.
3. Open GoodNotes or Notability.
4. Tap the '+' icon to create a new notebook.
5. Select 'Import' and choose 'Digital_Planner_Toolkit'.
6. Select all PDF files within the toolkit.
7. Confirm import. The planner pages will appear in your library.

## Hyperlink Setup
The planner uses internal bookmarks for navigation.
- Ensure your app supports 'Hyperlinks' or 'Bookmarks'.
- In GoodNotes: Go to Settings > Note-taking > Enable Hyperlinks.
- In Notability: Go to Preferences > Pages > Enable Hyperlinks.

## Pen Settings
Recommended tools:
- Fine liner pen (0.38mm - 0.7mm)
- Highlighter (low opacity for background coloring)
- Eraser tool for corrections

## File Structure
- Cover_Page.pdf: Front cover image
- Index.pdf: Hyperlinked table of contents
- Monthly_Planner.pdf: 12 monthly spreads
- Weekly_Planner.pdf: 52 weekly grids
- Goal_Setting.pdf: SMART goal templates
- Habit_Tracker.csv: Digital habit data log