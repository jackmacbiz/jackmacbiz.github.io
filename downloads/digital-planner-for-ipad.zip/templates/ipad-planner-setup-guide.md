# iPad Digital Planner Setup Guide

## Step 1: Install GoodNotes or Notability
Download your preferred annotation app from the App Store. GoodNotes 6 is recommended for its folder organization and PDF import speed.

## Step 2: Import the Toolkit
1. Open the Files app on your iPad.
2. Locate the downloaded ZIP file in your Downloads folder.
3. Long-press the ZIP file and select "Unzip" to extract the contents.
4. Open GoodNotes/Notability.
5. Tap the "Import" button (arrow pointing up into a box).
6. Navigate to the extracted folder and select all .PDF files.
7. Choose "Import to New Folder" and name it "My Digital Planner 2024".

## Step 3: Configure Hyperlinks
Ensure your iPad is set to open PDFs in GoodNotes/Notability by default:
- Go to Settings > GoodNotes 6 > Default PDF Viewer > Select "GoodNotes 6".
- Open any page from the imported folder. Tap the link icon (chain link) in the top toolbar if links do not auto-trigger.

## Step 4: Customize Your Cover
Open the "Cover_Page_Template.pdf" file.
- Use the Text Tool to add your name and start date.
- Use the Pen Tool to draw your preferred cover design.
- Save as a new PDF to preserve the original template.