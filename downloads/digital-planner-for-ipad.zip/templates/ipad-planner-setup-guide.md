# iPad Digital Planner Setup Guide

## Step 1: Download and Import
1. Open the GoodNotes, Notability, or Notion app on your iPad.
2. Locate the downloaded ZIP file in your Files app.
3. Extract the folder to your preferred storage location (iCloud Drive or On My iPad).
4. Open your note-taking app and import the 'Master_Template.pdf' as a new document.

## Step 2: Configure Hyperlinks
1. Ensure your app supports hyperlinked tabs (GoodNotes 6+ or Notability 2023+).
2. Tap the 'Home' tab to verify navigation works.
3. If links are inactive, check your app settings under 'Preferences > Import/Export > Enable Hyperlinks'.

## Step 3: Customize Your Layout
1. Use the 'Cover_Page.pdf' as your starting point.
2. Add a personal photo using the 'Insert > Image' tool.
3. Set up your daily spread by duplicating the 'Daily_Template' page.

## Step 4: Syncing Across Devices
1. Enable iCloud sync in your note-taking app settings.
2. Ensure you are logged into the same Apple ID on all devices.
3. Changes made on iPad will now reflect on iPhone and Mac automatically.