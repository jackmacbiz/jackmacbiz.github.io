# Monthly Expense Summary: January 2024

## Income
- Salary: $5,200.00
- Freelance Project: $800.00
- **Total Income: $6,000.00**

## Fixed Expenses
- Rent/Mortgage: $1,500.00
- Car Insurance: $120.00
- Internet/Phone: $90.00
- Gym Membership: $45.00
- **Total Fixed: $1,755.00**

## Variable Expenses
- Groceries: $485.50
- Dining Out: $120.00
- Entertainment/Subscriptions: $65.20
- Personal Care: $30.00
- **Total Variable: $700.70**

## Savings & Investments
- Emergency Fund: $1,000.00
- Roth IRA: $200.00
- **Total Savings: $1,200.00**

## Remaining Balance
$6,000.00 - $1,755.00 - $700.70 - $1,200.00 = **$2,344.30**

*Note: Remaining balance was allocated to debt repayment on credit card ending in 4422.*