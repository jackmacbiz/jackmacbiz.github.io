# Email Sequence for New Buyers

## Email 1: Welcome & Download Link
Subject: Your Digital Planner Toolkit is here!
Body:
Hi [Name],

Thank you for your purchase! Here is the link to download your toolkit.

[Download Link]

Best regards,
The Planning Team