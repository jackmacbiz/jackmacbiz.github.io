# The Digital Planner Goodnotes Etsy Toolkit — Quick-Start Manual

This manual provides step-by-step instructions for setting up and utilizing the Digital Planner GoodNotes Etsy Toolkit to streamline your workflow. It covers essential configuration steps, file organization, and best practices for maximizing efficiency in your digital planning process. Follow these guidelines to ensure a smooth setup and effective use of the toolkit’s features.

## Checklists & Worksheets

- `etsy-listing-copy.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `goodnotes-bundle-structure.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `goodnotes-hyperlink-map.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `etsy-tag-strategy.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `etsy-pricing-calculator.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.


## How the tools work together

Open `etsy-listing-copy.md`, `goodnotes-bundle-structure.csv`, `goodnotes-hyperlink-map.csv`, `etsy-tag-strategy.csv`, `etsy-pricing-calculator.csv` in order. Each file is a working tool for digital planner goodnotes etsy — fill it in as you go and revisit it on your next work block; the value is in using the structure, not in reading prose.