# Baby Shower Budget Planner
## Target Total: $150.00

| Category | Item Description | Vendor/Source | Estimated Cost | Actual Cost | Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Invitations | 25 Digital PDFs + Printing | Vistaprint | $35.00 | $38.50 | Paid |
| Decorations | Pastel Balloon Arch Kit | Amazon | $24.99 | $24.99 | Paid |
| Tableware | 1st Birthday/One Little One Plates | Target | $12.50 | $12.50 | Paid |
| Food | DIY Cupcake Station Supplies | Walmart | $45.00 | $42.75 | Pending |
| Games | Printable Game Props & Prizes | Etsy (Digital) | $8.00 | $8.00 | Paid |
| Favors | Mini Succulents x 25 | Local Nursery | $30.00 | $32.50 | Pending |
| Misc | Tape, Scissors, Extra Ink | Home Goods | $15.00 | $11.25 | Paid |

**Total Estimated:** $170.49
**Total Actual:** $169.99
**Variance:** -$0.50 (Under Budget)