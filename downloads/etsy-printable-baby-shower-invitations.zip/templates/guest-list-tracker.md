# Baby Shower Guest List & Gift Tracker

## Host Details
- **Mom-to-be:** Sarah Jenkins
- **Date:** October 14, 2026
- **Venue:** The Garden Room, 123 Maple St.

## Guest List (Confirmed)
| Name | Relationship | Dietary Restriction | Gift Received? | Thank You Sent? |
|---|---|---|---|---|
| Emily Davis | Sister | None | Diaper Bag | Yes |
| Mark & Lisa Smith | Neighbors | Gluten-Free | Onesie Set | No |
| Aunt Margaret | Family | Vegetarian | Baby Monitor | Yes |
| Dr. Patel | Friend | None | Wipes (12pk) | No |
| Uncle Bob | Family | None | Diapers (Size 1) | No |

## Action Items
- [ ] Finalize headcount by Oct 7
- [ ] Buy extra napkins for 15 guests
- [ ] Print thank you cards for Emily and Aunt Margaret