# The Etsy Printable Planner Inserts Toolkit — Quick-Start Manual

The Etsy Printable Planner Inserts Toolkit is a set of fillable spreadsheets and checklists for etsy printable planner inserts. Each tool below is a file you open in Excel, Google Sheets, or Numbers (CSV) or any text/markdown app (.md). Fill them in as you go — the value is in the structure, not in reading prose.

## Checklists & Worksheets

- `weekly-planner-insert.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `daily-task-checklist.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `monthly-budget-tracker.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.


## How the tools work together

Open `weekly-planner-insert.csv`, `daily-task-checklist.md`, `monthly-budget-tracker.csv` in order. Each file is a working tool for etsy printable planner inserts — fill it in as you go and revisit it on your next work block; the value is in using the structure, not in reading prose.