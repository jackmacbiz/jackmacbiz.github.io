# Daily Task Checklist for Etsy Planner Inserts

## Morning Routine (6:00 AM - 9:00 AM)
- [ ] Check Etsy notifications and reply to buyers within 1 hour
- [ ] Review daily sales dashboard and note any anomalies
- [ ] Pack overnight orders with care cards and stickers
- [ ] Update shipping labels for same-day dispatch

## Midday Production (10:00 AM - 2:00 PM)
- [ ] Design new planner insert mockup in Canva/Photoshop
- [ ] Edit product photos for current listings (lighting/color correction)
- [ ] Write SEO titles and tags for upcoming summer collection
- [ ] Organize digital assets folder by product category

## Afternoon Admin (2:30 PM - 5:00 PM)
- [ ] Process refunds or exchanges if requested
- [ ] Update inventory counts for physical supplies (paper, ink)
- [ ] Schedule social media posts for the next 3 days
- [ ] Review competitor pricing on similar planner inserts

## Evening Wrap-Up (6:00 PM - 7:00 PM)
- [ ] Final check of Etsy shop status and banner images
- [ ] Plan tomorrow's top 3 priorities
- [ ] Backup all design files to cloud storage
- [ ] Close shop for the day