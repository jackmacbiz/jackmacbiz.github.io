# The Prop Firm Evaluation Toolkit — Quick-Start Manual

This manual provides immediate access to the core tools required to pass prop firm evaluations for Topstep, Apex, FTMO, and Tradovate. It eliminates setup friction by delivering pre-configured templates and risk parameters that align with standard funded account rules. Use these resources to execute your trading plan with precision from day one.

## Daily Loss Limit Calculator

Open `daily-loss-limit-calculator.csv`. Enter your `account_size` (use the SAME account_size here as in the Position Size Calculator so both tools agree), your firm's `daily_loss_limit`, and how many trades you intend to take (`trades_per_day`), then your typical `stop_in_ticks` and the instrument's `tick_value`.

- `per_trade_risk_budget` = `daily_loss_limit` / `trades_per_day`
- `max_contracts` = `per_trade_risk_budget` / (`stop_in_ticks` * `tick_value`), rounded DOWN

Worked example (row 1): a $50,000 account with a $1,000 daily loss limit and 4 planned trades gives a $250 per-trade budget. With an 8-tick stop at $12.50/tick, max_contracts = 250 / (8 * 12.50) = 2.5 -> trade **2 contracts**. You round DOWN (2, not 3) because 3 contracts would risk 3 * 8 * $12.50 = $300, OVER your $250 budget — rounding up over-risks the trade and can breach your limit. Never let any single trade risk more than `per_trade_risk_budget`.

## Position Size Calculator

Open `position-size-calculator.csv`. Enter `account_size`, your chosen `risk_per_trade_pct` (0.5 is conservative), `stop_in_ticks`, and `tick_value`.

- `risk_dollars` = `account_size` * (`risk_per_trade_pct` / 100)
- `contracts` = `risk_dollars` / (`stop_in_ticks` * `tick_value`), rounded DOWN

Worked example (row 1): $50,000 at 0.5% = $250 risk. With an 8-tick stop at $12.50/tick, contracts = 250 / (8 * 12.50) = 2.5 -> **2 contracts**.

## Evaluation Progress Tracker

Open `evaluation-progress-tracker.csv` and add one row per trading day. Fill `starting_balance`, `ending_balance`, and `daily_pnl`; the tracker rolls up your progress toward the `profit_target` and flags breaches.

- `pct_to_target` = `cum_profit` / `profit_target` * 100
- `limit_breached` is TRUE when `daily_pnl` <= -`daily_loss_limit`
- `trailing_drawdown_floor` = `peak_balance` - your firm's max trailing drawdown; `drawdown_breached` is TRUE when `ending_balance` < that floor

Worked example: with $1,260 cumulative profit toward a $3,000 target, pct_to_target = 1260 / 3000 * 100 = **42%**. If your peak balance is $51,260 and the max trailing drawdown is $2,000, your floor is $49,260 — close any session before your balance touches it. If `ending_balance` DOES fall below the floor (say $49,100 < $49,260), the account is BLOWN: the eval is failed and you stop trading it immediately — there is no recovering a breached trailing drawdown. That is why the floor is the hardest line in the kit: protect it above the profit target.

## Trade Journal

Open `trade-journal.csv` and log every trade as you close it. Record `entry`, `stop`, `target`, `exit`, `contracts`, `risk_ticks`, `reward_ticks`, whether you `followed_plan`, and any `rule_breach`.

- `r_multiple` = `reward_ticks` / `risk_ticks`; a trade stopped at full risk = -1.0R

Worked example (row 1): an NQ long with an 8-tick risk and 24-tick reward scores r_multiple = 24 / 8 = **3.0R**. Review `rule_breach` weekly — recurring breaches (e.g. `reentry_after_stop`) are what void payouts even on a green account.

## Checklists & Planners

- `pre-market-checklist.md`: open it before each session and work top to bottom; treat every unchecked item as a reason not to trade yet.


## How the tools work together

Before the session, set your per-trade budget in the loss-limit calculator and size each trade with the position-size calculator. During the session, log every fill in the trade journal. After the close, add the day to the evaluation progress tracker and confirm no breach. Repeat until `pct_to_target` reaches 100% — then request your payout.