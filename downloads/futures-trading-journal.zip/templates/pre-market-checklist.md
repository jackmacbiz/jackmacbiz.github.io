# Pre-Market Checklist

- [ ] Set today's daily loss limit and per-trade budget (loss-limit calculator)
- [ ] Confirm max trailing drawdown floor for the account
- [ ] Note the day's news/economic events that move your instrument
- [ ] Define A+ setups only; no revenge or re-entry-after-stop trades
- [ ] Pre-size every planned trade with the position-size calculator
- [ ] Decide a hard stop-trading rule (e.g. 2 losers = done for the day)
