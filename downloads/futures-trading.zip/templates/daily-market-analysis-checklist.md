# Daily Market Analysis Checklist for Futures Trading Mastery

- [ ] Review overnight news affecting major markets (e.g., economic indicators, geopolitical events)
- [ ] Analyze futures contracts: S&P 500, NASDAQ, Dow Jones, Crude Oil, Gold
- [ ] Check technical indicators on charts: Moving Averages, RSI, MACD
- [ ] Identify support and resistance levels for key commodities and indices
- [ ] Evaluate open interest and volume trends in futures contracts
- [ ] Monitor global economic data releases that impact futures markets
- [ ] Assess sentiment through COT (Commitments of Traders) report
- [ ] Note any significant changes in volatility across different assets
- [ ] Plan trades based on analysis, considering risk management strategies