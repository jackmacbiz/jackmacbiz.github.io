```
Portfolio Performance Tracker for Futures Trading Mastery

Date,Symbol,Entry Price,Exit Price,Quantity,Realized P&L,Unrealized P&L,Total P&L,Notes
2023-10-01,CME_ES,4500.00,4600.00,1,-10000.00,0.00,-10000.00,"Exited position due to reaching target price."
2023-10-03,CME_CL,90.50,89.75,2,150.00,0.00,150.00,"Stopped out on adverse market movement."
2023-10-04,CME_ZN,125.00,,1,0.00,-125.00,-125.00,"Holding position for further upside."
```