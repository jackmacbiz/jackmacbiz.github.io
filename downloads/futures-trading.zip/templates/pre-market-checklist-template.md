# Futures Prop Trader Toolkit Pre-Market Checklist

## Account Setup & Compliance
- [ ] Verify account status and balance meets minimum requirements.
- [ ] Confirm compliance with prop firm rules and restrictions.
- [ ] Review and update risk management parameters.

## Market Analysis
- [ ] Analyze overnight news for significant market-moving events.
- [ ] Check economic calendar for upcoming releases (e.g., CPI, NFP).
- [ ] Evaluate technical indicators on key futures contracts (e.g., 10Y Yield, S&P500).

## Trading Plan
- [ ] Define trading goals and risk/reward ratios for the day.
- [ ] Identify potential entry points based on analysis.
- [ ] Set stop-loss levels at no more than 2% of account equity.

## Position Management
- [ ] Allocate capital across different futures contracts proportionally.
- [ ] Monitor open positions for unexpected volatility or slippage.
- [ ] Adjust position sizes according to market conditions and risk tolerance.

## Execution & Monitoring
- [ ] Execute trades at scheduled times based on pre-market analysis.
- [ ] Use limit orders to manage entry price within acceptable range.
- [ ] Track real-time market data using reliable trading platforms.

## Post-Market Review
- [ ] Record daily performance metrics (e.g., P&L, win rate).
- [ ] Analyze trades for opportunities missed or executed well.
- [ ] Adjust strategy based on review findings for next day's trading.