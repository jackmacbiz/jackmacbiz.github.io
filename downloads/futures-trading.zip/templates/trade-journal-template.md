# Futures Prop Trader Toolkit Trade Journal Template

## Daily Pre-Market Routine

- [ ] Review overnight news and economic reports.
- [ ] Analyze market sentiment from social media and forums.
- [ ] Check open positions for stop-loss or take-profit levels.
- [ ] Set up watchlists with key futures contracts (e.g., ES, NQ, CL).
- [ ] Update risk management parameters for the day.

## Trade Execution

- [ ] Identify high-probability setups based on technical analysis.
- [ ] Enter trades at specified price levels or after confirmation signals.
- [ ] Adjust position size according to account equity and volatility.
- [ ] Set initial stop-loss and take-profit orders.
- [ ] Monitor trade execution fees and slippage.

## Intraday Monitoring

- [ ] Track performance of open positions every 15 minutes.
- [ ] Reassess risk management rules as market conditions change.
- [ ] Adjust stop-loss levels to lock in gains or cut losses.
- [ ] Evaluate the impact of unexpected news events on trades.
- [ ] Record any deviations from trading plan and reasons.

## Post-Market Review

- [ ] Close all positions at market close or according to exit strategy.
- [ ] Calculate daily P&L (Profit & Loss).
- [ ] Analyze winning and losing trades separately.
- [ ] Note down lessons learned for future improvement.
- [ ] Update trading journal with new insights.

## Weekly/Monthly Analysis

- [ ] Review weekly/monthly performance metrics (ROI, Sharpe ratio).
- [ ] Identify trends in trade outcomes over time.
- [ ] Adjust trading plan based on recurring patterns or errors.
- [ ] Set goals for the next week/month based on current performance.
- [ ] Budget and allocate funds to new opportunities identified.

## Risk Management

- [ ] Maintain a risk/reward ratio of at least 1:2 per trade.
- [ ] Keep position sizes under 2% of account equity.
- [ ] Avoid trading more than 5 contracts simultaneously.
- [ ] Review daily drawdown limits (e.g., max $500 loss).
- [ ] Implement strict stop-loss orders to protect capital.

## Compliance and Record Keeping

- [ ] Ensure all trades comply with prop firm rules.
- [ ] Keep detailed records of each trade for audit purposes.
- [ ] Submit required reports to the prop firm on time.
- [ ] Stay informed about regulatory changes affecting futures trading.
- [ ] Maintain a separate journal for compliance notes.

## Personal Development

- [ ] Spend 1 hour daily reading market analysis and strategy articles.
- [ ] Attend weekly webinars or workshops on futures trading.
- [ ] Practice paper trading with new strategies before live use.
- [ ] Set aside time to review and update personal trading plan monthly.
- [ ] Network with other traders for insights and support.