# The Guided Meditation Audio For Sleep Toolkit — Quick-Start Manual

The Guided Meditation Audio For Sleep Toolkit is a set of fillable spreadsheets and checklists for guided meditation audio for sleep. Each tool below is a file you open in Excel, Google Sheets, or Numbers (CSV) or any text/markdown app (.md). Fill them in as you go — the value is in the structure, not in reading prose.

## Checklists & Worksheets

- `sleep-meditation-script.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `meditation-audio-metadata.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `sleep-hygiene-checklist.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `buyer-onboarding-email.txt`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.


## How the tools work together

Open `sleep-meditation-script.md`, `meditation-audio-metadata.csv`, `sleep-hygiene-checklist.md`, `buyer-onboarding-email.txt` in order. Each file is a working tool for guided meditation audio for sleep — fill it in as you go and revisit it on your next work block; the value is in using the structure, not in reading prose.