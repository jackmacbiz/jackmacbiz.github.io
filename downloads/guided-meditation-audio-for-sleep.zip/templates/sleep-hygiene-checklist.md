# Nightly Sleep Hygiene Checklist
## For Guided Meditation Users

Use this checklist to prepare your environment for the guided meditation. Consistency is key to deep sleep.

### Pre-Meditation Prep (15 Minutes Before)
- [ ] Phone set to 'Do Not Disturb' mode.
- [ ] Room temperature adjusted to 65-68°F (18-20°C).
- [ ] Lights dimmed or off. Blackout curtains drawn.
- [ ] White noise machine or fan turned on (if used).
- [ ] Water glass placed within arm's reach.

### Meditation Setup
- [ ] Headphones charged and ready.
- [ ] Meditation app opened to the 'Sleep' playlist.
- [ ] Body positioned comfortably in bed.
- [ ] Eyes closed for 30 seconds before pressing play.

### Post-Meditation Routine
- [ ] Device placed face down on a nightstand (not under the pillow).
- [ ] No further screen time after meditation ends.
- [ ] Focus remains on breathing until sleep onset.

### Weekly Reflection
- [ ] Average sleep duration: ______ hours
- [ ] Quality of rest (1-10): ______
- [ ] Did you use the guided audio? Yes / No
- [ ] Notes on what helped or hindered sleep: