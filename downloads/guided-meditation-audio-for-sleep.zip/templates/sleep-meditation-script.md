# The Guided Meditation Audio For Sleep Toolkit
## Script: 'The Drift Into Deep Rest'
## Duration: Approx. 15 Minutes
## Tone: Soft, Slow, Monotone, Reassuring

[0:00 - 2:00] Introduction & Settling In
Welcome. This is your time to let go of the day. There is nothing left to do. No emails to answer, no problems to solve. Just you and this moment.

Find a comfortable position in bed. Lie on your back or side, whichever feels most supportive for your spine. Allow your arms to rest by your sides, palms facing up or down, as they prefer.

Take a deep breath in through your nose... filling your lungs completely...
And exhale slowly through your mouth... letting all the tension leave with the air.

Again. Breathe in deeply... hold for a second...
And breathe out longer than you breathed in. Let your shoulders drop away from your ears.

[2:00 - 5:00] Body Scan Release
Bring your awareness to the top of your head. Imagine a warm, golden light touching your scalp. Feel it relax every muscle there.

Let this warmth flow down into your forehead. Smooth out any lines between your eyebrows. Your eyes are heavy now. Let them sink deeper into their sockets.

Feel the relaxation spread to your jaw. Unclench your teeth. Let your tongue rest loosely on the floor of your mouth. Your face is soft and smooth.

Let the warmth flow down your neck, releasing any tightness in the throat. It flows into your shoulders... letting them sink into the mattress. Down your arms... past your elbows... to your wrists... and out through your fingertips.

Feel your chest rise and fall gently with each breath. Your ribs expand softly.

Now, bring attention to your stomach. Let it be soft and unguarded. Feel the warmth flow down into your hips... releasing any stored tension.

Down through your thighs... heavy and relaxed.
Past your knees... into your calves...
And finally, into your ankles and feet. Your toes are warm and tingling with relaxation.

[5:00 - 10:00] The Visualisation: The Forest Path
Imagine you are standing at the edge of a gentle, misty forest. It is twilight here. The air is cool and fresh, smelling of pine and damp earth.

You step onto a soft moss path. With each step, you feel more grounded. The moss cushions your feet.

Ahead, you see a small clearing with a single, comfortable wooden bench. You walk toward it slowly. Sit down on the bench.

Look up at the sky through the trees. The stars are beginning to appear. One by one, they twinkle into existence. Watch them glow softly in the dark.

As you watch each star, feel your body becoming heavier, sinking deeper into the bench, and then into the earth below. You are safe here. You are held by the forest.

[10:00 - 13:00] The Counting Down Technique
We will now count down from 10 to 1. With each number, you will go twice as deep into sleep.

10... Drifting deeper...
9... So relaxed...
8... Letting go completely...
7... Heavy limbs...
6... Peaceful mind...
5... Halfway there...
4... Deeper still...
3... Almost asleep...
2... Very close...
1... Sleep.

[13:00 - 15:00] Outro & Fade Out
Rest now. Let the darkness wrap around you like a warm blanket. If your mind wanders, gently bring it back to the feeling of heavy, relaxed limbs.

You are safe. You are calm. You are ready for deep rest.

Sleep well.