# Meditation Audiobook Scripts: Anxiety Relief

## Session 1: The Anchor Breath (5 Minutes)
Focus on the sensation of air entering the nostrils. When anxiety spikes, count four seconds in, hold for two, exhale for six. Repeat until the heart rate slows.

## Session 2: Body Scan Release (10 Minutes)
Start at the toes. Tense the muscles for five seconds, then release completely. Move up to the calves, thighs, hips, stomach, chest, hands, shoulders, and face. Notice the weight of the body against the surface.

## Session 3: Visualizing Safety (7 Minutes)
Imagine a place where you feel completely secure. Describe the colors, sounds, and smells in detail. Anchor this feeling to a physical touchpoint on your wrist.