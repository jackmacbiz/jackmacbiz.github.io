# Minimalist Second Brain Navigation

## 🏠 Home
- **Dashboard**: Overview of active projects and daily focus.
- **Quick Capture**: Inbox for unprocessed thoughts.

## 📂 Projects (Active)
- [ ] Project Alpha: Q3 Marketing Launch
- [ ] Project Beta: Website Redesign
- [ ] Project Gamma: Client Onboarding System

## 📚 Areas (Ongoing Responsibilities)
- **Health**: Fitness tracking, meal planning.
- **Finance**: Budget review, investment monitoring.
- **Professional**: Skill development, networking.
- **Home**: Maintenance schedule, inventory.

## 🗄️ Archive
- Completed projects from 2023.
- Old client files.

## 🧠 Resources (Reference)
- **Books**: Notes on 'Atomic Habits', 'Deep Work'.
- **Articles**: Curated list of productivity hacks.
- **Templates**: Meeting agendas, project briefs.

## ✅ Tasks (Context-Based)
- @Computer: Email client, update CRM.
- @Home: Water plants, call plumber.
- @Errands: Buy groceries, pick up dry cleaning.