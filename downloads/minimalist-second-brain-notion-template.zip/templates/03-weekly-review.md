# Weekly Review: [Date Range]

## 🔄 Review Checklist
- [ ] Processed all Inbox items?
- [ ] Updated Project statuses?
- [ ] Cleared Email inbox to zero?
- [ ] Reviewed Calendar for next week?

## 📊 Metrics
- **Projects Completed**: 2
- **Tasks Done**: 14
- **Inbox Zero Days**: 5/7

## 💡 Key Insights
1. Most time spent on 'Project Alpha'. Need to delegate design tasks.
2. Morning hours are most productive for deep work.
3. Need to schedule more breaks to maintain focus.

## 🎯 Next Week's Focus
- Finalize Project Alpha proposal.
- Start research for Project Beta.
- Attend networking event on Thursday.