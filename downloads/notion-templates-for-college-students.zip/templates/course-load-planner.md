# Course Load Planner: Fall 2024
## Major: Computer Science
## Credits Required: 15

| Time | Mon | Tue | Wed | Thu | Fri |
|---|---|---|---|---|---|
| 08:00 | CS101 Lect | Math 201 Lec | CS101 Lab | Math 201 Prob | CS101 Lec |
| 10:00 | Physics 101 | English 102 | Physics 101 Lab | English 102 | Study Group |
| 13:00 | Lunch Break | Library Research | Gym Session | Library Research | Project Work |
| 15:00 | CS Elective | Office Hours | CS Elective | Office Hours | Club Meeting |

## Key Deadlines
- Oct 15: Midterm Physics
- Nov 1: CS Project Alpha Due
- Dec 10: Final Exam Period Starts