# Final Exam Study Scheduler
## Purpose: Allocate time blocks for high-stakes finals week.

| Date | Subject | Topic/Chapter | Goal (Hours) | Status |
|------|---------|---------------|--------------|--------|
| Mon, Dec 10 | Organic Chem | Ch. 12-14 Mechanisms | 3.0 | Done |
| Tue, Dec 11 | Microeconomics | Supply/Demand Shifts | 2.5 | Done |
| Wed, Dec 12 | Calc II | Integration by Parts | 4.0 | In Progress |
| Thu, Dec 13 | History of Art | Baroque Period Notes | 2.0 | Pending |
| Fri, Dec 14 | Physics II | Electromagnetism Review | 3.5 | Pending |

## Rules:
- No phone during study blocks.
- 50 min study / 10 min break.
- Mark 'Done' only after practice problems are completed.