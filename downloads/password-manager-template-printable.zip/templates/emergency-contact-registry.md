# Emergency Contact Registry
## Purpose
List trusted individuals who can access your digital life during incapacity.

## Primary Recovery Agent
Name: Jane Doe
Relation: Spouse
Phone: +1-555-0198
Email: jane.doe@example.com
Security Question Answer (Last 4): 7721

## Secondary Recovery Agent
Name: John Smith
Relation: Brother
Phone: +1-555-0142
Email: john.smith@example.com
Security Question Answer (Last 4): 9934

## Tertiary Recovery Agent
Name: Sarah Lee
Relation: Attorney
Phone: +1-555-0167
Email: sarah.lee@lawfirm.com
Security Question Answer (Last 4): 1128

## Instructions
1. Store this file in your secure offline backup.
2. Share the location with your Primary Recovery Agent only.
3. Update annually or after any major life event.