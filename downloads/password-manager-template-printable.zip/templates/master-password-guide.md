# Master Password Construction Guide

Your master password is the key to all your digital life. Follow these rules:

1. Length: Minimum 16 characters.
2. Complexity: Mix uppercase, lowercase, numbers, and symbols.
3. Memorability: Use a passphrase method.

Example Structure:
- Word 1 (Noun): Coffee
- Word 2 (Verb): Jumps
- Number: Over
- Symbol: The
- Word 3 (Adjective): Lazy
- Number: Dog

Result: CoffeeJumpsOverTheLazyDog99!

Do not reuse this password anywhere else.
Store it in your physical safe or a secure offline note.