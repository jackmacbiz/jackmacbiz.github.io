# Password Hierarchy & Rotation Schedule

## Tier 1: Critical Identity (Rotate Annually)
- Bank of America Checking | Last changed: 2024-01-15 | Next due: 2025-01-15
- PayPal Primary | Last changed: 2023-11-20 | Next due: 2024-11-20
- Apple ID (Primary) | Last changed: 2024-06-10 | Next due: 2025-06-10

## Tier 2: Financial & Legal (Rotate Every 6 Months)
- Chase Credit Card | Last changed: 2024-03-01 | Next due: 2024-09-01
- TurboTax Account | Last changed: 2024-02-15 | Next due: 2024-08-15
- Venmo Business | Last changed: 2023-12-10 | Next due: 2024-06-10

## Tier 3: Communication & Social (Rotate Every 12 Months)
- Gmail Primary | Last changed: 2023-05-20 | Next due: 2024-05-20
- LinkedIn Profile | Last changed: 2024-01-05 | Next due: 2025-01-05
- Instagram Creator | Last changed: 2023-09-12 | Next due: 2024-09-12

## Tier 4: Utilities & Services (Rotate Every 18 Months)
- Comcast Xfinity | Last changed: 2022-11-30 | Next due: 2024-05-30
- Netflix Personal | Last changed: 2023-04-15 | Next due: 2024-10-15
- Spotify Premium | Last changed: 2023-08-22 | Next due: 2025-02-22