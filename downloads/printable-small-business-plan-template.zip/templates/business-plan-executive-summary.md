# Executive Summary

**Business Name:** Urban Root Studio
**Owner:** Alex Chen
**Launch Date:** October 15, 2026

**Mission:** To provide high-quality, eco-friendly botanical prints and digital planning assets for modern home offices.

**Problem:** Remote workers lack aesthetically pleasing yet functional tools to organize their workflow without cluttering physical desks.

**Solution:** A curated collection of printable small business plan templates, including cash flow trackers, client onboarding checklists, and goal-setting worksheets. All designs are minimalist, black-and-white optimized for home printers, and instantly downloadable.

**Target Market:** Freelancers, solopreneurs, and small agency owners aged 25-40 who value organization and design.

**Revenue Model:** Direct-to-consumer sales via Etsy and Shopify. Average order value: $18. Projected Year 1 Revenue: $45,000.

**Funding Needs:** $2,000 for initial marketing spend and premium Canva Pro subscription for asset creation.