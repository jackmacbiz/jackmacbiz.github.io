Month	Category	Description	Income	Expenses
January	Revenue	Consulting Services	4500.00	0.00
January	Costs	Software Subscription	0.00	29.99
January	Costs	Office Supplies	0.00	150.00
February	Revenue	Workshop Fees	6000.00	0.00
February	Costs	Marketing Ads	0.00	300.00
February	Costs	Insurance Premium	0.00	120.00
March	Revenue	Product Sales	3200.00	0.00
March	Costs	Shipping Costs	0.00	85.50