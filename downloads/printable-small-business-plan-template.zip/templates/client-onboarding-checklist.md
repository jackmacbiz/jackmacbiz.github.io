# Client Onboarding Checklist: Corporate Workshop Packages

**Client Name:** TechFlow Solutions
**Contact:** Sarah Jenkins (HR Director)
**Date:** November 2, 2026

- [ ] **Initial Consultation Completed**
  - Needs assessment for team productivity workshops.
  - Budget confirmed: $1,500.

- [ ] **Contract Signed & Deposit Received**
  - Invoice #INV-2026-089 sent on Nov 3.
  - 50% deposit ($750) received via Stripe on Nov 4.

- [ ] **Custom Plan Template Created**
  - Branded with TechFlow logo.
  - Included specific KPIs for Q4 review.

- [ ] **Materials Prepared**
  - 20 printed binders shipped on Nov 10.
  - Digital copies emailed to all attendees on Nov 11.

- [ ] **Workshop Delivery**
  - Date: November 15, 2026.
  - Duration: 3 hours.

- [ ] **Post-Workshop Follow-up**
  - Feedback survey sent Nov 16.
  - Final invoice #INV-2026-090 sent upon completion.