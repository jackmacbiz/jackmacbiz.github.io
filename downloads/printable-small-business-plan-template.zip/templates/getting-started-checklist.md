# Getting Started Checklist — printable small business plan template

Work top to bottom. Treat every unchecked box as a reason you are not ready to move to the next stage.

## Setup
- [ ] Write your one-sentence promise (the concrete outcome a buyer gets)
- [ ] Name the specific buyer (who, exactly, has this problem today)
- [ ] Set a price you would actually pay for this outcome

## Build
- [ ] Open `progress-tracker.csv` and set your first real goal + target
- [ ] Open `planner.csv` and block time for this week's top priority
- [ ] Assemble the deliverable a buyer receives (this kit is your scaffold)

## Ship
- [ ] Stand up a landing page with a single clear call to action
- [ ] Add a lead-capture form (name + email) above the fold
- [ ] Post once where your buyer already spends time, and ask for the click

## Review
- [ ] Fill `weekly-review.csv` every Friday: what worked, what didn't, one change
- [ ] Update `progress-tracker.csv` so `pct_to_target` reflects reality
