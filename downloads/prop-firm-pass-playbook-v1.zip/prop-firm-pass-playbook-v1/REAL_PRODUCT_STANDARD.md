# Real Product Standard

A product is not considered shippable unless a paying customer receives a
complete, useful deliverable. The minimum standard:

1. A PRODUCT.json manifest with title, audience, promise, price, checkout_url,
   delivery_files, and refund/support instructions.
2. A complete guide or workbook with specific, actionable content. Notes,
   outlines, idea lists, prompt packs, and placeholders are rejected.
3. A real cover asset and a customer-facing checkout page.
4. A delivery package customers can download immediately after purchase.
5. Worksheets, templates, checklists, or other implementation assets that make
   the guide usable.
6. A quality report proving the gate passed before the product enters the money
   loop or marketing queue.

Rejected by default: wall-art ideas without finished design files, prompt packs
as the main product, text-file stubs, coming-soon pages, affiliate-only pages,
and anything with TODO/placeholder language.
