# The Prop Firm Pass Playbook: Payout Readiness Kit Delivery

Start with guide.html or guide.md. Then fill the CSV templates in order:

1. rule_audit.csv
2. daily_risk_plan.csv
3. setup_scorecard.md
4. trade_journal.csv
5. payout_readiness_checklist.csv

Support: Reply to the purchase receipt or DM @jackmactrades with the receipt email.
Refund policy: 14-day refund if the files are unusable or materially different from the checkout description.
