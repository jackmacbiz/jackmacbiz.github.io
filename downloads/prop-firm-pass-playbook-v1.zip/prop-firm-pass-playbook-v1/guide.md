# The Prop Firm Pass Playbook: Payout Readiness Kit

**Audience:** Funded-account and evaluation futures traders who need a rules-first operating system before they press for payout.

**Promise:** Turn prop-firm rules, daily risk, trade selection, and payout timing into a repeatable checklist so the trader knows when to push, pause, or stand down.

This product is educational and operational. It is not financial advice, trade
signals, a payout guarantee, or a promise that any prop firm will approve an
account. It gives a trader a rules-first workflow so decisions are written
before pressure arrives.

## What You Receive

- A complete guide for installing a payout-first trading operating system.
- CSV worksheets for rule audits, daily risk planning, trade journaling, and
  payout readiness.
- A setup scorecard and failure-response protocol.
- A checkout and delivery package that can be handed to a customer immediately.

## How To Use The Kit

Read chapter one, fill the rule audit, and do not skip ahead to trading tactics.
The value of the product is the operating system: account rules, daily loss map,
setup tiering, consistency control, news filter, payout protocol, and weekly
review. Each chapter ends with field actions. Complete those actions in order.

## 1. The Payout-First Operating Rule

Most prop-firm traders fail because they treat an evaluation like a
normal trading account. The account is not normal. The firm sells a
rule set, not freedom. The first job is not to prove talent. The
first job is to survive the exact rules long enough for a payout
request to clear. This kit starts with that truth because every
later decision depends on it.

A payout-first trader decides position size, session timing, and
setup selection from the rule book backward. The trader asks which
loss would break the account, which behavior would violate
consistency, which day would trigger emotional overtrading, and
which profit pattern gives the firm a clean reason to approve the
withdrawal. That is not timid trading. It is professional constraint
design. The goal is to make the account boring enough to keep.

The operating rule is simple: no trade is valid unless it protects
the next payout attempt. If the trade can produce profit but also
creates a high chance of daily loss breach, consistency distortion,
max drawdown pressure, or rule confusion, the trade is rejected. A
trader can always find another setup. A breached funded account
cannot be unbreached.

### Field Actions

- Write the firm name, account size, drawdown type, daily loss, max loss, news rule, and payout rule into rule_audit.csv.
- Mark each rule as hard stop, soft constraint, or unknown.
- Do not trade until every unknown is answered from the firm's current rule page.
- Set the day plan from the tightest rule, not from the biggest profit target.

### Pass/Fail Standard

This chapter is complete only when the trader can show the filled worksheet,
state the exact rule being protected, and name the condition that would make
them stop trading for the day. If that answer is vague, the system has not been
implemented yet.


## 2. Rule Audit Before Any Trade

A rule audit is a defensive checklist that removes guesswork before
money is at risk. Traders usually read the headline rules and skip
the operational details: whether the drawdown trails intraday or
end-of-day, whether unrealized profit counts, whether payout days
require minimum active days, whether a news window applies to
entries only or open positions, and whether scaling breaks
consistency. Those details decide whether a good chart setup is
actually tradable.

The audit should be written in trader language, not legal language.
If the firm says a trailing threshold is calculated from the highest
intraday balance, translate that into the exact dollar distance
between the current balance and account failure. If the firm says a
trader needs five active trading days, translate that into a pacing
calendar. If the firm says the largest winning day cannot exceed a
percentage of total profit, translate that into a maximum allowed
win for the day.

The audit is updated whenever the firm changes terms, when the
account crosses a new balance threshold, and before any payout
request. Old rules are dangerous. Screenshots are useful, but a
dated worksheet is better because it turns the rule into a decision
that can be followed under pressure.

### Field Actions

- Open the current rule page for the firm and fill every row in rule_audit.csv.
- For every hard stop, write the exact dollar amount or clock time that triggers it.
- Save a dated copy of the rule page URL in the source_url column.
- Review the audit before the first trade of every week.

### Pass/Fail Standard

This chapter is complete only when the trader can show the filled worksheet,
state the exact rule being protected, and name the condition that would make
them stop trading for the day. If that answer is vague, the system has not been
implemented yet.


## 3. Daily Loss Map

The daily loss rule is the fastest way to turn one bad sequence into
an account failure. The map converts that rule into three limits: a
normal stop amount, a danger amount, and a lockout amount. The
normal stop is where trading ends on an ordinary losing day. The
danger amount is where position size drops to the smallest allowed
unit. The lockout amount is where the platform closes and no
exception is allowed.

A usable map is built before the session begins. It includes the
opening account balance, the firm's daily loss number, the trader's
personal daily stop, the number of full-risk attempts allowed, and
the setup quality required after the first loss. The trader should
never be doing this math while angry. A trader who calculates risk
after two losses is negotiating with adrenaline.

The map also prevents false confidence after an early win. Many
traders increase size because the day is green, then give back the
cushion and breach. The map treats realized profit as temporary
until the session is over. If the account is near payout, protecting
eligibility matters more than maximizing the day.

### Field Actions

- Fill daily_risk_plan.csv before the first trade.
- Set personal daily stop at 35 to 50 percent of the firm's daily loss limit.
- Define maximum full-risk trades and reduced-risk trades before entry.
- When danger amount is reached, reduce size or stop. No discretionary override.

### Pass/Fail Standard

This chapter is complete only when the trader can show the filled worksheet,
state the exact rule being protected, and name the condition that would make
them stop trading for the day. If that answer is vague, the system has not been
implemented yet.


## 4. Consistency Control

Consistency rules punish lopsided profit distribution. Even when a
firm does not publish a strict percentage rule, payout reviewers
often dislike accounts that earn almost everything from one
oversized day. A trader who wants clean payouts should build profit
in a way that looks intentional, repeatable, and rule-respecting.

The consistency worksheet tracks total profit, largest winning day,
average winning day, and the percent of profit coming from the
largest day. If the largest day is already too dominant, the next
best action may be to trade smaller, wait for more active days, or
stop pressing until the distribution normalizes. The worksheet does
not promise approval. It gives the trader a way to avoid obvious
self-inflicted rejection patterns.

This is where patience becomes a financial edge. A trader near the
payout threshold often wants to hit one more big day. The cleaner
move may be two or three smaller green days that demonstrate
repeatability. The scorecard turns that temptation into a visible
number.

### Field Actions

- Update payout_readiness_checklist.csv after every trading day.
- If the largest winning day is more than 35 percent of total profit, reduce size until the ratio improves.
- Do not request payout until active-day and profit-distribution rules are both green.
- Write the reason for every unusually large day in the journal.

### Pass/Fail Standard

This chapter is complete only when the trader can show the filled worksheet,
state the exact rule being protected, and name the condition that would make
them stop trading for the day. If that answer is vague, the system has not been
implemented yet.


## 5. Setup Tiering

Not every setup deserves funded-account risk. The kit uses three
tiers. Tier A is the trader's best proven setup: clear context,
defined invalidation, clean liquidity or momentum condition, and a
trade location that can be explained in one sentence. Tier B is a
valid but less clean trade, allowed only at reduced size. Tier C is
any trade taken because the trader is bored, annoyed, trying to win
back a loss, or reacting to a candle with no plan.

Tiering protects the account by removing the phrase 'this looks
good enough.' The funded account only pays for repeatable behavior.
Tier A trades can use normal risk if the daily loss map is green.
Tier B trades use half risk or paper notes only. Tier C trades are
skipped and written down as avoided mistakes.

The goal is not to trade less forever. The goal is to stop giving
equal risk to unequal ideas. Once the trader has data, the tiers can
be updated from the journal rather than emotion.

### Field Actions

- Define one Tier A setup and one Tier B setup in setup_scorecard.md.
- Score every planned trade before entry using the trade_journal.csv fields.
- Use normal risk only when setup_tier is A and rule_status is green.
- Review skipped Tier C trades weekly to find behavior patterns.

### Pass/Fail Standard

This chapter is complete only when the trader can show the filled worksheet,
state the exact rule being protected, and name the condition that would make
them stop trading for the day. If that answer is vague, the system has not been
implemented yet.


## 6. News And Volatility Filter

News rules vary by firm, but volatility risk exists even when the
firm allows trading. A payout-first trader treats major scheduled
events as a separate environment. CPI, FOMC, NFP, central-bank
speakers, and major rate decisions can turn a valid setup into a
slippage event that breaks the daily loss map. The rule is not 'news
is bad.' The rule is 'unpriced volatility needs its own plan.'

The filter has three states. Red means no new positions and no open
position through the event. Yellow means reduced size and wider
execution tolerance after the first reaction clears. Green means
normal rules apply. The important part is that the state is chosen
before the release, not during the spike.

Traders should also check whether the firm has platform-specific
rules for news, copy trading, or holding through maintenance. A
profit made during a prohibited window can still be a failure if the
account is reviewed and denied.

### Field Actions

- Write today's scheduled events in daily_risk_plan.csv.
- Set each event to red, yellow, or green before market open.
- If the firm's news rule is unclear, treat it as red until verified.
- After a red event, wait for spreads and candle range to normalize before reassessing.

### Pass/Fail Standard

This chapter is complete only when the trader can show the filled worksheet,
state the exact rule being protected, and name the condition that would make
them stop trading for the day. If that answer is vague, the system has not been
implemented yet.


## 7. Payout Request Protocol

The payout request is not a victory lap. It is an operational event.
Before requesting, the trader should confirm active days, minimum
profit, consistency, rule compliance, account information, payment
details, and open-position status. The goal is to remove every easy
reason for delay or denial.

The protocol starts two sessions before the planned request. The
trader shifts from growth mode to preservation mode, reduces size,
and stops taking marginal trades. On the final day, the trader
verifies there are no open positions, no pending orders, no
unresolved rule questions, and no abnormal large-day ratio. Then the
request is filed with a screenshot archive.

If a payout is denied, the response should be diagnostic, not
emotional. The trader records the stated reason, compares it to the
checklist, updates the rule audit, and decides whether to keep,
reset, or abandon the firm. A denied payout with a clear lesson is
data. A denied payout repeated twice is a system failure.

### Field Actions

- Use payout_readiness_checklist.csv two sessions before the planned request.
- Do not increase size on the final day before payout.
- Save screenshots of balance, trading days, and closed positions before submitting.
- If denied, record the exact reason and update the audit before the next trade.

### Pass/Fail Standard

This chapter is complete only when the trader can show the filled worksheet,
state the exact rule being protected, and name the condition that would make
them stop trading for the day. If that answer is vague, the system has not been
implemented yet.


## 8. Weekly Review

Weekly review turns the account from a hope project into an
operating system. The review looks for four patterns: rule pressure,
setup drift, emotional trades, and payout readiness. Each pattern
gets one change for the next week. The trader is not allowed to
rewrite the whole system every weekend because that creates new
instability.

The review starts with numbers: total trades, average risk, largest
loss, largest win, rule warnings, active days, and consistency
ratio. Then it reviews screenshots and journal notes. The trader
marks which losses were acceptable and which were process breaks.
The distinction matters. A planned loss is cost of business. An
unplanned loss is a leak.

The final output is a one-page plan for the next week: allowed
setup, max daily risk, news rules, payout status, and one behavior
to remove. This plan goes beside the trading screen.

### Field Actions

- Run the weekly review every Friday after trading or Sunday before planning.
- Pick one process leak to fix, not ten.
- Archive the week's CSV files before starting the next week.
- If rule pressure increased for two weeks, cut risk before changing strategy.

### Pass/Fail Standard

This chapter is complete only when the trader can show the filled worksheet,
state the exact rule being protected, and name the condition that would make
them stop trading for the day. If that answer is vague, the system has not been
implemented yet.


## 9. Failure Response

The account needs a failure response before the failure happens.
Without one, the trader improvises while frustrated. The response
has three levels. Level one is a normal losing day: stop at personal
daily limit, write the journal, and return next session. Level two
is a rule-pressure day: stop immediately, reduce next-session size,
and audit the trigger. Level three is a breach or denial: stop all
trading on that firm until the postmortem is complete.

The postmortem is short and factual. What rule was threatened or
broken? What decision created the risk? Was the setup valid? Was
the size correct? Was there a news or volatility event? What exact
rule will prevent the repeat? If the answer is not specific, the
trader is not ready to re-enter.

The purpose is not shame. The purpose is to keep one mistake from
becoming a pattern. A trader who can respond correctly to failure
has a much better chance of keeping future funded accounts.

### Field Actions

- Write a level one, two, and three response in the workbook before trading.
- After any level two event, reduce next-session risk by at least half.
- After a breach, do not buy another evaluation until the postmortem is written.
- Track repeated triggers in the weekly review.

### Pass/Fail Standard

This chapter is complete only when the trader can show the filled worksheet,
state the exact rule being protected, and name the condition that would make
them stop trading for the day. If that answer is vague, the system has not been
implemented yet.


## 10. Implementation Schedule

The kit can be installed in one focused hour. First, complete the
rule audit from the firm's current rule page. Second, build the
daily loss map for the account size. Third, define the Tier A setup
and the conditions that invalidate it. Fourth, set the news filter
for the next three trading days. Fifth, fill the payout readiness
checklist with the current account state.

After installation, the trader uses three daily actions: review
rules before trading, score each trade before entry, and update the
journal after the session. The weekly review turns that data into
one change. This is intentionally simple because complexity breaks
under stress.

A customer should finish this product with a usable rule audit, a
daily risk plan, a setup scorecard, a payout checklist, and a
failure response. Those files are the product. The guide explains
the thinking, but the worksheets are what change behavior.

### Field Actions

- Block one hour to install the kit before the next funded-account session.
- Print or pin the daily risk plan and setup scorecard.
- Use the journal for at least 20 trades before changing setup definitions.
- Request payout only when the checklist is green.

### Pass/Fail Standard

This chapter is complete only when the trader can show the filled worksheet,
state the exact rule being protected, and name the condition that would make
them stop trading for the day. If that answer is vague, the system has not been
implemented yet.


## Appendix A. Calculation Examples

The daily loss map should be calculated with numbers before the market opens.
Example: a trader has a 50k account, a firm daily loss limit of 1000 dollars,
and a personal daily stop of 400 dollars. If the trader normally risks 150
dollars per trade, the day allows two normal attempts and one reduced-risk
attempt. After two normal losses, the trader is not allowed to take a third
normal trade because that creates a path from ordinary variance to rule
pressure. The reduced-risk attempt is allowed only if the setup is Tier A and
the news filter is green. If either condition is not true, the session is done.

Consistency example: an account is up 1800 dollars and the largest winning day
is 950 dollars. The largest day is 52.8 percent of total profit. Even if the
firm does not publish a strict rule, this account is fragile from a payout
review perspective. The next plan should avoid pressing for another large day.
The trader can reduce size, aim for smaller green days, and wait for the ratio
to improve. If total profit rises to 3000 dollars while the largest day remains
950, the ratio drops to 31.7 percent, which is cleaner.

Trailing drawdown example: an account begins at 50,000, reaches an intraday high
of 51,200, and has a trailing threshold 2,500 dollars below the high. The
failure line is now 48,700 if the firm trails intraday. A trader who only thinks
about starting balance may believe there is 2,500 dollars of room, but the real
room from 51,200 is different. The worksheet forces that translation before
entries are placed.

## Appendix B. Filled-In Daily Plan Example

Date: Monday. Market: NQ. Firm: 50k evaluation. Opening balance: 51,050. Daily
loss limit: 1,000. Personal daily stop: 400. Danger amount: 300. Normal risk:
125 per trade. Full-risk attempts allowed: two. News state: yellow until thirty
minutes after the 10:00 release. Tier A setup: pullback into prior breakout
level after market structure holds above opening range. Tier B setup: momentum
continuation after first impulse, half risk only. Lockout trigger: two losses,
one rule uncertainty, or any trade taken outside the defined setup.

The trader's first trade is a Tier A setup after the news window clears. It
loses 125 dollars. The second setup is Tier B because location is late. It is
skipped at normal size and either taken at half risk or not taken. If the second
trade loses 60 dollars, the day is down 185 dollars and still green from a rule
pressure perspective. If the trader feels rushed after the second loss, the
emotion_state column becomes yellow and only a perfect Tier A trade can be
considered. This is the system working. The worksheet is allowed to stop trades
that the chart alone would not stop.

## Appendix C. Customer Completion Checklist

The customer has implemented the product when the following items are complete:

- The current firm rule page has been translated into rule_audit.csv.
- The daily risk plan has exact dollar limits for the next session.
- The setup scorecard contains one Tier A setup and one Tier B setup.
- The trade journal has been prepared before the first trade.
- The payout readiness checklist has a status for every checkpoint.
- The trader can state the lockout trigger without looking at the guide.

Do not treat reading as completion. Completion means the files are filled,
visible, and used during the next session. The product is designed to be
practical, so the customer should be able to install it, trade from it, and
review from it without needing another tool.

The best use of the kit is boring repetition. The trader fills the same plan
before the session, grades the same fields after each trade, and reviews the
same numbers each week. That repetition is what reveals whether the trader has
a strategy problem, a sizing problem, a rule-comprehension problem, or a
discipline problem. Without the worksheets, every losing week feels like a new
story. With the worksheets, the pattern becomes visible enough to fix.

