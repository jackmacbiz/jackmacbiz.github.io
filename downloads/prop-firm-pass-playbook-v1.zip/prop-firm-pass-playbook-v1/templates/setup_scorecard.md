# Setup Scorecard

Score each planned trade before entry.

| Field | Green | Yellow | Red |
| --- | --- | --- | --- |
| Rule status | All rules verified | One soft constraint | Any hard-stop uncertainty |
| Setup quality | Tier A definition met | Tier B only | Impulse or revenge trade |
| Daily loss map | Full room available | Danger amount near | Lockout trigger near |
| News filter | Green | Yellow, reduced size | Red, no trade |

Normal risk is allowed only when every field is green.
