# The Risk Compliance Excel Templates Toolkit — Quick-Start Manual

The Risk Compliance Excel Templates Toolkit is a set of fillable spreadsheets and checklists for risk compliance excel templates. Each tool below is a file you open in Excel, Google Sheets, or Numbers (CSV) or any text/markdown app (.md). Fill them in as you go — the value is in the structure, not in reading prose.

## Checklists & Worksheets

- `risk-control-matrix.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `audit-checklist.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `vendor-due-diligence-log.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `incident-response-log.csv`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.

- `compliance-glossary.md`: open it before each work block and go top to bottom; treat every unchecked item as a reason you're not ready yet.


## How the tools work together

Open `risk-control-matrix.csv`, `audit-checklist.md`, `vendor-due-diligence-log.csv`, `incident-response-log.csv`, `compliance-glossary.md` in order. Each file is a working tool for risk compliance excel templates — fill it in as you go and revisit it on your next work block; the value is in using the structure, not in reading prose.