# Internal Audit Checklist: Risk Compliance Framework

## Section 1: Governance & Oversight
- [ ] Board of Directors risk committee charter is current and signed.
- [ ] Risk appetite statement has been reviewed and approved in Q2 2026.
- [ ] Organizational chart clearly defines segregation of duties for high-risk functions.

## Section 2: Financial Controls
- [ ] Bank reconciliations performed monthly with independent review by non-preparer.
- [ ] Journal entries over $10,000 require secondary approval in ERP system.
- [ ] Petty cash logs matched to receipts weekly; variance < $50.

## Section 3: IT & Cybersecurity
- [ ] All user access rights reviewed quarterly with least-privilege principle applied.
- [ ] Multi-factor authentication enabled for 100% of remote access accounts.
- [ ] Backup restoration test completed successfully in last 90 days.
- [ ] Firewall rules audited and cleaned up quarterly.

## Section 4: Operational Compliance
- [ ] Vendor due diligence files complete for all active suppliers >$25k/year.
- [ ] Employee training completion rate for anti-fraud and data privacy >95%.
- [ ] Incident response plan tested via tabletop exercise in last 6 months.

## Section 5: Regulatory Reporting
- [ ] All statutory filings submitted on time with no penalties incurred.
- [ ] External audit findings from 2025 fully remediated with evidence of closure.
- [ ] Whistleblower hotline active and reports reviewed by compliance officer monthly.