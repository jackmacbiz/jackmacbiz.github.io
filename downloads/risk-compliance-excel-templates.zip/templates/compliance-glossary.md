# Risk Compliance Glossary

**Audit Trail**: A chronological record that provides documentary evidence of the sequence of activities that have affected at any time a specific operation, procedure, or event.

**Due Diligence**: The investigation or exercise of care that a reasonable business or person is expected to take before entering into an agreement or contract with another party.

**Fraud Triangle**: A model explaining the three factors that contribute to fraud: Pressure (motive), Opportunity, and Rationalization.

**Key Risk Indicator (KRI)**: A metric used by organizations to provide an early signal of increasing risk exposure in various areas of the enterprise.

**Segregation of Duties**: A internal control concept designed to ensure that no single individual has control over all aspects of any significant transaction.

**Whistleblower Policy**: A corporate policy that details how employees can report unethical or illegal behavior without fear of retaliation.