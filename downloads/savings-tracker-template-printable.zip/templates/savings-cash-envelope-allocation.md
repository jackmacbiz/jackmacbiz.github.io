# Cash Envelope Allocation Guide

## Purpose
Allocate physical cash for variable expenses to prevent overspending.

## Monthly Budget Caps (Example: $2000 Income)
| Category | Limit | Envelope Label |
|----------|-------|----------------|
| Groceries | $400 | FOOD |
| Dining Out | $100 | EATS |
| Gas/Transport | $150 | FUEL |
| Household Supplies | $50 | HOME |
| Personal Care | $75 | SELF |
| Entertainment | $80 | FUN |
| Miscellaneous | $50 | OTHER |

## Rules
1. Withdraw cash at month start.
2. Fill envelopes immediately.
3. When envelope is empty, stop spending in that category.
4. Roll over unused cash to next month's savings goal.