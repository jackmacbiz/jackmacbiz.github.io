# Savings Goal Breakdown
## Target: Emergency Fund ($10,000)

### Current Status
- Starting Balance: $1,200
- Monthly Contribution: $800
- Timeline: 11 Months

### Monthly Milestones
| Month | Contribution | Cumulative Total |
|-------|--------------|------------------|
| Jan   | $800         | $2,000           |
| Feb   | $800         | $2,800           |
| Mar   | $800         | $3,600           |
| Apr   | $800         | $4,400           |
| May   | $800         | $5,200           |
| Jun   | $800         | $6,000           |
| Jul   | $800         | $6,800           |
| Aug   | $800         | $7,600           |
| Sep   | $800         | $8,400           |
| Oct   | $800         | $9,200           |
| Nov   | $800         | $10,000          |

### Action Items
- [ ] Set up auto-transfer on the 1st of each month.
- [ ] Review progress at month-end.
- [ ] Adjust contribution if income changes.