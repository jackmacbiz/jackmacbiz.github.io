# Zero-Based Budget Worksheet
## January 2024

### Income
Paycheck 1: $3,200.00
Freelance: $450.00
Total Income: $3,650.00

### Expenses (Assign Every Dollar)
Rent: $1,200.00
Groceries: $400.00
Utilities: $150.00
Internet/Phone: $90.00
Car Payment: $350.00
Gas: $60.00
Entertainment: $50.00
Savings Goal: $500.00
Emergency Fund: $200.00
Vacation Fund: $100.00
Miscellaneous: $50.00
Total Expenses: $3,650.00

### Remaining Balance: $0.00