WEDDING SEATING CHART PLANNER KIT — what's inside

1. guide.md / guide.html  — The Calm Seating Plan (7-step method + hard cases + day-of binder)
2. master-guest-list.csv  — track RSVPs, meals, dietary notes, plus-ones, table numbers (Excel/Sheets/Numbers)
3. table-assignment-worksheet.md — the cluster-first framework so you place groups, not 150 names
4. find-your-seat-signs.md — entrance sign + table number wording templates to print

HOW TO USE: open guide.html in any browser to read the method. Open the CSV in
Excel, Google Sheets or Numbers. Fill the worksheet, then print your signs.

Personal use license. Not for resale or redistribution. Questions? Message the shop.
