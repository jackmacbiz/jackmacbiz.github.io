# Find Your Seat Sign + Table Number Templates

Copy the wording you like, drop in your names/date, and print. Pair with the
table numbers in your chart. Recommended print: entrance sign at 16x20 or 18x24;
table numbers at 5x7 folded or 4x6 flat.

---

## ENTRANCE — "Find Your Seat" sign (option 1, classic)

        ~ Please Find Your Seat ~

        [Names], [Date]

   Take a seat, but not ours —
   we saved you the best one.

   (Guests are then listed alphabetically with table numbers,
    or arranged by table on a board.)

---

## ENTRANCE — "Find Your Seat" sign (option 2, warm)

        Welcome — Find Your Seat

   We're so glad you're here.
   Find your name below and join us
   at your table. Let's celebrate!

        [Names]  •  [Date]

---

## TABLE NUMBER CARD template (repeat per table)

        Table  [ 1 ]

   (optional) "The year we met" / a shared memory /
   a place that matters to you both.

---

## TIP
List guests alphabetically by LAST name with their table number — it's faster for
guests than listing by table. Keep the sign to "Name -> Table #" only; the seat at
the table is open within it.
