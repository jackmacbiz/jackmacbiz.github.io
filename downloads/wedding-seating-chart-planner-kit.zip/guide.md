# The Calm Seating Plan: 7 Steps to a Finished Wedding Chart

## Why seating charts feel impossible (and why they aren't)
A wedding seating chart breaks people not because it's hard, but because it's done
in the wrong order. Most couples start by staring at a blank table layout and trying
to place 150 individual names at once. That's like solving a 1000-piece puzzle by
grabbing random pieces. This guide gives you the order professional planners use:
group first, place groups second, fix exceptions last. Worked end to end, a full
chart takes one focused evening.

---

## Step 1 — Lock the guest list before you place anyone
Open the Master Guest List Spreadsheet (included). Do not start seating until every
row has a CONFIRMED status. A single "maybe" cousin can move three tables.
- Mark each guest: Confirmed / Declined / Awaiting RSVP.
- Record meal choice and dietary notes now — caterers count by table.
- Note plus-ones explicitly as their own rows so they get a seat, not an afterthought.

## Step 2 — Count your real number and your tables
- Final headcount = Confirmed guests + confirmed plus-ones.
- Ask your venue the seats-per-table number (usually 8 or 10). Round tables of 10
  seat comfortably at 8–9; squeezing 10 makes elbows touch.
- Tables needed = ceil(headcount / seats-per-table) + 1 buffer table. The buffer
  absorbs the inevitable late RSVP.

## Step 3 — Build "social clusters," not individual seats
This is the move that makes everything easy. In the Table Assignment Worksheet,
group guests into clusters of people who already know and like each other:
- College friends, work friends, the partner's friends.
- Each side's immediate family, then extended family.
- Couples and families stay intact — never split a married couple across tables.
A cluster is usually 4–10 people. You are now placing ~15 clusters, not 150 names.

## Step 4 — Place the anchor tables first
- Head table or sweetheart table: you two (+ wedding party if you want a head table).
- Parents' tables: each set of parents near the front. If parents are divorced,
  give each their own table with their own people and a little distance — see Step 6.
- Place elderly guests away from the band/speakers and near restrooms and an exit.

## Step 5 — Fill outward from the dance floor
- Closest to the dance floor and the couple: your youngest, liveliest clusters
  (friends who'll get up and dance).
- Mid-distance: family clusters and couples.
- Outer ring / quieter corners: older relatives and anyone who wants conversation
  over volume.

## Step 6 — Handle the hard cases on purpose
- Divorced / feuding relatives: separate tables, ideally not in direct sightline.
  Put a friendly buffer cluster between them.
- The "no one knows them" guest (a plus-one, a distant cousin): seat them with the
  warmest, most welcoming cluster — never alone at the edge.
- Kids: decide early — a dedicated kids' table (fun, with activity sheets) OR kids
  with their parents. Don't mix half and half; pick one rule and tell parents.
- Coworkers vs. friends: people are happiest with peers, not their boss.

## Step 7 — Lock it, label it, and build the signs
- Freeze the chart 7–10 days out. After that, absorb changes by swapping within a
  table, not reshuffling the whole room.
- Number every table. Fill in the included "Find Your Seat" entrance sign and the
  per-table number cards using the templates.
- Give the final table-by-table list (with meal counts) to your caterer and
  coordinator. Print one copy for the day-of binder.

---

## Last-minute RSVP fixes (without redoing everything)
- A late YES: seat them at the buffer table or fill an open seat in their natural
  cluster. One person rarely requires a reshuffle.
- A day-before NO: leave the seat empty rather than re-balancing — an empty chair is
  invisible; a rushed reshuffle creates new problems.
- A surprise plus-one: politely confirm with the venue/caterer first; if yes, add to
  the guest's cluster table or the buffer.

## The day-of binder checklist
- [ ] Final guest list with table numbers (printed)
- [ ] Meal count per table for the caterer
- [ ] Find Your Seat entrance sign printed and framed
- [ ] Numbered table cards printed
- [ ] One spare printed copy for your coordinator

You now have a seating plan that's organized, kind to your guests, and finished —
without a planner's fee. Congratulations, and enjoy the day.
