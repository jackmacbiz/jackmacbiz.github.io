# Table Assignment Worksheet

Work top to bottom. Do NOT assign individual seats until every cluster is built.

## A. Social Clusters (group people who already like each other)
List 4–10 people per cluster. Keep couples and families together.

Cluster 1 (name it, e.g. "Bride college friends"): ______________________________
  Members: ____________________________________________________________________

Cluster 2: ____________________________________________________________________
  Members: ____________________________________________________________________

Cluster 3: ____________________________________________________________________
  Members: ____________________________________________________________________

Cluster 4: ____________________________________________________________________
  Members: ____________________________________________________________________

Cluster 5: ____________________________________________________________________
  Members: ____________________________________________________________________

(Add as many clusters as you need — most weddings have 10–18.)

## B. Anchor Placements (do these first)
Head / Sweetheart table — who: _______________________________________________
Parents Table A — who: _______________________________________________________
Parents Table B — who: _______________________________________________________
Elderly / accessibility table (near exit, away from speakers): _______________

## C. Cluster -> Table Map (place outward from dance floor)
Table 1: ___________________________  (cluster: _______________  seats used: __)
Table 2: ___________________________  (cluster: _______________  seats used: __)
Table 3: ___________________________  (cluster: _______________  seats used: __)
Table 4: ___________________________  (cluster: _______________  seats used: __)
Table 5: ___________________________  (cluster: _______________  seats used: __)
Table 6: ___________________________  (cluster: _______________  seats used: __)
Table 7: ___________________________  (cluster: _______________  seats used: __)
Table 8: ___________________________  (cluster: _______________  seats used: __)
Buffer table (late RSVPs): ___________________________________________________

## D. Exceptions checklist
- [ ] Divorced/feuding guests seated apart with a buffer cluster between
- [ ] Every plus-one and "lone" guest is in a warm cluster, never isolated
- [ ] Kids rule chosen (kids' table OR with parents) and consistent
- [ ] Meal counts per table totaled for the caterer
