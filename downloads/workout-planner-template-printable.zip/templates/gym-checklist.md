# Pre-Workout Checklist
- [ ] Hydrate (16oz water)
- [ ] Warm-up (5 min cardio)
- [ ] Stretch hips/shoulders
- [ ] Pack towel and shaker
- [ ] Download playlist

# Post-Workout Checklist
- [ ] Cool down stretch
- [ ] Log sets/reps in tracker
- [ ] Protein shake within 30 mins
- [ ] Update next session plan
- [ ] Clean equipment