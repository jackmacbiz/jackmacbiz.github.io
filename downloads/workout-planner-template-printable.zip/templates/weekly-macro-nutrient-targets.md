# Weekly Macro Nutrient Targets
## Goal: Muscle Hypertrophy & Recovery

| Day | Protein (g) | Carbs (g) | Fats (g) | Calories |
|-----|-------------|-----------|----------|----------|
| Mon | 180         | 250       | 70       | 2400     |
| Tue | 180         | 230       | 65       | 2300     |
| Wed | 190         | 260       | 75       | 2500     |
| Thu | 175         | 240       | 68       | 2350     |
| Fri | 185         | 255       | 72       | 2450     |
| Sat | 195         | 270       | 80       | 2600     |
| Sun | 170         | 220       | 60       | 2200     |