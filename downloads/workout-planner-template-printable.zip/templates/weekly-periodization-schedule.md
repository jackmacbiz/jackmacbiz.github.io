# Weekly Periodization Schedule

## Objective
Balance intensity and volume to prevent overtraining while maximizing hypertrophy and strength gains.

### Monday: Upper Body Push (Heavy)
- Barbell Bench Press: 4 sets x 5 reps @ 80% 1RM
- Overhead Press: 3 sets x 8 reps
- Incline Dumbbell Press: 3 sets x 10 reps
- Tricep Dips: 3 sets x failure

### Tuesday: Lower Body (Squat Focus)
- Back Squat: 4 sets x 5 reps @ 75% 1RM
- Romanian Deadlift: 3 sets x 8 reps
- Leg Press: 3 sets x 12 reps
- Calf Raises: 4 sets x 15 reps

### Wednesday: Active Recovery / Mobility
- Light Cardio (Zone 2): 30 minutes
- Foam Rolling: Full body focus
- Dynamic Stretching: Hip flexors and thoracic spine

### Thursday: Upper Body Pull (Hypertrophy)
- Weighted Pull-ups: 3 sets x 8 reps
- Bent Over Barbell Rows: 4 sets x 8 reps
- Lat Pulldown: 3 sets x 12 reps
- Face Pulls: 3 sets x 15 reps

### Friday: Lower Body (Deadlift Focus)
- Conventional Deadlift: 3 sets x 5 reps @ 80% 1RM
- Front Squat: 3 sets x 8 reps
- Leg Curls: 3 sets x 12 reps
- Plank: 3 sets x 60 seconds

### Saturday: Accessory / Weak Points
- Lateral Raises: 4 sets x 15 reps
- Bicep Curls: 3 sets x 12 reps
- Hammer Curls: 3 sets x 12 reps
- Core Circuit: 3 rounds

### Sunday: Rest
- Complete rest or light walking.
- Meal prep for the upcoming week.